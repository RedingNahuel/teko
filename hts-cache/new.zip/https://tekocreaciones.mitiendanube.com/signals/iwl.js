<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:fb="http://www.facebook.com/2008/fbml" xmlns:og="http://opengraphprotocol.org/schema/" lang="es">
<head>
<link rel="preconnect" href="https://acdn.mitiendanube.com" />
<link rel="dns-prefetch" href="https://acdn.mitiendanube.com" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title></title>
<meta name="description" content />
<meta property="og:site_name" content="Teko Creaciones" />
<meta property="fb:app_id" content="107147892676939" />
<style>
            
            
                
                
                @import url('//fonts.googleapis.com/css?family=Montserrat:400,700&display=swap');

            

            @charset "UTF-8":

/*============================================================================
critical-css.tpl

    -This file contains all the theme critical styles wich will be loaded inline before the rest of the site
    -Rest of styling can be found in:
    	--static/css/style-async.css.tpl --> For non critical styles witch will be loaded asynchronously
      --static/css/style-colors.critical.tpl --> For critical CSS rendered inline before the rest of the site

==============================================================================*/

/*============================================================================
  Table of Contents

  #External CSS libraries and plugins
    // Bootstrap Grid v4.1.3
    // Swiper 4.4.2
  #Critical path helpers
  #Components
    // Wrappers
    // Placeholders and preloaders
    // Animations
    // Buttons
    // Links
    // Titles and breadcrumbs
    // Icons
    // Texts
    // Sliders
    // Lists
    // Notifications
    // Badge
    // Tooltip
    // Images
    // Forms
    // Video
  #Header and nav
    // Topbar
    // Nav
    // Logo
    // Cart widget and search
  #Home page
    // Welcome message
  #Banners
    // Home banners
    // Informative banners
  #Product grid
    // Category controls
    // Grid item
    // Labels
  #Product detail
  	// Image
  #Cart detail
    // Shipping Calculator
  #Contact page
    // Data contact
  #Media queries
    // Min width 1400px
    // Min width 768px
    //// Components
    //// Header and Nav
    //// Product grid
    //// Helper classes
  
  #Helper classes
    // Margin and padding
    // Text
    // Algin
    // Position
    // Image
    // Visibility
    // Float 
    // Width

==============================================================================*/

/*============================================================================
  #External CSS libraries and plugins
==============================================================================*/
  
{# /* // Bootstrap Grid v4.1.3 */ #}

@-ms-viewport{width:device-width}html{box-sizing:border-box;-ms-overflow-style:scrollbar}*,::after,::before{box-sizing:inherit}.container{width:100%;padding-right:15px;padding-left:15px;margin-right:auto;margin-left:auto}@media (min-width:576px){.container{max-width:540px}}@media (min-width:768px){.container{max-width:720px}}@media (min-width:992px){.container{max-width:960px}}@media (min-width:1200px){.container{max-width:1140px}}.container-fluid{width:100%;padding-right:15px;padding-left:15px;margin-right:auto;margin-left:auto}.row{display:-ms-flexbox;display:flex;-ms-flex-wrap:wrap;flex-wrap:wrap;margin-right:-15px;margin-left:-15px}.no-gutters{margin-right:0;margin-left:0}.no-gutters>.col,.no-gutters>[class*=col-]{padding-right:0;padding-left:0}.col,.col-1,.col-10,.col-11,.col-12,.col-2,.col-3,.col-4,.col-5,.col-6,.col-7,.col-8,.col-9,.col-auto,.col-lg,.col-lg-1,.col-lg-10,.col-lg-11,.col-lg-12,.col-lg-2,.col-lg-3,.col-lg-4,.col-lg-5,.col-lg-6,.col-lg-7,.col-lg-8,.col-lg-9,.col-lg-auto,.col-md,.col-md-1,.col-md-10,.col-md-11,.col-md-12,.col-md-2,.col-md-3,.col-md-4,.col-md-5,.col-md-6,.col-md-7,.col-md-8,.col-md-9,.col-md-auto,.col-sm,.col-sm-1,.col-sm-10,.col-sm-11,.col-sm-12,.col-sm-2,.col-sm-3,.col-sm-4,.col-sm-5,.col-sm-6,.col-sm-7,.col-sm-8,.col-sm-9,.col-sm-auto,.col-xl,.col-xl-1,.col-xl-10,.col-xl-11,.col-xl-12,.col-xl-2,.col-xl-3,.col-xl-4,.col-xl-5,.col-xl-6,.col-xl-7,.col-xl-8,.col-xl-9,.col-xl-auto{position:relative;width:100%;min-height:1px;padding-right:15px;padding-left:15px}.col{-ms-flex-preferred-size:0;flex-basis:0;-ms-flex-positive:1;flex-grow:1;max-width:100%}.col-auto{-ms-flex:0 0 auto;flex:0 0 auto;width:auto;max-width:none}.col-1{-ms-flex:0 0 8.333333%;flex:0 0 8.333333%;max-width:8.333333%}.col-2{-ms-flex:0 0 16.666667%;flex:0 0 16.666667%;max-width:16.666667%}.col-3{-ms-flex:0 0 25%;flex:0 0 25%;max-width:25%}.col-4{-ms-flex:0 0 33.333333%;flex:0 0 33.333333%;max-width:33.333333%}.col-5{-ms-flex:0 0 41.666667%;flex:0 0 41.666667%;max-width:41.666667%}.col-6{-ms-flex:0 0 50%;flex:0 0 50%;max-width:50%}.col-7{-ms-flex:0 0 58.333333%;flex:0 0 58.333333%;max-width:58.333333%}.col-8{-ms-flex:0 0 66.666667%;flex:0 0 66.666667%;max-width:66.666667%}.col-9{-ms-flex:0 0 75%;flex:0 0 75%;max-width:75%}.col-10{-ms-flex:0 0 83.333333%;flex:0 0 83.333333%;max-width:83.333333%}.col-11{-ms-flex:0 0 91.666667%;flex:0 0 91.666667%;max-width:91.666667%}.col-12{-ms-flex:0 0 100%;flex:0 0 100%;max-width:100%}.order-first{-ms-flex-order:-1;order:-1}.order-last{-ms-flex-order:13;order:13}.order-0{-ms-flex-order:0;order:0}.order-1{-ms-flex-order:1;order:1}.order-2{-ms-flex-order:2;order:2}.order-3{-ms-flex-order:3;order:3}.order-4{-ms-flex-order:4;order:4}.order-5{-ms-flex-order:5;order:5}.order-6{-ms-flex-order:6;order:6}.order-7{-ms-flex-order:7;order:7}.order-8{-ms-flex-order:8;order:8}.order-9{-ms-flex-order:9;order:9}.order-10{-ms-flex-order:10;order:10}.order-11{-ms-flex-order:11;order:11}.order-12{-ms-flex-order:12;order:12}.offset-1{margin-left:8.333333%}.offset-2{margin-left:16.666667%}.offset-3{margin-left:25%}.offset-4{margin-left:33.333333%}.offset-5{margin-left:41.666667%}.offset-6{margin-left:50%}.offset-7{margin-left:58.333333%}.offset-8{margin-left:66.666667%}.offset-9{margin-left:75%}.offset-10{margin-left:83.333333%}.offset-11{margin-left:91.666667%}@media (min-width:576px){.col-sm{-ms-flex-preferred-size:0;flex-basis:0;-ms-flex-positive:1;flex-grow:1;max-width:100%}.col-sm-auto{-ms-flex:0 0 auto;flex:0 0 auto;width:auto;max-width:none}.col-sm-1{-ms-flex:0 0 8.333333%;flex:0 0 8.333333%;max-width:8.333333%}.col-sm-2{-ms-flex:0 0 16.666667%;flex:0 0 16.666667%;max-width:16.666667%}.col-sm-3{-ms-flex:0 0 25%;flex:0 0 25%;max-width:25%}.col-sm-4{-ms-flex:0 0 33.333333%;flex:0 0 33.333333%;max-width:33.333333%}.col-sm-5{-ms-flex:0 0 41.666667%;flex:0 0 41.666667%;max-width:41.666667%}.col-sm-6{-ms-flex:0 0 50%;flex:0 0 50%;max-width:50%}.col-sm-7{-ms-flex:0 0 58.333333%;flex:0 0 58.333333%;max-width:58.333333%}.col-sm-8{-ms-flex:0 0 66.666667%;flex:0 0 66.666667%;max-width:66.666667%}.col-sm-9{-ms-flex:0 0 75%;flex:0 0 75%;max-width:75%}.col-sm-10{-ms-flex:0 0 83.333333%;flex:0 0 83.333333%;max-width:83.333333%}.col-sm-11{-ms-flex:0 0 91.666667%;flex:0 0 91.666667%;max-width:91.666667%}.col-sm-12{-ms-flex:0 0 100%;flex:0 0 100%;max-width:100%}.order-sm-first{-ms-flex-order:-1;order:-1}.order-sm-last{-ms-flex-order:13;order:13}.order-sm-0{-ms-flex-order:0;order:0}.order-sm-1{-ms-flex-order:1;order:1}.order-sm-2{-ms-flex-order:2;order:2}.order-sm-3{-ms-flex-order:3;order:3}.order-sm-4{-ms-flex-order:4;order:4}.order-sm-5{-ms-flex-order:5;order:5}.order-sm-6{-ms-flex-order:6;order:6}.order-sm-7{-ms-flex-order:7;order:7}.order-sm-8{-ms-flex-order:8;order:8}.order-sm-9{-ms-flex-order:9;order:9}.order-sm-10{-ms-flex-order:10;order:10}.order-sm-11{-ms-flex-order:11;order:11}.order-sm-12{-ms-flex-order:12;order:12}.offset-sm-0{margin-left:0}.offset-sm-1{margin-left:8.333333%}.offset-sm-2{margin-left:16.666667%}.offset-sm-3{margin-left:25%}.offset-sm-4{margin-left:33.333333%}.offset-sm-5{margin-left:41.666667%}.offset-sm-6{margin-left:50%}.offset-sm-7{margin-left:58.333333%}.offset-sm-8{margin-left:66.666667%}.offset-sm-9{margin-left:75%}.offset-sm-10{margin-left:83.333333%}.offset-sm-11{margin-left:91.666667%}}@media (min-width:768px){.col-md{-ms-flex-preferred-size:0;flex-basis:0;-ms-flex-positive:1;flex-grow:1;max-width:100%}.col-md-auto{-ms-flex:0 0 auto;flex:0 0 auto;width:auto;max-width:none}.col-md-1{-ms-flex:0 0 8.333333%;flex:0 0 8.333333%;max-width:8.333333%}.col-md-2{-ms-flex:0 0 16.666667%;flex:0 0 16.666667%;max-width:16.666667%}.col-md-3{-ms-flex:0 0 25%;flex:0 0 25%;max-width:25%}.col-md-4{-ms-flex:0 0 33.333333%;flex:0 0 33.333333%;max-width:33.333333%}.col-md-5{-ms-flex:0 0 41.666667%;flex:0 0 41.666667%;max-width:41.666667%}.col-md-6{-ms-flex:0 0 50%;flex:0 0 50%;max-width:50%}.col-md-7{-ms-flex:0 0 58.333333%;flex:0 0 58.333333%;max-width:58.333333%}.col-md-8{-ms-flex:0 0 66.666667%;flex:0 0 66.666667%;max-width:66.666667%}.col-md-9{-ms-flex:0 0 75%;flex:0 0 75%;max-width:75%}.col-md-10{-ms-flex:0 0 83.333333%;flex:0 0 83.333333%;max-width:83.333333%}.col-md-11{-ms-flex:0 0 91.666667%;flex:0 0 91.666667%;max-width:91.666667%}.col-md-12{-ms-flex:0 0 100%;flex:0 0 100%;max-width:100%}.order-md-first{-ms-flex-order:-1;order:-1}.order-md-last{-ms-flex-order:13;order:13}.order-md-0{-ms-flex-order:0;order:0}.order-md-1{-ms-flex-order:1;order:1}.order-md-2{-ms-flex-order:2;order:2}.order-md-3{-ms-flex-order:3;order:3}.order-md-4{-ms-flex-order:4;order:4}.order-md-5{-ms-flex-order:5;order:5}.order-md-6{-ms-flex-order:6;order:6}.order-md-7{-ms-flex-order:7;order:7}.order-md-8{-ms-flex-order:8;order:8}.order-md-9{-ms-flex-order:9;order:9}.order-md-10{-ms-flex-order:10;order:10}.order-md-11{-ms-flex-order:11;order:11}.order-md-12{-ms-flex-order:12;order:12}.offset-md-0{margin-left:0}.offset-md-1{margin-left:8.333333%}.offset-md-2{margin-left:16.666667%}.offset-md-3{margin-left:25%}.offset-md-4{margin-left:33.333333%}.offset-md-5{margin-left:41.666667%}.offset-md-6{margin-left:50%}.offset-md-7{margin-left:58.333333%}.offset-md-8{margin-left:66.666667%}.offset-md-9{margin-left:75%}.offset-md-10{margin-left:83.333333%}.offset-md-11{margin-left:91.666667%}}@media (min-width:992px){.col-lg{-ms-flex-preferred-size:0;flex-basis:0;-ms-flex-positive:1;flex-grow:1;max-width:100%}.col-lg-auto{-ms-flex:0 0 auto;flex:0 0 auto;width:auto;max-width:none}.col-lg-1{-ms-flex:0 0 8.333333%;flex:0 0 8.333333%;max-width:8.333333%}.col-lg-2{-ms-flex:0 0 16.666667%;flex:0 0 16.666667%;max-width:16.666667%}.col-lg-3{-ms-flex:0 0 25%;flex:0 0 25%;max-width:25%}.col-lg-4{-ms-flex:0 0 33.333333%;flex:0 0 33.333333%;max-width:33.333333%}.col-lg-5{-ms-flex:0 0 41.666667%;flex:0 0 41.666667%;max-width:41.666667%}.col-lg-6{-ms-flex:0 0 50%;flex:0 0 50%;max-width:50%}.col-lg-7{-ms-flex:0 0 58.333333%;flex:0 0 58.333333%;max-width:58.333333%}.col-lg-8{-ms-flex:0 0 66.666667%;flex:0 0 66.666667%;max-width:66.666667%}.col-lg-9{-ms-flex:0 0 75%;flex:0 0 75%;max-width:75%}.col-lg-10{-ms-flex:0 0 83.333333%;flex:0 0 83.333333%;max-width:83.333333%}.col-lg-11{-ms-flex:0 0 91.666667%;flex:0 0 91.666667%;max-width:91.666667%}.col-lg-12{-ms-flex:0 0 100%;flex:0 0 100%;max-width:100%}.order-lg-first{-ms-flex-order:-1;order:-1}.order-lg-last{-ms-flex-order:13;order:13}.order-lg-0{-ms-flex-order:0;order:0}.order-lg-1{-ms-flex-order:1;order:1}.order-lg-2{-ms-flex-order:2;order:2}.order-lg-3{-ms-flex-order:3;order:3}.order-lg-4{-ms-flex-order:4;order:4}.order-lg-5{-ms-flex-order:5;order:5}.order-lg-6{-ms-flex-order:6;order:6}.order-lg-7{-ms-flex-order:7;order:7}.order-lg-8{-ms-flex-order:8;order:8}.order-lg-9{-ms-flex-order:9;order:9}.order-lg-10{-ms-flex-order:10;order:10}.order-lg-11{-ms-flex-order:11;order:11}.order-lg-12{-ms-flex-order:12;order:12}.offset-lg-0{margin-left:0}.offset-lg-1{margin-left:8.333333%}.offset-lg-2{margin-left:16.666667%}.offset-lg-3{margin-left:25%}.offset-lg-4{margin-left:33.333333%}.offset-lg-5{margin-left:41.666667%}.offset-lg-6{margin-left:50%}.offset-lg-7{margin-left:58.333333%}.offset-lg-8{margin-left:66.666667%}.offset-lg-9{margin-left:75%}.offset-lg-10{margin-left:83.333333%}.offset-lg-11{margin-left:91.666667%}}@media (min-width:1200px){.col-xl{-ms-flex-preferred-size:0;flex-basis:0;-ms-flex-positive:1;flex-grow:1;max-width:100%}.col-xl-auto{-ms-flex:0 0 auto;flex:0 0 auto;width:auto;max-width:none}.col-xl-1{-ms-flex:0 0 8.333333%;flex:0 0 8.333333%;max-width:8.333333%}.col-xl-2{-ms-flex:0 0 16.666667%;flex:0 0 16.666667%;max-width:16.666667%}.col-xl-3{-ms-flex:0 0 25%;flex:0 0 25%;max-width:25%}.col-xl-4{-ms-flex:0 0 33.333333%;flex:0 0 33.333333%;max-width:33.333333%}.col-xl-5{-ms-flex:0 0 41.666667%;flex:0 0 41.666667%;max-width:41.666667%}.col-xl-6{-ms-flex:0 0 50%;flex:0 0 50%;max-width:50%}.col-xl-7{-ms-flex:0 0 58.333333%;flex:0 0 58.333333%;max-width:58.333333%}.col-xl-8{-ms-flex:0 0 66.666667%;flex:0 0 66.666667%;max-width:66.666667%}.col-xl-9{-ms-flex:0 0 75%;flex:0 0 75%;max-width:75%}.col-xl-10{-ms-flex:0 0 83.333333%;flex:0 0 83.333333%;max-width:83.333333%}.col-xl-11{-ms-flex:0 0 91.666667%;flex:0 0 91.666667%;max-width:91.666667%}.col-xl-12{-ms-flex:0 0 100%;flex:0 0 100%;max-width:100%}.order-xl-first{-ms-flex-order:-1;order:-1}.order-xl-last{-ms-flex-order:13;order:13}.order-xl-0{-ms-flex-order:0;order:0}.order-xl-1{-ms-flex-order:1;order:1}.order-xl-2{-ms-flex-order:2;order:2}.order-xl-3{-ms-flex-order:3;order:3}.order-xl-4{-ms-flex-order:4;order:4}.order-xl-5{-ms-flex-order:5;order:5}.order-xl-6{-ms-flex-order:6;order:6}.order-xl-7{-ms-flex-order:7;order:7}.order-xl-8{-ms-flex-order:8;order:8}.order-xl-9{-ms-flex-order:9;order:9}.order-xl-10{-ms-flex-order:10;order:10}.order-xl-11{-ms-flex-order:11;order:11}.order-xl-12{-ms-flex-order:12;order:12}.offset-xl-0{margin-left:0}.offset-xl-1{margin-left:8.333333%}.offset-xl-2{margin-left:16.666667%}.offset-xl-3{margin-left:25%}.offset-xl-4{margin-left:33.333333%}.offset-xl-5{margin-left:41.666667%}.offset-xl-6{margin-left:50%}.offset-xl-7{margin-left:58.333333%}.offset-xl-8{margin-left:66.666667%}.offset-xl-9{margin-left:75%}.offset-xl-10{margin-left:83.333333%}.offset-xl-11{margin-left:91.666667%}}.d-none{display:none!important}.d-inline{display:inline!important}.d-inline-block{display:inline-block!important}.d-block{display:block!important}.d-table{display:table!important}.d-table-row{display:table-row!important}.d-table-cell{display:table-cell!important}.d-flex{display:-ms-flexbox!important;display:flex!important}.d-inline-flex{display:-ms-inline-flexbox!important;display:inline-flex!important}@media (min-width:576px){.d-sm-none{display:none!important}.d-sm-inline{display:inline!important}.d-sm-inline-block{display:inline-block!important}.d-sm-block{display:block!important}.d-sm-table{display:table!important}.d-sm-table-row{display:table-row!important}.d-sm-table-cell{display:table-cell!important}.d-sm-flex{display:-ms-flexbox!important;display:flex!important}.d-sm-inline-flex{display:-ms-inline-flexbox!important;display:inline-flex!important}}@media (min-width:768px){.d-md-none{display:none!important}.d-md-inline{display:inline!important}.d-md-inline-block{display:inline-block!important}.d-md-block{display:block!important}.d-md-table{display:table!important}.d-md-table-row{display:table-row!important}.d-md-table-cell{display:table-cell!important}.d-md-flex{display:-ms-flexbox!important;display:flex!important}.d-md-inline-flex{display:-ms-inline-flexbox!important;display:inline-flex!important}}@media (min-width:992px){.d-lg-none{display:none!important}.d-lg-inline{display:inline!important}.d-lg-inline-block{display:inline-block!important}.d-lg-block{display:block!important}.d-lg-table{display:table!important}.d-lg-table-row{display:table-row!important}.d-lg-table-cell{display:table-cell!important}.d-lg-flex{display:-ms-flexbox!important;display:flex!important}.d-lg-inline-flex{display:-ms-inline-flexbox!important;display:inline-flex!important}}@media (min-width:1200px){.d-xl-none{display:none!important}.d-xl-inline{display:inline!important}.d-xl-inline-block{display:inline-block!important}.d-xl-block{display:block!important}.d-xl-table{display:table!important}.d-xl-table-row{display:table-row!important}.d-xl-table-cell{display:table-cell!important}.d-xl-flex{display:-ms-flexbox!important;display:flex!important}.d-xl-inline-flex{display:-ms-inline-flexbox!important;display:inline-flex!important}}@media print{.d-print-none{display:none!important}.d-print-inline{display:inline!important}.d-print-inline-block{display:inline-block!important}.d-print-block{display:block!important}.d-print-table{display:table!important}.d-print-table-row{display:table-row!important}.d-print-table-cell{display:table-cell!important}.d-print-flex{display:-ms-flexbox!important;display:flex!important}.d-print-inline-flex{display:-ms-inline-flexbox!important;display:inline-flex!important}}.flex-row{-ms-flex-direction:row!important;flex-direction:row!important}.flex-column{-ms-flex-direction:column!important;flex-direction:column!important}.flex-row-reverse{-ms-flex-direction:row-reverse!important;flex-direction:row-reverse!important}.flex-column-reverse{-ms-flex-direction:column-reverse!important;flex-direction:column-reverse!important}.flex-wrap{-ms-flex-wrap:wrap!important;flex-wrap:wrap!important}.flex-nowrap{-ms-flex-wrap:nowrap!important;flex-wrap:nowrap!important}.flex-wrap-reverse{-ms-flex-wrap:wrap-reverse!important;flex-wrap:wrap-reverse!important}.flex-fill{-ms-flex:1 1 auto!important;flex:1 1 auto!important}.flex-grow-0{-ms-flex-positive:0!important;flex-grow:0!important}.flex-grow-1{-ms-flex-positive:1!important;flex-grow:1!important}.flex-shrink-0{-ms-flex-negative:0!important;flex-shrink:0!important}.flex-shrink-1{-ms-flex-negative:1!important;flex-shrink:1!important}.justify-content-start{-ms-flex-pack:start!important;justify-content:flex-start!important}.justify-content-end{-ms-flex-pack:end!important;justify-content:flex-end!important}.justify-content-center{-ms-flex-pack:center!important;justify-content:center!important}.justify-content-between{-ms-flex-pack:justify!important;justify-content:space-between!important}.justify-content-around{-ms-flex-pack:distribute!important;justify-content:space-around!important}.align-items-start{-ms-flex-align:start!important;align-items:flex-start!important}.align-items-end{-ms-flex-align:end!important;align-items:flex-end!important}.align-items-center{-ms-flex-align:center!important;align-items:center!important}.align-items-baseline{-ms-flex-align:baseline!important;align-items:baseline!important}.align-items-stretch{-ms-flex-align:stretch!important;align-items:stretch!important}.align-content-start{-ms-flex-line-pack:start!important;align-content:flex-start!important}.align-content-end{-ms-flex-line-pack:end!important;align-content:flex-end!important}.align-content-center{-ms-flex-line-pack:center!important;align-content:center!important}.align-content-between{-ms-flex-line-pack:justify!important;align-content:space-between!important}.align-content-around{-ms-flex-line-pack:distribute!important;align-content:space-around!important}.align-content-stretch{-ms-flex-line-pack:stretch!important;align-content:stretch!important}.align-self-auto{-ms-flex-item-align:auto!important;align-self:auto!important}.align-self-start{-ms-flex-item-align:start!important;align-self:flex-start!important}.align-self-end{-ms-flex-item-align:end!important;align-self:flex-end!important}.align-self-center{-ms-flex-item-align:center!important;align-self:center!important}.align-self-baseline{-ms-flex-item-align:baseline!important;align-self:baseline!important}.align-self-stretch{-ms-flex-item-align:stretch!important;align-self:stretch!important}@media (min-width:576px){.flex-sm-row{-ms-flex-direction:row!important;flex-direction:row!important}.flex-sm-column{-ms-flex-direction:column!important;flex-direction:column!important}.flex-sm-row-reverse{-ms-flex-direction:row-reverse!important;flex-direction:row-reverse!important}.flex-sm-column-reverse{-ms-flex-direction:column-reverse!important;flex-direction:column-reverse!important}.flex-sm-wrap{-ms-flex-wrap:wrap!important;flex-wrap:wrap!important}.flex-sm-nowrap{-ms-flex-wrap:nowrap!important;flex-wrap:nowrap!important}.flex-sm-wrap-reverse{-ms-flex-wrap:wrap-reverse!important;flex-wrap:wrap-reverse!important}.flex-sm-fill{-ms-flex:1 1 auto!important;flex:1 1 auto!important}.flex-sm-grow-0{-ms-flex-positive:0!important;flex-grow:0!important}.flex-sm-grow-1{-ms-flex-positive:1!important;flex-grow:1!important}.flex-sm-shrink-0{-ms-flex-negative:0!important;flex-shrink:0!important}.flex-sm-shrink-1{-ms-flex-negative:1!important;flex-shrink:1!important}.justify-content-sm-start{-ms-flex-pack:start!important;justify-content:flex-start!important}.justify-content-sm-end{-ms-flex-pack:end!important;justify-content:flex-end!important}.justify-content-sm-center{-ms-flex-pack:center!important;justify-content:center!important}.justify-content-sm-between{-ms-flex-pack:justify!important;justify-content:space-between!important}.justify-content-sm-around{-ms-flex-pack:distribute!important;justify-content:space-around!important}.align-items-sm-start{-ms-flex-align:start!important;align-items:flex-start!important}.align-items-sm-end{-ms-flex-align:end!important;align-items:flex-end!important}.align-items-sm-center{-ms-flex-align:center!important;align-items:center!important}.align-items-sm-baseline{-ms-flex-align:baseline!important;align-items:baseline!important}.align-items-sm-stretch{-ms-flex-align:stretch!important;align-items:stretch!important}.align-content-sm-start{-ms-flex-line-pack:start!important;align-content:flex-start!important}.align-content-sm-end{-ms-flex-line-pack:end!important;align-content:flex-end!important}.align-content-sm-center{-ms-flex-line-pack:center!important;align-content:center!important}.align-content-sm-between{-ms-flex-line-pack:justify!important;align-content:space-between!important}.align-content-sm-around{-ms-flex-line-pack:distribute!important;align-content:space-around!important}.align-content-sm-stretch{-ms-flex-line-pack:stretch!important;align-content:stretch!important}.align-self-sm-auto{-ms-flex-item-align:auto!important;align-self:auto!important}.align-self-sm-start{-ms-flex-item-align:start!important;align-self:flex-start!important}.align-self-sm-end{-ms-flex-item-align:end!important;align-self:flex-end!important}.align-self-sm-center{-ms-flex-item-align:center!important;align-self:center!important}.align-self-sm-baseline{-ms-flex-item-align:baseline!important;align-self:baseline!important}.align-self-sm-stretch{-ms-flex-item-align:stretch!important;align-self:stretch!important}}@media (min-width:768px){.flex-md-row{-ms-flex-direction:row!important;flex-direction:row!important}.flex-md-column{-ms-flex-direction:column!important;flex-direction:column!important}.flex-md-row-reverse{-ms-flex-direction:row-reverse!important;flex-direction:row-reverse!important}.flex-md-column-reverse{-ms-flex-direction:column-reverse!important;flex-direction:column-reverse!important}.flex-md-wrap{-ms-flex-wrap:wrap!important;flex-wrap:wrap!important}.flex-md-nowrap{-ms-flex-wrap:nowrap!important;flex-wrap:nowrap!important}.flex-md-wrap-reverse{-ms-flex-wrap:wrap-reverse!important;flex-wrap:wrap-reverse!important}.flex-md-fill{-ms-flex:1 1 auto!important;flex:1 1 auto!important}.flex-md-grow-0{-ms-flex-positive:0!important;flex-grow:0!important}.flex-md-grow-1{-ms-flex-positive:1!important;flex-grow:1!important}.flex-md-shrink-0{-ms-flex-negative:0!important;flex-shrink:0!important}.flex-md-shrink-1{-ms-flex-negative:1!important;flex-shrink:1!important}.justify-content-md-start{-ms-flex-pack:start!important;justify-content:flex-start!important}.justify-content-md-end{-ms-flex-pack:end!important;justify-content:flex-end!important}.justify-content-md-center{-ms-flex-pack:center!important;justify-content:center!important}.justify-content-md-between{-ms-flex-pack:justify!important;justify-content:space-between!important}.justify-content-md-around{-ms-flex-pack:distribute!important;justify-content:space-around!important}.align-items-md-start{-ms-flex-align:start!important;align-items:flex-start!important}.align-items-md-end{-ms-flex-align:end!important;align-items:flex-end!important}.align-items-md-center{-ms-flex-align:center!important;align-items:center!important}.align-items-md-baseline{-ms-flex-align:baseline!important;align-items:baseline!important}.align-items-md-stretch{-ms-flex-align:stretch!important;align-items:stretch!important}.align-content-md-start{-ms-flex-line-pack:start!important;align-content:flex-start!important}.align-content-md-end{-ms-flex-line-pack:end!important;align-content:flex-end!important}.align-content-md-center{-ms-flex-line-pack:center!important;align-content:center!important}.align-content-md-between{-ms-flex-line-pack:justify!important;align-content:space-between!important}.align-content-md-around{-ms-flex-line-pack:distribute!important;align-content:space-around!important}.align-content-md-stretch{-ms-flex-line-pack:stretch!important;align-content:stretch!important}.align-self-md-auto{-ms-flex-item-align:auto!important;align-self:auto!important}.align-self-md-start{-ms-flex-item-align:start!important;align-self:flex-start!important}.align-self-md-end{-ms-flex-item-align:end!important;align-self:flex-end!important}.align-self-md-center{-ms-flex-item-align:center!important;align-self:center!important}.align-self-md-baseline{-ms-flex-item-align:baseline!important;align-self:baseline!important}.align-self-md-stretch{-ms-flex-item-align:stretch!important;align-self:stretch!important}}@media (min-width:992px){.flex-lg-row{-ms-flex-direction:row!important;flex-direction:row!important}.flex-lg-column{-ms-flex-direction:column!important;flex-direction:column!important}.flex-lg-row-reverse{-ms-flex-direction:row-reverse!important;flex-direction:row-reverse!important}.flex-lg-column-reverse{-ms-flex-direction:column-reverse!important;flex-direction:column-reverse!important}.flex-lg-wrap{-ms-flex-wrap:wrap!important;flex-wrap:wrap!important}.flex-lg-nowrap{-ms-flex-wrap:nowrap!important;flex-wrap:nowrap!important}.flex-lg-wrap-reverse{-ms-flex-wrap:wrap-reverse!important;flex-wrap:wrap-reverse!important}.flex-lg-fill{-ms-flex:1 1 auto!important;flex:1 1 auto!important}.flex-lg-grow-0{-ms-flex-positive:0!important;flex-grow:0!important}.flex-lg-grow-1{-ms-flex-positive:1!important;flex-grow:1!important}.flex-lg-shrink-0{-ms-flex-negative:0!important;flex-shrink:0!important}.flex-lg-shrink-1{-ms-flex-negative:1!important;flex-shrink:1!important}.justify-content-lg-start{-ms-flex-pack:start!important;justify-content:flex-start!important}.justify-content-lg-end{-ms-flex-pack:end!important;justify-content:flex-end!important}.justify-content-lg-center{-ms-flex-pack:center!important;justify-content:center!important}.justify-content-lg-between{-ms-flex-pack:justify!important;justify-content:space-between!important}.justify-content-lg-around{-ms-flex-pack:distribute!important;justify-content:space-around!important}.align-items-lg-start{-ms-flex-align:start!important;align-items:flex-start!important}.align-items-lg-end{-ms-flex-align:end!important;align-items:flex-end!important}.align-items-lg-center{-ms-flex-align:center!important;align-items:center!important}.align-items-lg-baseline{-ms-flex-align:baseline!important;align-items:baseline!important}.align-items-lg-stretch{-ms-flex-align:stretch!important;align-items:stretch!important}.align-content-lg-start{-ms-flex-line-pack:start!important;align-content:flex-start!important}.align-content-lg-end{-ms-flex-line-pack:end!important;align-content:flex-end!important}.align-content-lg-center{-ms-flex-line-pack:center!important;align-content:center!important}.align-content-lg-between{-ms-flex-line-pack:justify!important;align-content:space-between!important}.align-content-lg-around{-ms-flex-line-pack:distribute!important;align-content:space-around!important}.align-content-lg-stretch{-ms-flex-line-pack:stretch!important;align-content:stretch!important}.align-self-lg-auto{-ms-flex-item-align:auto!important;align-self:auto!important}.align-self-lg-start{-ms-flex-item-align:start!important;align-self:flex-start!important}.align-self-lg-end{-ms-flex-item-align:end!important;align-self:flex-end!important}.align-self-lg-center{-ms-flex-item-align:center!important;align-self:center!important}.align-self-lg-baseline{-ms-flex-item-align:baseline!important;align-self:baseline!important}.align-self-lg-stretch{-ms-flex-item-align:stretch!important;align-self:stretch!important}}@media (min-width:1200px){.flex-xl-row{-ms-flex-direction:row!important;flex-direction:row!important}.flex-xl-column{-ms-flex-direction:column!important;flex-direction:column!important}.flex-xl-row-reverse{-ms-flex-direction:row-reverse!important;flex-direction:row-reverse!important}.flex-xl-column-reverse{-ms-flex-direction:column-reverse!important;flex-direction:column-reverse!important}.flex-xl-wrap{-ms-flex-wrap:wrap!important;flex-wrap:wrap!important}.flex-xl-nowrap{-ms-flex-wrap:nowrap!important;flex-wrap:nowrap!important}.flex-xl-wrap-reverse{-ms-flex-wrap:wrap-reverse!important;flex-wrap:wrap-reverse!important}.flex-xl-fill{-ms-flex:1 1 auto!important;flex:1 1 auto!important}.flex-xl-grow-0{-ms-flex-positive:0!important;flex-grow:0!important}.flex-xl-grow-1{-ms-flex-positive:1!important;flex-grow:1!important}.flex-xl-shrink-0{-ms-flex-negative:0!important;flex-shrink:0!important}.flex-xl-shrink-1{-ms-flex-negative:1!important;flex-shrink:1!important}.justify-content-xl-start{-ms-flex-pack:start!important;justify-content:flex-start!important}.justify-content-xl-end{-ms-flex-pack:end!important;justify-content:flex-end!important}.justify-content-xl-center{-ms-flex-pack:center!important;justify-content:center!important}.justify-content-xl-between{-ms-flex-pack:justify!important;justify-content:space-between!important}.justify-content-xl-around{-ms-flex-pack:distribute!important;justify-content:space-around!important}.align-items-xl-start{-ms-flex-align:start!important;align-items:flex-start!important}.align-items-xl-end{-ms-flex-align:end!important;align-items:flex-end!important}.align-items-xl-center{-ms-flex-align:center!important;align-items:center!important}.align-items-xl-baseline{-ms-flex-align:baseline!important;align-items:baseline!important}.align-items-xl-stretch{-ms-flex-align:stretch!important;align-items:stretch!important}.align-content-xl-start{-ms-flex-line-pack:start!important;align-content:flex-start!important}.align-content-xl-end{-ms-flex-line-pack:end!important;align-content:flex-end!important}.align-content-xl-center{-ms-flex-line-pack:center!important;align-content:center!important}.align-content-xl-between{-ms-flex-line-pack:justify!important;align-content:space-between!important}.align-content-xl-around{-ms-flex-line-pack:distribute!important;align-content:space-around!important}.align-content-xl-stretch{-ms-flex-line-pack:stretch!important;align-content:stretch!important}.align-self-xl-auto{-ms-flex-item-align:auto!important;align-self:auto!important}.align-self-xl-start{-ms-flex-item-align:start!important;align-self:flex-start!important}.align-self-xl-end{-ms-flex-item-align:end!important;align-self:flex-end!important}.align-self-xl-center{-ms-flex-item-align:center!important;align-self:center!important}.align-self-xl-baseline{-ms-flex-item-align:baseline!important;align-self:baseline!important}.align-self-xl-stretch{-ms-flex-item-align:stretch!important;align-self:stretch!important}}

{# /* // Swiper 4.4.2 */ #}
.swiper-container{width:100%;margin:0 auto;position:relative;overflow:hidden;list-style:none;padding:0;z-index:1}.swiper-container-no-flexbox .swiper-slide{float:left}.swiper-container-vertical>.swiper-wrapper{-webkit-box-orient:vertical;-webkit-box-direction:normal;-webkit-flex-direction:column;-ms-flex-direction:column;flex-direction:column}.swiper-wrapper{position:relative;width:100%;height:100%;z-index:1;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-transition-property:-webkit-transform;transition-property:-webkit-transform;-o-transition-property:transform;transition-property:transform;transition-property:transform,-webkit-transform}.swiper-container-android .swiper-slide,.swiper-wrapper{-webkit-transform:translate3d(0,0,0);transform:translate3d(0,0,0)}.swiper-container-multirow>.swiper-wrapper{-webkit-flex-wrap:wrap;-ms-flex-wrap:wrap;flex-wrap:wrap}.swiper-container-free-mode>.swiper-wrapper{-webkit-transition-timing-function:ease-out;-o-transition-timing-function:ease-out;transition-timing-function:ease-out;margin:0 auto}.swiper-slide{-webkit-flex-shrink:0;-ms-flex-negative:0;flex-shrink:0;width:100%;height:100%;position:relative;-webkit-transition-property:-webkit-transform;transition-property:-webkit-transform;-o-transition-property:transform;transition-property:transform;transition-property:transform,-webkit-transform}.swiper-slide-invisible-blank{visibility:hidden}.swiper-container-autoheight,.swiper-container-autoheight .swiper-slide{height:auto}.swiper-container-autoheight .swiper-wrapper{-webkit-box-align:start;-webkit-align-items:flex-start;-ms-flex-align:start;align-items:flex-start;-webkit-transition-property:height,-webkit-transform;transition-property:height,-webkit-transform;-o-transition-property:transform,height;transition-property:transform,height;transition-property:transform,height,-webkit-transform}.swiper-container-3d{-webkit-perspective:1200px;perspective:1200px}.swiper-container-3d .swiper-cube-shadow,.swiper-container-3d .swiper-slide,.swiper-container-3d .swiper-slide-shadow-bottom,.swiper-container-3d .swiper-slide-shadow-left,.swiper-container-3d .swiper-slide-shadow-right,.swiper-container-3d .swiper-slide-shadow-top,.swiper-container-3d .swiper-wrapper{-webkit-transform-style:preserve-3d;transform-style:preserve-3d}.swiper-container-3d .swiper-slide-shadow-bottom,.swiper-container-3d .swiper-slide-shadow-left,.swiper-container-3d .swiper-slide-shadow-right,.swiper-container-3d .swiper-slide-shadow-top{position:absolute;left:0;top:0;width:100%;height:100%;pointer-events:none;z-index:10}.swiper-container-3d .swiper-slide-shadow-left{background-image:-webkit-gradient(linear,right top,left top,from(rgba(0,0,0,.5)),to(rgba(0,0,0,0)));background-image:-webkit-linear-gradient(right,rgba(0,0,0,.5),rgba(0,0,0,0));background-image:-o-linear-gradient(right,rgba(0,0,0,.5),rgba(0,0,0,0));background-image:linear-gradient(to left,rgba(0,0,0,.5),rgba(0,0,0,0))}.swiper-container-3d .swiper-slide-shadow-right{background-image:-webkit-gradient(linear,left top,right top,from(rgba(0,0,0,.5)),to(rgba(0,0,0,0)));background-image:-webkit-linear-gradient(left,rgba(0,0,0,.5),rgba(0,0,0,0));background-image:-o-linear-gradient(left,rgba(0,0,0,.5),rgba(0,0,0,0));background-image:linear-gradient(to right,rgba(0,0,0,.5),rgba(0,0,0,0))}.swiper-container-3d .swiper-slide-shadow-top{background-image:-webkit-gradient(linear,left bottom,left top,from(rgba(0,0,0,.5)),to(rgba(0,0,0,0)));background-image:-webkit-linear-gradient(bottom,rgba(0,0,0,.5),rgba(0,0,0,0));background-image:-o-linear-gradient(bottom,rgba(0,0,0,.5),rgba(0,0,0,0));background-image:linear-gradient(to top,rgba(0,0,0,.5),rgba(0,0,0,0))}.swiper-container-3d .swiper-slide-shadow-bottom{background-image:-webkit-gradient(linear,left top,left bottom,from(rgba(0,0,0,.5)),to(rgba(0,0,0,0)));background-image:-webkit-linear-gradient(top,rgba(0,0,0,.5),rgba(0,0,0,0));background-image:-o-linear-gradient(top,rgba(0,0,0,.5),rgba(0,0,0,0));background-image:linear-gradient(to bottom,rgba(0,0,0,.5),rgba(0,0,0,0))}.swiper-container-wp8-horizontal,.swiper-container-wp8-horizontal>.swiper-wrapper{-ms-touch-action:pan-y;touch-action:pan-y}.swiper-container-wp8-vertical,.swiper-container-wp8-vertical>.swiper-wrapper{-ms-touch-action:pan-x;touch-action:pan-x}.swiper-button-next,.swiper-button-prev{position:absolute;top:50%;z-index:10;width:30px;height:40px;margin-top:-25px;line-height:40px;color:#fff;text-align:center;cursor:pointer}.swiper-button-next.swiper-button-disabled,.swiper-button-prev.swiper-button-disabled{opacity:0;cursor:auto}.swiper-button-prev,.swiper-container-rtl .swiper-button-next{left:20px;right:auto}.swiper-button-next,.swiper-container-rtl .swiper-button-prev{right:20px;left:auto}.swiper-button-lock{display:none}.swiper-pagination{position:absolute;text-align:center;-webkit-transition:.3s opacity;-o-transition:.3s opacity;transition:.3s opacity;-webkit-transform:translate3d(0,0,0);transform:translate3d(0,0,0);z-index:10}.swiper-pagination.swiper-pagination-hidden{opacity:0}.swiper-container-horizontal>.swiper-pagination-bullets,.swiper-pagination-custom,.swiper-pagination-fraction{bottom:20px;left:0;width:100%}.swiper-pagination-bullets-dynamic{overflow:hidden;font-size:0}.swiper-pagination-bullets-dynamic .swiper-pagination-bullet{-webkit-transform:scale(.33);-ms-transform:scale(.33);transform:scale(.33);position:relative}.swiper-pagination-bullets-dynamic .swiper-pagination-bullet-active{-webkit-transform:scale(1);-ms-transform:scale(1);transform:scale(1)}.swiper-pagination-bullets-dynamic .swiper-pagination-bullet-active-main{-webkit-transform:scale(1);-ms-transform:scale(1);transform:scale(1)}.swiper-pagination-bullets-dynamic .swiper-pagination-bullet-active-prev{-webkit-transform:scale(.66);-ms-transform:scale(.66);transform:scale(.66)}.swiper-pagination-bullets-dynamic .swiper-pagination-bullet-active-prev-prev{-webkit-transform:scale(.33);-ms-transform:scale(.33);transform:scale(.33)}.swiper-pagination-bullets-dynamic .swiper-pagination-bullet-active-next{-webkit-transform:scale(.66);-ms-transform:scale(.66);transform:scale(.66)}.swiper-pagination-bullets-dynamic .swiper-pagination-bullet-active-next-next{-webkit-transform:scale(.33);-ms-transform:scale(.33);transform:scale(.33)}.swiper-pagination-bullet{width:8px;height:8px;display:inline-block;border-radius:100%;background:#000;opacity:.2}button.swiper-pagination-bullet{border:none;margin:0;padding:0;-webkit-box-shadow:none;box-shadow:none;-webkit-appearance:none;-moz-appearance:none;appearance:none}.swiper-pagination-clickable .swiper-pagination-bullet{cursor:pointer}.swiper-pagination-bullet-active{opacity:1;background:#007aff}.swiper-container-vertical>.swiper-pagination-bullets{right:10px;top:50%;-webkit-transform:translate3d(0,-50%,0);transform:translate3d(0,-50%,0)}.swiper-container-vertical>.swiper-pagination-bullets .swiper-pagination-bullet{margin:6px 0;display:block}.swiper-container-vertical>.swiper-pagination-bullets.swiper-pagination-bullets-dynamic{top:50%;-webkit-transform:translateY(-50%);-ms-transform:translateY(-50%);transform:translateY(-50%);width:8px}.swiper-container-vertical>.swiper-pagination-bullets.swiper-pagination-bullets-dynamic .swiper-pagination-bullet{display:inline-block;-webkit-transition:.2s top,.2s -webkit-transform;transition:.2s top,.2s -webkit-transform;-o-transition:.2s transform,.2s top;transition:.2s transform,.2s top;transition:.2s transform,.2s top,.2s -webkit-transform}.swiper-container-horizontal>.swiper-pagination-bullets .swiper-pagination-bullet{margin:0 4px}.swiper-container-horizontal>.swiper-pagination-bullets.swiper-pagination-bullets-dynamic{left:50%;-webkit-transform:translateX(-50%);-ms-transform:translateX(-50%);transform:translateX(-50%);white-space:nowrap}.swiper-container-horizontal>.swiper-pagination-bullets.swiper-pagination-bullets-dynamic .swiper-pagination-bullet{-webkit-transition:.2s left,.2s -webkit-transform;transition:.2s left,.2s -webkit-transform;-o-transition:.2s transform,.2s left;transition:.2s transform,.2s left;transition:.2s transform,.2s left,.2s -webkit-transform}.swiper-container-horizontal.swiper-container-rtl>.swiper-pagination-bullets-dynamic .swiper-pagination-bullet{-webkit-transition:.2s right,.2s -webkit-transform;transition:.2s right,.2s -webkit-transform;-o-transition:.2s transform,.2s right;transition:.2s transform,.2s right;transition:.2s transform,.2s right,.2s -webkit-transform}.swiper-pagination-progressbar{background:rgba(0,0,0,.25);position:absolute}.swiper-pagination-progressbar .swiper-pagination-progressbar-fill{background:#007aff;position:absolute;left:0;top:0;width:100%;height:100%;-webkit-transform:scale(0);-ms-transform:scale(0);transform:scale(0);-webkit-transform-origin:left top;-ms-transform-origin:left top;transform-origin:left top}.swiper-container-rtl .swiper-pagination-progressbar .swiper-pagination-progressbar-fill{-webkit-transform-origin:right top;-ms-transform-origin:right top;transform-origin:right top}.swiper-container-horizontal>.swiper-pagination-progressbar,.swiper-container-vertical>.swiper-pagination-progressbar.swiper-pagination-progressbar-opposite{width:100%;height:4px;left:0;top:0}.swiper-container-horizontal>.swiper-pagination-progressbar.swiper-pagination-progressbar-opposite,.swiper-container-vertical>.swiper-pagination-progressbar{width:4px;height:100%;left:0;top:0}.swiper-pagination-white .swiper-pagination-bullet-active{background:#fff}.swiper-pagination-progressbar.swiper-pagination-white{background:rgba(255,255,255,.25)}.swiper-pagination-progressbar.swiper-pagination-white .swiper-pagination-progressbar-fill{background:#fff}.swiper-pagination-black .swiper-pagination-bullet-active{background:#000}.swiper-pagination-progressbar.swiper-pagination-black{background:rgba(0,0,0,.25)}.swiper-pagination-progressbar.swiper-pagination-black .swiper-pagination-progressbar-fill{background:#000}.swiper-pagination-lock{display:none}.swiper-lazy-preloader{width:42px;height:42px;position:absolute;left:50%;top:50%;margin-left:-21px;margin-top:-21px;z-index:10;-webkit-transform-origin:50%;-ms-transform-origin:50%;transform-origin:50%;-webkit-animation:swiper-preloader-spin 1s steps(12,end) infinite;animation:swiper-preloader-spin 1s steps(12,end) infinite}.swiper-lazy-preloader:after{display:block;content:'';width:100%;height:100%;background-image:url("data:image/svg+xml;charset=utf-8,%3Csvg%20viewBox%3D'0%200%20120%20120'%20xmlns%3D'http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg'%20xmlns%3Axlink%3D'http%3A%2F%2Fwww.w3.org%2F1999%2Fxlink'%3E%3Cdefs%3E%3Cline%20id%3D'l'%20x1%3D'60'%20x2%3D'60'%20y1%3D'7'%20y2%3D'27'%20stroke%3D'%236c6c6c'%20stroke-width%3D'11'%20stroke-linecap%3D'round'%2F%3E%3C%2Fdefs%3E%3Cg%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.27'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.27'%20transform%3D'rotate(30%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.27'%20transform%3D'rotate(60%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.27'%20transform%3D'rotate(90%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.27'%20transform%3D'rotate(120%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.27'%20transform%3D'rotate(150%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.37'%20transform%3D'rotate(180%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.46'%20transform%3D'rotate(210%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.56'%20transform%3D'rotate(240%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.66'%20transform%3D'rotate(270%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.75'%20transform%3D'rotate(300%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.85'%20transform%3D'rotate(330%2060%2C60)'%2F%3E%3C%2Fg%3E%3C%2Fsvg%3E");background-position:50%;background-size:100%;background-repeat:no-repeat}.swiper-lazy-preloader-white:after{background-image:url("data:image/svg+xml;charset=utf-8,%3Csvg%20viewBox%3D'0%200%20120%20120'%20xmlns%3D'http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg'%20xmlns%3Axlink%3D'http%3A%2F%2Fwww.w3.org%2F1999%2Fxlink'%3E%3Cdefs%3E%3Cline%20id%3D'l'%20x1%3D'60'%20x2%3D'60'%20y1%3D'7'%20y2%3D'27'%20stroke%3D'%23fff'%20stroke-width%3D'11'%20stroke-linecap%3D'round'%2F%3E%3C%2Fdefs%3E%3Cg%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.27'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.27'%20transform%3D'rotate(30%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.27'%20transform%3D'rotate(60%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.27'%20transform%3D'rotate(90%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.27'%20transform%3D'rotate(120%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.27'%20transform%3D'rotate(150%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.37'%20transform%3D'rotate(180%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.46'%20transform%3D'rotate(210%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.56'%20transform%3D'rotate(240%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.66'%20transform%3D'rotate(270%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.75'%20transform%3D'rotate(300%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.85'%20transform%3D'rotate(330%2060%2C60)'%2F%3E%3C%2Fg%3E%3C%2Fsvg%3E")}@-webkit-keyframes swiper-preloader-spin{100%{-webkit-transform:rotate(360deg);transform:rotate(360deg)}}@keyframes swiper-preloader-spin{100%{-webkit-transform:rotate(360deg);transform:rotate(360deg)}}.swiper-container-fade.swiper-container-free-mode .swiper-slide{-webkit-transition-timing-function:ease-out;-o-transition-timing-function:ease-out;transition-timing-function:ease-out}.swiper-container-fade .swiper-slide{pointer-events:none;-webkit-transition-property:opacity;-o-transition-property:opacity;transition-property:opacity}.swiper-container-fade .swiper-slide .swiper-slide{pointer-events:none}.swiper-container-fade .swiper-slide-active,.swiper-container-fade .swiper-slide-active .swiper-slide-active{pointer-events:auto}

/*============================================================================
  #Critical path helpers
==============================================================================*/

/* Hidden general content until rest of styling loads */
.visible-when-content-ready{
	visibility: hidden!important;
}
.display-when-content-ready{
	display: none!important;
}

/*============================================================================
  #Components
==============================================================================*/

{# /* // Wrappers */ #}

body{
  margin: 0;
  font-size: 12px;
}

{# /* // Placeholders and preloaders */ #}

.placeholder-line-medium{
  height: 25px;
  border-radius: 6px;
}
.placeholder-icon{
  position: absolute;
  top: 50%;
  left: 50%;
  width: 25%;
  transform: translate(-50%, -50%);
  -webkit-transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
} 
.placeholder-full-height{
  position: relative;
  height: 100%;
}
.home-placeholder-icons{
  position: absolute;
  top: calc(50% - 75px);
}
.product-placeholder-container{
  position: relative;
  max-height: 900px;
  margin-bottom: 20px;
  overflow: hidden;
}
.placeholder-shine{
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  opacity: 0.5;
  -moz-animation: placeholder-shine 1.5s infinite;
  -webkit-animation: placeholder-shine 1.5s infinite;
  animation: placeholder-shine 1.5s infinite;
}
@keyframes placeholder-shine {
  0%{
    opacity: 0.1;
  }
  50% {
    opacity: 0.5;
  }
  100% {
    opacity: 0.1;
  }
}
.placeholder-fade{
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  opacity: 0.1;
  -moz-animation: placeholder-fade 1.5s infinite;
  -webkit-animation: placeholder-fade 1.5s infinite;
  animation: placeholder-fade 1.5s infinite;
}
@keyframes placeholder-fade {
  0%{
    opacity: 0.2;
  }
  50% {
    opacity: 0.3;
  }
  100% {
    opacity: 0.2;
  }
}
.blur-up {
  position: absolute;
  top: 0;
  -webkit-filter: blur(4px);
  filter: blur(4px);
  -moz-filter: blur(4px);
  -ms-filter: blur(4px);
  -o-filter: blur(4px);
  transition: opacity .2s, -webkit-filter .2s;
}
.blur-up-huge {
  -webkit-filter: blur(6px);
  filter: blur(6px);
  -moz-filter: blur(6px);
  -ms-filter: blur(6px);
  -o-filter: blur(6px);
  transition: filter .2s, -webkit-filter .2s;
}
.blur-up.lazyloaded,
.blur-up-huge.lazyloaded,
.blur-up.swiper-lazy-loaded,
.blur-up-huge.swiper-lazy-loaded {
  -webkit-filter: none;
  filter: none;
  -moz-filter: none;
  -ms-filter: none;
  -o-filter: none;
}
.preloader-bg-img,
.product-slider-image.blur-up{
  position: absolute;
  left: 0;
  top: 0;
  width: 100%;
  -webkit-filter: blur(4px);
  filter: blur(4px);
  -moz-filter: blur(4px);
  -ms-filter: blur(4px);
  -o-filter: blur(4px);
  transition: filter .2s, -webkit-filter .2s, opacity .2s;
  /* Avoid strange image behaviour on filters in IOS */
  -webkit-perspective: 1000;
  -webkit-backface-visibility: hidden;
}
.product-slider-image.blur-up{
  left: 50%;
  width: auto;
}
.swiper-lazy-loaded + .preloader-bg-img,
.lazyloaded + .blur-up{
  opacity: 0;
  -webkit-filter: none;
  filter: none;
  -moz-filter: none;
  -ms-filter: none;
  -o-filter: none;
}

.lazyloaded + .blur-up {
  opacity: 0;
  pointer-events: none;
}
.lazyloaded + .placeholder-shine,
.lazyloaded + .placeholder-fade{
  display: none;
}
.fade-in {
  opacity: 0;
  transition: opacity .2s;
}
.fade-in.lazyloaded {
  opacity: 1;
}

.spinner-ellipsis {
  display: inline-block;
  position: relative;
  width: 64px;
  height: 40px;
}
.spinner-ellipsis.btn-ellipsis{
  height: 14px;
}
.spinner-ellipsis .point {
  position: absolute;
  top: 15px;
  width: 11px;
  height: 11px;
  border-radius: 50%;
  animation-timing-function: cubic-bezier(0, 1, 1, 0);
}
.spinner-ellipsis.btn-ellipsis .point{
  top: 3px;
}
.spinner-ellipsis .point:nth-child(1) {
  left: 6px;
  animation: spinner-ellipsis1 0.6s infinite;
}
.spinner-ellipsis .point:nth-child(2) {
  left: 6px;
  animation: spinner-ellipsis2 0.6s infinite;
}
.spinner-ellipsis .point:nth-child(3) {
  left: 26px;
  animation: spinner-ellipsis2 0.6s infinite;
}
.spinner-ellipsis .point:nth-child(4) {
  left: 45px;
  animation: spinner-ellipsis3 0.6s infinite;
}
@keyframes spinner-ellipsis1 {
  0% {
    transform: scale(0);
  }
  100% {
    transform: scale(1);
  }
}
@keyframes spinner-ellipsis3 {
  0% {
    transform: scale(1);
  }
  100% {
    transform: scale(0);
  }
}
@keyframes spinner-ellipsis2 {
  0% {
    transform: translate(0, 0);
  }
  100% {
    transform: translate(19px, 0);
  }
}

{# /* // Animations*/ #}

.transition-up,
.fade-in-vertical {
  opacity: 0;
}


{# /* // Buttons */ #}

.btn-whatsapp {
  position: fixed;
  bottom: 10px;
  right: 10px;
  z-index: 100;
  color: white;
  background-color:#4dc247;
  box-shadow: 2px 2px 6px rgba(0,0,0,0.4);
  border-radius: 50%;
}

.btn-whatsapp svg{
  width: 45px;
  height: 45px;
  padding: 10px;
  fill: white;
  vertical-align:middle;
}

{# /* // Links */ #}

a {
  text-decoration: none;
}


{# /* // Icons */ #}

.icon-inline {
  display: inline-block;
  font-size: inherit;
  width: 1em;
  height: 1em;
  overflow: visible;
  vertical-align: -.125em;
}

.icon-xs {
  font-size: .75em;
}
.icon-md  {
  font-size: .875em; 
}
.icon-lg {
  font-size: 1.33333em;
  line-height: .75em;
  vertical-align: -.0667em; 
}
.icon-2x {
  font-size: 2em;  
}
.icon-2x-half {
  font-size: 2.5em; 
}
.icon-3x {
  font-size: 3em; 
}
.icon-4x {
  font-size: 4em;  
}
.icon-5x {
  font-size: 5em;  
}
.icon-6x {
  font-size: 6em;  
}
.icon-7x {
  font-size: 7em; 
}
.icon-8x {
  font-size: 8em;  
}
.icon-9x {
  font-size: 9em;  
}

.icon-inline.icon-lg{
  vertical-align: -.225em
}
.icon-inline.icon-w {
  text-align: center;
  width: 1.25em
}
.icon-inline.icon-w-1{
  width:.0625em
}
.icon-inline.icon-w-2{
  width:.125em
}
.icon-inline.icon-w-3{
  width:.1875em
}
.icon-inline.icon-w-4{
  width:.25em
}
.icon-inline.icon-w-5{
  width:.3125em
}
.icon-inline.icon-w-6{
  width:.375em
}
.icon-inline.icon-w-7{
  width:.4375em
}
.icon-inline.icon-w-8{
  width:.5em
}
.icon-inline.icon-w-9{
  width:.5625em
}
.icon-inline.icon-w-10{
  width:.625em
}
.icon-inline.icon-w-11{
  width:.6875em
}
.icon-inline.icon-w-12{
  width:.75em
}
.icon-inline.icon-w-13{
  width:.8125em
}
.icon-inline.icon-w-14{
  width:.875em
}
.icon-inline.icon-w-15{
  width:.9375em
}
.icon-inline.icon-w-16{
  width:1em
}
.icon-inline.icon-w-17{
  width:1.0625em
}
.icon-inline.icon-w-18{
  width:1.125em
}
.icon-inline.icon-w-19{
  width:1.1875em
}
.icon-inline.icon-w-20{
  width:1.25em
}
.icon-flip-horizontal {
  transform: scaleX(-1);
}
.icon-flip-vertical {
  transform: scaleY(-1);
}
.icon-spin{
  -webkit-animation:icon-spin .5s infinite linear;
  animation:icon-spin .5s infinite linear
}
@-webkit-keyframes icon-spin {
  0% {
    -webkit-transform: rotate(0);
    transform: rotate(0)
  }
  100% {
    -webkit-transform: rotate(360deg);
    transform: rotate(360deg)
  }
}

@keyframes icon-spin {
  0% {
    -webkit-transform: rotate(0);
    transform: rotate(0)
  }
  100% {
    -webkit-transform: rotate(360deg);
    transform: rotate(360deg)
  }
}

.social-icon {
  padding: 0 7px;
}

{# /* // Titles and breadcrumbs */ #}

h1,
.h1 {
  font-size: 34px;
  font-weight: 700;
}

h2,
.h2 {
  font-size: 28px;
  font-weight: 700;
}

h3,
.h3 {
  font-size: 20px;
  font-weight: 700;
}

h4,
.h4 {
  font-size: 18px;
  font-weight: 700;
}

h5,
.h5 {
  font-size: 16px;
  font-weight: 700;
}

h6,
.h6 {
  font-size: 14px;
  font-weight: 700;
}

.breadcrumbs .crumb {
  display: inline-block;
  margin: 0;
  font-size: 14px;
  font-weight: 400;
}

{# /* // Texts */ #}

.font-big{
  font-size: 16px;
}

.font-body{
  font-size: 14px;
}

.font-small{
  font-size: 12px;
}

.font-smallest{
  font-size: 10px!important;
}

p{
  margin-top: 0;
  line-height: 20px;
}

.user-content ul {
  padding-left: 20px;
}

.user-content ul li {
  margin-bottom: 10px;
  line-height: 22px;
}

.user-content table {
  width: 100%;
  max-width: 100%;
  margin-bottom: 10px;
  line-height: 22px;
}

{# /* // Sliders */ #}

.section-slider {
  height: 60vh;
}
.section-slider-auto {
  height: auto;
}
.nube-slider-home {
  height: 100%;
}
.swiper-wrapper.disabled {
  transform: translate3d(0px, 0, 0) !important;
}
.slide-container{
  overflow: hidden;
}
.slider-slide {
  height: 100%;
  background-position: center;
  background-size: cover; 
  overflow: hidden;
}
.slider-image {
  height: 100%;
  width: 100%;
  object-fit: cover;
}
.swiper-pagination-fraction{
  position: relative;
  width: 100%;
  padding: 20px 0;
}
.swiper-pagination-fraction .swiper-pagination-current{
  opacity: 0.8;
}

.slider-slide-empty {
  display: block;
  width: 100%;
  background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 1440 770'><rect width='1440' height='770' fill='%23fcfcfc'/><path d='M852.28,303.08a17.11,17.11,0,0,0-11.62-6.15l-80.84-7.56-10.51-46a17.22,17.22,0,0,0-20.6-12.91l-152.45,34.5a17.19,17.19,0,0,0-13,20.51L599.57,444.3a17.22,17.22,0,0,0,20.6,12.91L652.06,450l-1,10.19a17.23,17.23,0,0,0,15.52,18.68l155.54,14.56c.55.05,1.09.07,1.62.07A17.19,17.19,0,0,0,840.89,478l2.76-29.35a1,1,0,0,0,.17-1.77l12.35-131.22A17,17,0,0,0,852.28,303.08ZM567.2,273.61a15.08,15.08,0,0,1,9.5-6.73l152.45-34.5a15.22,15.22,0,0,1,18.21,11.4l10.37,45.39-72.61-6.79a17.21,17.21,0,0,0-18.74,15.47l-1.59,16.89-28.65-18.83a1,1,0,0,0-1.39.29,1,1,0,0,0,.29,1.38L664.58,317,657,397.89l-62.69,14.27L565.24,285A15,15,0,0,1,567.2,273.61ZM737.9,424.37a1,1,0,0,0,1.41.19l71.12-54.77L845.6,402.6a1,1,0,0,0,.36.21l-4.12,43.71L656.2,427.36l4.49-47.66a.94.94,0,0,0,.86-.1l67.93-45.68,51.61,55.93-43,33.12A1,1,0,0,0,737.9,424.37ZM619.73,455.26a15.23,15.23,0,0,1-18.21-11.41l-6.79-29.74,62-14.13-2.61,27.76a1.12,1.12,0,0,0-.14.4,1,1,0,0,0,.06.43l-1.82,19.33Zm219.17,22.5a15.21,15.21,0,0,1-16.55,13.67L666.81,476.88a15.22,15.22,0,0,1-13.72-16.5l2.92-31,185.64,19.16Zm15.28-162.34-8,85-35-32.67a1,1,0,0,0-1.3-.06l-27.2,20.95-52.31-56.7a1,1,0,0,0-1.3-.15l-68.19,45.86,7.5-79.6a15.2,15.2,0,0,1,16.55-13.67l155.54,14.55a15.22,15.22,0,0,1,13.71,16.5ZM788.4,325.69A12.21,12.21,0,0,0,786.12,350c.39,0,.77.05,1.15.05A12.22,12.22,0,0,0,799.41,339h0a12.19,12.19,0,0,0-11-13.29Zm9,13.1a10.2,10.2,0,1,1-10.17-11.15c.32,0,.64,0,1,0a10.2,10.2,0,0,1,9.21,11.11Zm-168.36,3.62a1,1,0,0,0,.55.17,1,1,0,0,0,.56-1.83L607.75,325.8a1,1,0,0,0-1.11,1.67Zm-78.72-42.54L38.33,49.46l.44-.9L550.78,299ZM39.58,724l-.44-.9,549.09-271.3.45.9Zm1364.65,1.75-.45-.22L870,463.38l.44-.89.45.22,533.77,262.13ZM870.51,307.35l-.44-.9L1402.64,44.84l.44.89Z' fill='%23ccc'/></svg>");
}

.swiper-text {
  position: absolute;
  width: 92%;
  top: 50%;
  bottom: auto;
  left: 50%;
  padding: 0 25px;
  text-align: center;
  transform: translate(-50%,-50%);
}
.swiper-description {
  letter-spacing: 3px;
}
.swiper-title {
  font-size: 50px;
  line-height: 52px;
  font-weight: 900;
}
.swiper-title-small {
  font-size: 28px;
  line-height: 30px;
}

{# /* // Lists */ #}

.list {
  padding: 0;
  list-style-type: none;
}
.list .list-item{
  position: relative;
  margin-bottom: 10px;
  cursor: default;
}

.list-unstyled{
  padding: 0;
  margin: 0;
  list-style-type: none;
}

.list-inline li{
  display: inline-flex;
}

{# /* // Notifications */ #}

.notification{
  padding: 10px;
  text-align: center;
}
.notification-floating {
  position: absolute;
  left: 0;
  z-index: 2000;
  width: 100%;
}
.notification-fixed {
  position: fixed;
  right: 0;
  left: initial;
  width: calc(100% - 20px);
  margin-top: -10px;
}
.notification-floating .notification{
  margin: 10px;
}
.notification-close {
  padding: 0 5px;
}
.notification-floating .notification {
  border-radius: 6px;
  box-shadow: 0 0 5px 0 rgba(0, 0, 0, .1), 0 3px 9px 0 rgba(0, 0, 0, .3);
}
.notification-centered {  
  display: inline-block;
  width: 100%;
  margin: 0 20px 20px 0;
  text-align: center;
}
.notification-left {
  display: inline-block;
  margin: 5px 0 20px 0;
  text-align: left;
  font-size: 12px;
}

.notification-fixed-bottom {
  position: fixed;
  bottom: 0;
  left: 0;
  z-index: 999;
  width: 100%;
}

.notification-above {
  z-index: 1000;
}

{# /* // Badge */ #}

.badge {
  position: absolute;
  right: 0;
  top: 10px;
  padding: 6px;
  font-size: 12px;
  font-weight: bold;
  line-height: 13px;
  border-radius: 20px;
}

.badge-amount {
  padding: 2px 5px;
}

.badge-overlap {
  top: 12px;
  right: 17px;
}

.badge-float {
  top: -10px;
  right: -9px;
}

{# /* // Tooltip */ #}

.tooltip {
  position: absolute;
  left: -170%;
  z-index: 9999;
  width: 340px;
  padding: 15px 5px;
  text-align: center;
  border-radius: 10px;
}

.tooltip-top {
  bottom: calc(100% + 20px);
}

.tooltip-bottom {
  top: 95%;
}

.tooltip-arrow {
  position: absolute;
  right: 30%;
  width: 0;
  height: 0;
  pointer-events: none;
}

.tooltip-bottom .tooltip-arrow {
  top: -8px;
  right: 15%;
}

.tooltip-top .tooltip-arrow {
  bottom: -8px;
  transform: rotate(180deg);
}

{# /* // Images */ #}

/* Used for images that have a placeholder before it loads. The image container should have a padding-bottom inline with the result of (image height/ image width) * 100 */
.img-absolute {
  position: absolute;
  left: 0;
  width: 100%;
  height: auto;
  vertical-align: middle;
  text-indent: -9999px;
  z-index: 1;
}

.img-absolute-centered{
  left: 50%;
  transform: translateX(-50%)!important;
  -webkit-transform: translateX(-50%)!important;
  -ms-transform: translateX(-50%)!important;
}

.card-img{
  margin: 0 5px 5px 0;
  border: 1px solid #00000012;
}
.card-img-small{
  height: 25px;
}
.card-img-medium{
  height: 35px;
}
.card-img-big{
  height: 50px;
}
.card-img-square-container {
  position: relative;
  width: 100%;
  padding-top: 100%;
}
.card-img-square {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  object-fit: cover;
}
.card-img-pill {
  position: absolute;
  right: 5px;
  bottom: 5px;
  z-index: 999;
  padding: 4px 9px;
  font-size: 12px;
  border-radius: 15px;
}

{# /* // Forms */ #}

.form-group {
  position: relative;
  width: 100%;
}
.form-group .form-select-icon{
  position: absolute;
  bottom: 12px;
  right: 15px;
  pointer-events: none;
}
.form-group-small .form-select-icon{
  bottom: 10px;
  right: 10px;
  font-size: 12px;
}
.form-row {
  width: auto;
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
  -ms-flex-wrap: wrap;
  flex-wrap: wrap;
  margin-right: -5px;
  margin-left: -5px;
  clear: both;
}

.form-row > .col,
.form-row > [class*=col-]{
  padding-right: 5px;
  padding-left: 5px;
}

.form-label {
  font-size: 12px;
}

.form-toggle-eye {
  position: absolute;
  top: 28px;
  right: 2px;
  display: inline-block;
  padding: 10px;
  background: none;
  border: 0;
}

{# /* // Video */ #}

.embed-responsive {
  position: relative;
  display: block;
  height: 0;
  padding: 0;
  overflow: hidden;
}
.embed-responsive.embed-responsive-16by9 {
  padding-bottom: 56.25%;
}
.embed-responsive .embed-responsive-item,
.embed-responsive embed,
.embed-responsive iframe,
.embed-responsive object,
.embed-responsive video {
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  width: 100%;
  height: 100%;
  border: 0;
}
.video-player {
  position: absolute;
  top: 0;
  left: 0;
  z-index: 1;
  width: 100%;
  height: 100%;
  cursor: pointer;
}
.video-player-icon {
  position: absolute;
  top: 50%;
  left: 50%;
  width: 80px;
  height: 80px;
  margin: -40px 0 0 -40px;
  padding: 0;
  font-size: 24px;
  line-height: 80px;
  text-align: center;
  border-radius: 80px;
  pointer-events: none;
}
.video-player-icon-small {
  width: 40px;
  height: 40px;
  margin: -20px 0 0 -20px;
  font-size: 20px;
  line-height: 40px;
}
.video-image {
  position: absolute;
  top: 50%;
  left: 50%;
  width: 100%;
  height: auto;
  transform: translate(-50%, -50%);
  -webkit-transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
}

/*============================================================================
  #Header and nav
==============================================================================*/

.head-main {
  position: relative;
  z-index: 1040;  
  -webkit-backface-visibility: hidden;
  -webkit-transform: scale(1);
}

.head-fix {
  position: sticky;
  top:0;
  width: 100%;
}

{# /* // Topbar */ #}

.section-topbar {
  padding: 4px 0;
  line-height: 20px;
}

{# /* // Nav */ #}

.nav-row {
  border-top: 1px solid;
}

.nav-desktop {
  width: 100%;
  display: inline-block;
  position: relative;
}
.nav-desktop-list {
  margin: 0;
  padding: 0;
  list-style: none;
}
.nav-item {
  display: inline-block;
  position: initial;
  padding: 0 10px;
}
.nav-list-link {
  padding: 0 5px;
  font-weight: 500;
  font-size: 14px;
  line-height: 50px;
  letter-spacing: 1px;
}

.desktop-dropdown {
  position: absolute;
  width: 100%; 
  top: 100%;
  left: 0;
  z-index: 9999;
  overflow-y: auto;
}

.nav-categories {
  overflow-x: scroll;
}
.nav-list-mobile-categories {
  margin: 4px 0;
  padding: 0 15px;
  white-space: nowrap!important;
}

.nav-dropdown-content {
  position: absolute;
  visibility: hidden;
  opacity: 0;
  transition: visibility 0s linear .3s, opacity .3s linear;
}

.utilities-container .nav-dropdown-content {
  pointer-events: none;
}

{# /* // Logo */ #}

.logo-text-container {
  max-width: 450px;
  margin: auto;
  padding: 5px;
}

.logo-img-container {
  max-width: 450px;
  margin: auto;
}
.logo-img{
  width: auto;
  height: auto;
  margin: 15px 0;
  vertical-align: middle;
  max-width: 90%;
  max-height: 50px;
    
                padding-left: 45px;
      
}

.logo-img-small,
.head-main.head-fix.compress .logo-img-small {
  max-width: 75%;
  max-height: 40px;
}

.logo-img-big {
  max-height: 80px;
}

{# /* // Cart widget and search */ #}

.search-input-submit {
  position: absolute;
  top: -2px;
  right: 2px;
  padding: 10px;
  background: none;
  border: 0;
}

.utilities-item {
  position: relative;
  display: inline-block;
    
          font-size: 12px;
      padding:  15px 8px;
      
}
.utility-name {
  padding-top: 5px;
  font-size: 12px;
}

/*============================================================================
  #Home Page
==============================================================================*/

{# /* // Welcome message */ #}

.section-welcome-home {
  padding-top: 50px;
  padding-bottom: 70px;
  text-align: center;
}

/*============================================================================
  #Banners
==============================================================================*/

{# /* // Home banners */ #}

.textbanner {
  position: relative;
  margin-bottom: 40px;
  overflow: hidden;
}
.textbanner-link {
  display: block;
  width: 100%;
  height: 100%;
}
.textbanner-image {
  position: relative;
  padding-top: 115%;
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
}
.textbanner-text {  
  position: relative;
  padding: 30px;
  text-align: center;
}
.textbanner-text.over-image {
  position: absolute;
  top: 50%;
  left: 50%;
  z-index: 9;
  width: 100%;
  color: #fff;
  border: 0;
  transform: translate(-50%, -50%);
}
.textbanner-paragraph {
  display: -webkit-box;
  margin: 15px 0;
  overflow: hidden;
  text-overflow: ellipsis;
  -webkit-line-clamp: 3;
  -webkit-box-orient: vertical;
}

.textbanner .textbanner-image.overlay.textbanner-image-empty {
  background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' viewBox='0 0 600 900'><defs><radialGradient id='a' cx='3282.88' cy='442.28' r='546.36' gradientTransform='matrix(0.43, 0, 0, -1.38, -1111.64, 1058.96)' gradientUnits='userSpaceOnUse'><stop offset='0' stop-color='%23f9f9f9'/><stop offset='0.5' stop-color='%23f9f9f9'/><stop offset='1' stop-color='%23f9f9f9'/></radialGradient></defs><rect width='600' height='900' fill='url(%23a)'/><path d='M420,633.77l160,245Z' fill='none' stroke='%23ddd' stroke-linecap='square' stroke-miterlimit='10'/><path d='M420,266.23l160-245Z' fill='none' stroke='%23ddd' stroke-linecap='square' stroke-miterlimit='10'/><polyline points='20 878.81 140.04 694.97 180 633.77' fill='none' stroke='%23ddd' stroke-linecap='square' stroke-miterlimit='10'/><line x1='20' y1='21.19' x2='180' y2='266.23' fill='none' stroke='%23ddd' stroke-linecap='square' stroke-miterlimit='10'/><path d='M239.27,543.46l-39.35,8.9A19.24,19.24,0,0,1,177,538L134,349.9A19.16,19.16,0,0,1,148.46,327l180.48-40.84a19.25,19.25,0,0,1,23,14.4l12.63,55.32' fill='none' stroke='%23ccc' stroke-linecap='round' stroke-linejoin='round'/><line x1='168.9' y1='501.54' x2='244.84' y2='484.25' fill='none' stroke='%23ccc' stroke-linecap='round' stroke-linejoin='round'/><line x1='218.43' y1='363.55' x2='254' y2='386.93' fill='none' stroke='%23ccc' stroke-linecap='round' stroke-linejoin='round'/><line x1='184.82' y1='398.93' x2='211.36' y2='416.62' fill='none' stroke='%23ccc' stroke-linecap='round' stroke-linejoin='round'/><path d='M439.42,595.21,255.28,578A19.19,19.19,0,0,1,238,557.15L256.07,365A19.2,19.2,0,0,1,277,347.72L461.09,365a19.2,19.2,0,0,1,17.31,20.82L460.3,578A19.21,19.21,0,0,1,439.42,595.21Z' fill='none' stroke='%23ccc' stroke-linecap='round' stroke-linejoin='round'/><line x1='241.43' y1='519.23' x2='464.33' y2='542.22' fill='none' stroke='%23ccc' stroke-linecap='round' stroke-linejoin='round'/><polyline points='248.51 460.65 329.76 406.01 391.8 473.23' fill='none' stroke='%23ccc' stroke-linecap='round' stroke-linejoin='round'/><polyline points='467.87 488 425.5 448.47 340.5 513.92' fill='none' stroke='%23ccc' stroke-linecap='round' stroke-linejoin='round'/><path d='M411.2,413.44a13.27,13.27,0,1,1-12-14.45A13.28,13.28,0,0,1,411.2,413.44Z' fill='none' stroke='%23ccc' stroke-linecap='round' stroke-linejoin='round'/></svg>");
}

.textbanner-image-background {
  position: absolute;
  top: 0;
  width: 100%;
  height: 100%;
  object-fit: cover;
}

{# /* // Informative banners */ #}

.section-informative-banners {
  padding: 50px 0;
}

.service-icon {
  margin: 10px 0;
}

.service-item .service-icon-big {
  font-size: 30px;
}

.service-pagination {
  position: relative;
  margin-top: 5px;
}

/*============================================================================
  #Product grid
==============================================================================*/

{# /* // Category banner */ #}  

.category-banner-header {
  position: relative;
  width: 100%;
  margin: -60px 15px 0 15px;
  padding: 15px 0;
}

{# /* // Category controls */ #}

.category-controls-sticky-detector {
  height: 1px;
}

.category-controls {
  position: sticky;
  z-index: 100;
  padding: 15px;
  transition: all .5s cubic-bezier(.16,.68,.43,.99);
}

{# /* // Grid item */ #}

.item {
  margin-bottom: 20px;
  padding: 15px;
  text-align: center;
  border-radius: 10px;
}
.item-rounded {
  margin-bottom: 40px;
}
.item-rounded.box-rounded {
  overflow: visible;
}
.item-rounded .item-image {
  border-radius: 20px 20px 0 0;
}
.item-image {
  position: relative;
  overflow: hidden;
  max-height: 390px;
}
.item-image img{
  height: 100%;
  width: auto;
  max-height: 390px;
}
.item-image-big,
.item-image-big img{
  max-height: 530px;
}
.item-image-primary {
  z-index: 2;
  opacity: 1;
}
.item-image .item-image-secondary {
  opacity: 0;
}
.item-with-two-images:hover .item-image-primary {
  opacity: 0;
  transition-delay: .05s
}
.item-with-two-images:hover .item-image-secondary{
  opacity: 1;
}
.item-colors {
  position: absolute;
  bottom: 0;
  z-index: 9;
  width: 100%;
  padding: 10px 0;
}
.item-colors-bullet {
  display: inline-block;
  min-width: 18px;
  height: 18px;
  margin: 0 3px;
  font-size: 10px;
  line-height: 16px;
  vertical-align: top;
  border-radius: 18px;
  cursor: pointer;
  opacity: 0.8;
  -webkit-transition: all 0.4s ease;
  -ms-transition: all 0.4s ease;
  -moz-transition: all 0.4s ease;
  -o-transition: all 0.4s ease;
  transition: all 0.4s ease;
}
.item-colors-bullet:hover,
.item-colors-bullet.selected {
  opacity: 1;
}
.item-thumbnail {
  display: block;
  width: 100%;
}
.item-name {
  font-size: 14px;
  line-height: 16px;
  text-overflow: ellipsis;
  overflow: hidden;
  -webkit-line-clamp: 2;
  display: -webkit-box;
  -webkit-box-orient: vertical;
}
.item-price-container { 
  font-size: 14px;
}
.item-price {
  font-size: 20px;
  font-weight: 700;
}
.price-compare {
  margin-right: 10px;
  text-decoration: line-through;
}
.item-installments { 
  font-size: 12px;
}
.item-installments .product-installment-amount,
.item-installments .product-installment-value {
  font-weight: bold;
}
.item-buy {
  display: block;
  position: absolute;
  bottom: 0;
  width: 100%;
  align-items: center;
  text-align: center;
  z-index: 10;
}
.item-buy-open {
  display: inline-block;
  text-align: center;
  padding: 4px 8px 0 8px;
  font-size: 20px; 
}
.item-buy-variants {
  overflow: hidden;
  display: none;
  padding-top: 20px;
}
.item-actions {
  -webkit-transition: all 0.4s ease;
  -ms-transition: all 0.4s ease;
  -moz-transition: all 0.4s ease;
  -o-transition: all 0.4s ease;
  transition: all 0.4s ease;
}

{# /* // Labels */ #}

.labels {
  position: absolute;
  top: 10px;
  left: 10px;
  z-index: 9;
  text-align: left;
  pointer-events: none;
}

.labels-product-slider{
  top: 10px;
  left: 45px;
}

.label {
  margin-bottom: 10px;
  padding: 8px 10px; 
  border-radius: 10px;
  font-size: 12px;
  font-weight: bold;
  text-transform: uppercase;
  width: fit-content;
}

.label-small {
  padding: 3px 6px; 
  border-radius: 12px;
  font-size: 10px;
}

.label-circle{
  height: 50px;
  width: 50px;
  border-radius: 100%;
  line-height: 16px;
  text-align: center;
  box-sizing: border-box;
}

/*============================================================================
  #Product detail
==============================================================================*/

{# /* // Image */ #}

.nube-slider-product {
  overflow: hidden;
}

.product-slider-image {
  width: auto;
  height: 100%;
  max-width: 100%;
}

.thumb-see-more{
  display: flex;
  justify-content: center;
  flex-direction: column;
  position: absolute;
  width: 100%;
  height: 100%;
  z-index: 1;
  text-align: center;
}

.product-video-container {
  display: block;
  width: 100%;
  height: 100%;
}
.product-video {
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  -webkit-box-align: center;
  -ms-flex-align: center;
  align-items: center;
}
.product-video .embed-responsive {
  width: 100%;
  height: 100%;
}
.product-video .video-image{
  width: auto;
  height: 100%;
}

.product-banner-service-image {
  width: 20px;
}

/*============================================================================
  #Cart detail
==============================================================================*/

{# /* // Shipping Calculator */ #}

.shipping-calculator-head.with-zip {
  height: 45px;
}
.shipping-calculator-head.with-form {
  height: 110px;
}
.shipping-calculator-head.with-form + .shipping-spinner-container {
  margin-top: -20px;
}
.shipping-calculator-head.with-error {
  height: 200px;
}

/*============================================================================
  #Contact page
==============================================================================*/

{# /* // Data contact */ #}

.contact-info {
  margin-top: 10px;
  padding-left: 0;
}

.contact-icon {
  display: block;
  margin: 0 auto 10px auto;
}

.contact-item {
  list-style: none;
}

.contact-link {
  list-style: none;
}

/*============================================================================
  #Media queries
==============================================================================*/

{# /* // Min width 1400px */ #}

@media (min-width: 1400px) {
  .container {
    max-width: 1300px;
  }
}

{# /* // Min width 768px */ #}

@media (min-width: 768px) { 

  {# /* //// Components */ #}

  {# /* Titles and breadcrumbs */ #}

  .h1, .h1-md {
    font-size: 34px;
    font-weight: 700;
  }

  .h4-md {
    font-size: 18px;
    font-weight: 700;
  }

  .h5-md {
    font-size: 16px;
    font-weight: 700;
  }

  .h6-md {
    font-size: 14px;
    font-weight: 700;
  }

  .font-md-normal {
    font-size: 14px;
  }

  {# /* Slider */ #}

  .swiper-text {
    max-width: 800px;
  }
  .swiper-description {
    font-size: 16px;
    letter-spacing: 1px;
  }
  .swiper-title {
    font-size: 66px;
    line-height: 68px;
    font-weight: 900;
  }

  {# /* Notifications */ #}

  .notification-floating{
    margin-top: -10px;
  }

  .notification-fixed {
    right: 10px;
    width: 25%;
  }

  {# /* Tooltips */ #}

  .tooltip {
    right: -5px;
    left: initial;
  }

  {# /* Tooltips */ #}

  .badge-amount {
    
              right: 28px;
          
  }

  {# /* //// Header and nav */ #}

  .head-fix {
    position: fixed;
  }

  .logo-img{
    width: auto;
    height: auto;
    
              max-height: 80px;
            max-width: 80%;
              padding-left: 0;
             
  }
  
  

  .logo-img-big {
    max-height: 100px;
    max-width: 90%;
  }

  .logo-desktop-center .logo-img-big {
    max-height: 80px;
  }

  .logo-img-small,
  .head-main.head-fix.compress .logo-img-small {
    max-height: 60px;
    max-width: 50%;
  }

  .logo-desktop-center .logo-img-small,
  .logo-desktop-center.head-main.compress .logo-img-small {
    max-height: 40px;
  }

  .logo-text-container {
    padding: 20px;
  }

  {# /* Cart widget and search */ #}

  .utilities-container {
    margin-right: -10px;
  }
  .utilities-item {
    width: 32%;
    padding: 15px 0;
  }

  {# /* //// Product grid */ #}

  .category-controls {
    position: relative;
    padding: 0 15px;
  }

  .item-actions {
    visibility: hidden;
    opacity: 0;
  }
  .item:hover .item-actions {
    visibility: visible;
    opacity: 1;
  }

  .item-rounded .item-actions {
    position: absolute;
    width: 100%;
    height: 0;
    margin-top: -15px !important;
    border-radius: 0 0 20px 20px;
  }

  .item-rounded:hover .item-actions {
    height: 45px;
  }

  .labels-product-slider{
    top: 10px;
    left: 10px;
  }

  {# /* //// Product detail */ #}

  .product-video-container {
    padding: 0;
  }

  {# /* //// Helper classes */ #}

  {# /* // Position */ #}

  .position-relative-md{position:relative!important;}.position-sticky-md{position:sticky!important;position:-webkit-sticky!important;}

  {# /* // Float */ #}
  
  .float-md-none{float:none!important;}

  {# /* // Titles */ #}
  
  .h3-md{font-size:20px;font-weight:700}

  {# /* // Icons */ #}

  .icon-desktop-lg {font-size: 1.33333em;line-height: .75em;vertical-align: -.0667em;}

  {# /* // Width */ #}
  .w-md-100{width:100%!important}.w-md-auto{width:auto!important}
}
/*============================================================================
  #Helper classes
==============================================================================*/

/*CSS properties helpers minified, to unminify it you have to copy the code and paste it here http://unminify.com/, after that paste the unminified code here */

{# /* // Margin and padding */ #}
.m-0{margin:0!important}.mt-0,.my-0{margin-top:0!important}.mr-0,.mx-0{margin-right:0!important}.mb-0,.my-0{margin-bottom:0!important}.ml-0,.mx-0{margin-left:0!important}.m-1{margin:.25rem!important}.mt-1,.my-1{margin-top:.25rem!important}.mr-1,.mx-1{margin-right:.25rem!important}.mb-1,.my-1{margin-bottom:.25rem!important}.ml-1,.mx-1{margin-left:.25rem!important}.m-2{margin:.5rem!important}.mt-2,.my-2{margin-top:.5rem!important}.mr-2,.mx-2{margin-right:.5rem!important}.mb-2,.my-2{margin-bottom:.5rem!important}.ml-2,.mx-2{margin-left:.5rem!important}.m-3{margin:1rem!important}.mt-3,.my-3{margin-top:1rem!important}.mr-3,.mx-3{margin-right:1rem!important}.mb-3,.my-3{margin-bottom:1rem!important}.ml-3,.mx-3{margin-left:1rem!important}.m-4{margin:1.5rem!important}.mt-4,.my-4{margin-top:1.5rem!important}.mr-4,.mx-4{margin-right:1.5rem!important}.mb-4,.my-4{margin-bottom:1.5rem!important}.ml-4,.mx-4{margin-left:1.5rem!important}.mt-3n{margin-top:-1rem!important}.mt-4n{margin-top:-1.5rem!important}.m-5{margin:3rem!important}.mt-5,.my-5{margin-top:3rem!important}.mr-5,.mx-5{margin-right:3rem!important}.mb-5,.my-5{margin-bottom:3rem!important}.ml-5,.mx-5{margin-left:3rem!important}.p-0{padding:0!important}.pt-0,.py-0{padding-top:0!important}.pr-0,.px-0{padding-right:0!important}.pb-0,.py-0{padding-bottom:0!important}.pl-0,.px-0{padding-left:0!important}.p-1{padding:.25rem!important}.pt-1,.py-1{padding-top:.25rem!important}.pr-1,.px-1{padding-right:.25rem!important}.pb-1,.py-1{padding-bottom:.25rem!important}.pl-1,.px-1{padding-left:.25rem!important}.p-2{padding:.5rem!important}.pt-2,.py-2{padding-top:.5rem!important}.pr-2,.px-2{padding-right:.5rem!important}.pb-2,.py-2{padding-bottom:.5rem!important}.pl-2,.px-2{padding-left:.5rem!important}.p-3{padding:1rem!important}.pt-3,.py-3{padding-top:1rem!important}.pr-3,.px-3{padding-right:1rem!important}.pb-3,.py-3{padding-bottom:1rem!important}.pl-3,.px-3{padding-left:1rem!important}.p-4{padding:1.5rem!important}.pt-4,.py-4{padding-top:1.5rem!important}.pr-4,.px-4{padding-right:1.5rem!important}.pb-4,.py-4{padding-bottom:1.5rem!important}.pl-4,.px-4{padding-left:1.5rem!important}.p-5{padding:3rem!important}.pt-5,.py-5{padding-top:3rem!important}.pr-5,.px-5{padding-right:3rem!important}.pb-5,.py-5{padding-bottom:3rem!important}.pl-5,.px-5{padding-left:3rem!important}.m-auto{margin:auto!important}.mt-auto,.my-auto{margin-top:auto!important}.mr-auto,.mx-auto{margin-right:auto!important}.mb-auto,.my-auto{margin-bottom:auto!important}.ml-auto,.mx-auto{margin-left:auto!important}@media (min-width:576px){.m-sm-0{margin:0!important}.mt-sm-0,.my-sm-0{margin-top:0!important}.mr-sm-0,.mx-sm-0{margin-right:0!important}.mb-sm-0,.my-sm-0{margin-bottom:0!important}.ml-sm-0,.mx-sm-0{margin-left:0!important}.m-sm-1{margin:.25rem!important}.mt-sm-1,.my-sm-1{margin-top:.25rem!important}.mr-sm-1,.mx-sm-1{margin-right:.25rem!important}.mb-sm-1,.my-sm-1{margin-bottom:.25rem!important}.ml-sm-1,.mx-sm-1{margin-left:.25rem!important}.m-sm-2{margin:.5rem!important}.mt-sm-2,.my-sm-2{margin-top:.5rem!important}.mr-sm-2,.mx-sm-2{margin-right:.5rem!important}.mb-sm-2,.my-sm-2{margin-bottom:.5rem!important}.ml-sm-2,.mx-sm-2{margin-left:.5rem!important}.m-sm-3{margin:1rem!important}.mt-sm-3,.my-sm-3{margin-top:1rem!important}.mr-sm-3,.mx-sm-3{margin-right:1rem!important}.mb-sm-3,.my-sm-3{margin-bottom:1rem!important}.ml-sm-3,.mx-sm-3{margin-left:1rem!important}.m-sm-4{margin:1.5rem!important}.mt-sm-4,.my-sm-4{margin-top:1.5rem!important}.mr-sm-4,.mx-sm-4{margin-right:1.5rem!important}.mb-sm-4,.my-sm-4{margin-bottom:1.5rem!important}.ml-sm-4,.mx-sm-4{margin-left:1.5rem!important}.m-sm-5{margin:3rem!important}.mt-sm-5,.my-sm-5{margin-top:3rem!important}.mr-sm-5,.mx-sm-5{margin-right:3rem!important}.mb-sm-5,.my-sm-5{margin-bottom:3rem!important}.ml-sm-5,.mx-sm-5{margin-left:3rem!important}.p-sm-0{padding:0!important}.pt-sm-0,.py-sm-0{padding-top:0!important}.pr-sm-0,.px-sm-0{padding-right:0!important}.pb-sm-0,.py-sm-0{padding-bottom:0!important}.pl-sm-0,.px-sm-0{padding-left:0!important}.p-sm-1{padding:.25rem!important}.pt-sm-1,.py-sm-1{padding-top:.25rem!important}.pr-sm-1,.px-sm-1{padding-right:.25rem!important}.pb-sm-1,.py-sm-1{padding-bottom:.25rem!important}.pl-sm-1,.px-sm-1{padding-left:.25rem!important}.p-sm-2{padding:.5rem!important}.pt-sm-2,.py-sm-2{padding-top:.5rem!important}.pr-sm-2,.px-sm-2{padding-right:.5rem!important}.pb-sm-2,.py-sm-2{padding-bottom:.5rem!important}.pl-sm-2,.px-sm-2{padding-left:.5rem!important}.p-sm-3{padding:1rem!important}.pt-sm-3,.py-sm-3{padding-top:1rem!important}.pr-sm-3,.px-sm-3{padding-right:1rem!important}.pb-sm-3,.py-sm-3{padding-bottom:1rem!important}.pl-sm-3,.px-sm-3{padding-left:1rem!important}.p-sm-4{padding:1.5rem!important}.pt-sm-4,.py-sm-4{padding-top:1.5rem!important}.pr-sm-4,.px-sm-4{padding-right:1.5rem!important}.pb-sm-4,.py-sm-4{padding-bottom:1.5rem!important}.pl-sm-4,.px-sm-4{padding-left:1.5rem!important}.p-sm-5{padding:3rem!important}.pt-sm-5,.py-sm-5{padding-top:3rem!important}.pr-sm-5,.px-sm-5{padding-right:3rem!important}.pb-sm-5,.py-sm-5{padding-bottom:3rem!important}.pl-sm-5,.px-sm-5{padding-left:3rem!important}.m-sm-auto{margin:auto!important}.mt-sm-auto,.my-sm-auto{margin-top:auto!important}.mr-sm-auto,.mx-sm-auto{margin-right:auto!important}.mb-sm-auto,.my-sm-auto{margin-bottom:auto!important}.ml-sm-auto,.mx-sm-auto{margin-left:auto!important}}@media (min-width:768px){.m-md-0{margin:0!important}.mt-md-0,.my-md-0{margin-top:0!important}.mr-md-0,.mx-md-0{margin-right:0!important}.mb-md-0,.my-md-0{margin-bottom:0!important}.ml-md-0,.mx-md-0{margin-left:0!important}.m-md-1{margin:.25rem!important}.mt-md-1,.my-md-1{margin-top:.25rem!important}.mr-md-1,.mx-md-1{margin-right:.25rem!important}.mb-md-1,.my-md-1{margin-bottom:.25rem!important}.ml-md-1,.mx-md-1{margin-left:.25rem!important}.m-md-2{margin:.5rem!important}.mt-md-2,.my-md-2{margin-top:.5rem!important}.mr-md-2,.mx-md-2{margin-right:.5rem!important}.mb-md-2,.my-md-2{margin-bottom:.5rem!important}.ml-md-2,.mx-md-2{margin-left:.5rem!important}.m-md-3{margin:1rem!important}.mt-md-3,.my-md-3{margin-top:1rem!important}.mr-md-3,.mx-md-3{margin-right:1rem!important}.mb-md-3,.my-md-3{margin-bottom:1rem!important}.ml-md-3,.mx-md-3{margin-left:1rem!important}.m-md-4{margin:1.5rem!important}.mt-md-4,.my-md-4{margin-top:1.5rem!important}.mr-md-4,.mx-md-4{margin-right:1.5rem!important}.mb-md-4,.my-md-4{margin-bottom:1.5rem!important}.ml-md-4,.mx-md-4{margin-left:1.5rem!important}.m-md-5{margin:3rem!important}.mt-md-5,.my-md-5{margin-top:3rem!important}.mr-md-5,.mx-md-5{margin-right:3rem!important}.mb-md-5,.my-md-5{margin-bottom:3rem!important}.ml-md-5,.mx-md-5{margin-left:3rem!important}.p-md-0{padding:0!important}.pt-md-0,.py-md-0{padding-top:0!important}.pr-md-0,.px-md-0{padding-right:0!important}.pb-md-0,.py-md-0{padding-bottom:0!important}.pl-md-0,.px-md-0{padding-left:0!important}.p-md-1{padding:.25rem!important}.pt-md-1,.py-md-1{padding-top:.25rem!important}.pr-md-1,.px-md-1{padding-right:.25rem!important}.pb-md-1,.py-md-1{padding-bottom:.25rem!important}.pl-md-1,.px-md-1{padding-left:.25rem!important}.p-md-2{padding:.5rem!important}.pt-md-2,.py-md-2{padding-top:.5rem!important}.pr-md-2,.px-md-2{padding-right:.5rem!important}.pb-md-2,.py-md-2{padding-bottom:.5rem!important}.pl-md-2,.px-md-2{padding-left:.5rem!important}.p-md-3{padding:1rem!important}.pt-md-3,.py-md-3{padding-top:1rem!important}.pr-md-3,.px-md-3{padding-right:1rem!important}.pb-md-3,.py-md-3{padding-bottom:1rem!important}.pl-md-3,.px-md-3{padding-left:1rem!important}.p-md-4{padding:1.5rem!important}.pt-md-4,.py-md-4{padding-top:1.5rem!important}.pr-md-4,.px-md-4{padding-right:1.5rem!important}.pb-md-4,.py-md-4{padding-bottom:1.5rem!important}.pl-md-4,.px-md-4{padding-left:1.5rem!important}.p-md-5{padding:3rem!important}.pt-md-5,.py-md-5{padding-top:3rem!important}.pr-md-5,.px-md-5{padding-right:3rem!important}.pb-md-5,.py-md-5{padding-bottom:3rem!important}.pl-md-5,.px-md-5{padding-left:3rem!important}.m-md-auto{margin:auto!important}.mt-md-auto,.my-md-auto{margin-top:auto!important}.mr-md-auto,.mx-md-auto{margin-right:auto!important}.mb-md-auto,.my-md-auto{margin-bottom:auto!important}.ml-md-auto,.mx-md-auto{margin-left:auto!important}}@media (min-width:992px){.m-lg-0{margin:0!important}.mt-lg-0,.my-lg-0{margin-top:0!important}.mr-lg-0,.mx-lg-0{margin-right:0!important}.mb-lg-0,.my-lg-0{margin-bottom:0!important}.ml-lg-0,.mx-lg-0{margin-left:0!important}.m-lg-1{margin:.25rem!important}.mt-lg-1,.my-lg-1{margin-top:.25rem!important}.mr-lg-1,.mx-lg-1{margin-right:.25rem!important}.mb-lg-1,.my-lg-1{margin-bottom:.25rem!important}.ml-lg-1,.mx-lg-1{margin-left:.25rem!important}.m-lg-2{margin:.5rem!important}.mt-lg-2,.my-lg-2{margin-top:.5rem!important}.mr-lg-2,.mx-lg-2{margin-right:.5rem!important}.mb-lg-2,.my-lg-2{margin-bottom:.5rem!important}.ml-lg-2,.mx-lg-2{margin-left:.5rem!important}.m-lg-3{margin:1rem!important}.mt-lg-3,.my-lg-3{margin-top:1rem!important}.mr-lg-3,.mx-lg-3{margin-right:1rem!important}.mb-lg-3,.my-lg-3{margin-bottom:1rem!important}.ml-lg-3,.mx-lg-3{margin-left:1rem!important}.m-lg-4{margin:1.5rem!important}.mt-lg-4,.my-lg-4{margin-top:1.5rem!important}.mr-lg-4,.mx-lg-4{margin-right:1.5rem!important}.mb-lg-4,.my-lg-4{margin-bottom:1.5rem!important}.ml-lg-4,.mx-lg-4{margin-left:1.5rem!important}.m-lg-5{margin:3rem!important}.mt-lg-5,.my-lg-5{margin-top:3rem!important}.mr-lg-5,.mx-lg-5{margin-right:3rem!important}.mb-lg-5,.my-lg-5{margin-bottom:3rem!important}.ml-lg-5,.mx-lg-5{margin-left:3rem!important}.p-lg-0{padding:0!important}.pt-lg-0,.py-lg-0{padding-top:0!important}.pr-lg-0,.px-lg-0{padding-right:0!important}.pb-lg-0,.py-lg-0{padding-bottom:0!important}.pl-lg-0,.px-lg-0{padding-left:0!important}.p-lg-1{padding:.25rem!important}.pt-lg-1,.py-lg-1{padding-top:.25rem!important}.pr-lg-1,.px-lg-1{padding-right:.25rem!important}.pb-lg-1,.py-lg-1{padding-bottom:.25rem!important}.pl-lg-1,.px-lg-1{padding-left:.25rem!important}.p-lg-2{padding:.5rem!important}.pt-lg-2,.py-lg-2{padding-top:.5rem!important}.pr-lg-2,.px-lg-2{padding-right:.5rem!important}.pb-lg-2,.py-lg-2{padding-bottom:.5rem!important}.pl-lg-2,.px-lg-2{padding-left:.5rem!important}.p-lg-3{padding:1rem!important}.pt-lg-3,.py-lg-3{padding-top:1rem!important}.pr-lg-3,.px-lg-3{padding-right:1rem!important}.pb-lg-3,.py-lg-3{padding-bottom:1rem!important}.pl-lg-3,.px-lg-3{padding-left:1rem!important}.p-lg-4{padding:1.5rem!important}.pt-lg-4,.py-lg-4{padding-top:1.5rem!important}.pr-lg-4,.px-lg-4{padding-right:1.5rem!important}.pb-lg-4,.py-lg-4{padding-bottom:1.5rem!important}.pl-lg-4,.px-lg-4{padding-left:1.5rem!important}.p-lg-5{padding:3rem!important}.pt-lg-5,.py-lg-5{padding-top:3rem!important}.pr-lg-5,.px-lg-5{padding-right:3rem!important}.pb-lg-5,.py-lg-5{padding-bottom:3rem!important}.pl-lg-5,.px-lg-5{padding-left:3rem!important}.m-lg-auto{margin:auto!important}.mt-lg-auto,.my-lg-auto{margin-top:auto!important}.mr-lg-auto,.mx-lg-auto{margin-right:auto!important}.mb-lg-auto,.my-lg-auto{margin-bottom:auto!important}.ml-lg-auto,.mx-lg-auto{margin-left:auto!important}}@media (min-width:1200px){.m-xl-0{margin:0!important}.mt-xl-0,.my-xl-0{margin-top:0!important}.mr-xl-0,.mx-xl-0{margin-right:0!important}.mb-xl-0,.my-xl-0{margin-bottom:0!important}.ml-xl-0,.mx-xl-0{margin-left:0!important}.m-xl-1{margin:.25rem!important}.mt-xl-1,.my-xl-1{margin-top:.25rem!important}.mr-xl-1,.mx-xl-1{margin-right:.25rem!important}.mb-xl-1,.my-xl-1{margin-bottom:.25rem!important}.ml-xl-1,.mx-xl-1{margin-left:.25rem!important}.m-xl-2{margin:.5rem!important}.mt-xl-2,.my-xl-2{margin-top:.5rem!important}.mr-xl-2,.mx-xl-2{margin-right:.5rem!important}.mb-xl-2,.my-xl-2{margin-bottom:.5rem!important}.ml-xl-2,.mx-xl-2{margin-left:.5rem!important}.m-xl-3{margin:1rem!important}.mt-xl-3,.my-xl-3{margin-top:1rem!important}.mr-xl-3,.mx-xl-3{margin-right:1rem!important}.mb-xl-3,.my-xl-3{margin-bottom:1rem!important}.ml-xl-3,.mx-xl-3{margin-left:1rem!important}.m-xl-4{margin:1.5rem!important}.mt-xl-4,.my-xl-4{margin-top:1.5rem!important}.mr-xl-4,.mx-xl-4{margin-right:1.5rem!important}.mb-xl-4,.my-xl-4{margin-bottom:1.5rem!important}.ml-xl-4,.mx-xl-4{margin-left:1.5rem!important}.m-xl-5{margin:3rem!important}.mt-xl-5,.my-xl-5{margin-top:3rem!important}.mr-xl-5,.mx-xl-5{margin-right:3rem!important}.mb-xl-5,.my-xl-5{margin-bottom:3rem!important}.ml-xl-5,.mx-xl-5{margin-left:3rem!important}.p-xl-0{padding:0!important}.pt-xl-0,.py-xl-0{padding-top:0!important}.pr-xl-0,.px-xl-0{padding-right:0!important}.pb-xl-0,.py-xl-0{padding-bottom:0!important}.pl-xl-0,.px-xl-0{padding-left:0!important}.p-xl-1{padding:.25rem!important}.pt-xl-1,.py-xl-1{padding-top:.25rem!important}.pr-xl-1,.px-xl-1{padding-right:.25rem!important}.pb-xl-1,.py-xl-1{padding-bottom:.25rem!important}.pl-xl-1,.px-xl-1{padding-left:.25rem!important}.p-xl-2{padding:.5rem!important}.pt-xl-2,.py-xl-2{padding-top:.5rem!important}.pr-xl-2,.px-xl-2{padding-right:.5rem!important}.pb-xl-2,.py-xl-2{padding-bottom:.5rem!important}.pl-xl-2,.px-xl-2{padding-left:.5rem!important}.p-xl-3{padding:1rem!important}.pt-xl-3,.py-xl-3{padding-top:1rem!important}.pr-xl-3,.px-xl-3{padding-right:1rem!important}.pb-xl-3,.py-xl-3{padding-bottom:1rem!important}.pl-xl-3,.px-xl-3{padding-left:1rem!important}.p-xl-4{padding:1.5rem!important}.pt-xl-4,.py-xl-4{padding-top:1.5rem!important}.pr-xl-4,.px-xl-4{padding-right:1.5rem!important}.pb-xl-4,.py-xl-4{padding-bottom:1.5rem!important}.pl-xl-4,.px-xl-4{padding-left:1.5rem!important}.p-xl-5{padding:3rem!important}.pt-xl-5,.py-xl-5{padding-top:3rem!important}.pr-xl-5,.px-xl-5{padding-right:3rem!important}.pb-xl-5,.py-xl-5{padding-bottom:3rem!important}.pl-xl-5,.px-xl-5{padding-left:3rem!important}.m-xl-auto{margin:auto!important}.mt-xl-auto,.my-xl-auto{margin-top:auto!important}.mr-xl-auto,.mx-xl-auto{margin-right:auto!important}.mb-xl-auto,.my-xl-auto{margin-bottom:auto!important}.ml-xl-auto,.mx-xl-auto{margin-left:auto!important}}

{# /* // Text */ #}
.text-left{text-align:left!important}.text-right{text-align:right!important}.text-center{text-align:center!important}@media (min-width:576px){.text-sm-left{text-align:left!important}.text-sm-right{text-align:right!important}.text-sm-center{text-align:center!important}}@media (min-width:768px){.text-md-left{text-align:left!important}.text-md-right{text-align:right!important}.text-md-center{text-align:center!important}}@media (min-width:992px){.text-lg-left{text-align:left!important}.text-lg-right{text-align:right!important}.text-lg-center{text-align:center!important}}@media (min-width:1200px){.text-xl-left{text-align:left!important}.text-xl-right{text-align:right!important}.text-xl-center{text-align:center!important}}.text-lowercase{text-transform:lowercase!important}.text-uppercase{text-transform:uppercase!important}.text-capitalize{text-transform:capitalize!important}.font-weight-light{font-weight:300!important}.font-weight-normal{font-weight:400!important}.font-weight-bold{font-weight:700!important}.font-italic{font-style:italic!important}

{# /* // Align */ #}
.align-baseline{vertical-align:baseline!important}.align-top{vertical-align:top!important}.align-middle{vertical-align:middle!important}.align-bottom{vertical-align:bottom!important}.align-text-bottom{vertical-align:text-bottom!important}.align-text-top{vertical-align:text-top!important}

{# /* // Position */ #}
.position-sticky{position: sticky!important; position: -webkit-sticky;}.position-relative{position:relative!important}.position-absolute{position:absolute!important;}.position-fixed{position:fixed!important}

{# /* // Image */ #}
.img-fluid {max-width:100%;height:auto}

{# /* // Visibility */ #}
.hidden{display:none}.opacity-50{opacity: .5}.opacity-40{opacity:.4}.opacity-60{opacity:.6}.opacity-80{opacity:.8}.opacity-90{opacity:.9}.overflow-none{overflow:hidden}

{# /* // Float */ #}
.float-left{float:left!important}.float-right{float:right!important}.float-none{float:none!important}

{# /* // Width */ #}
.w-100{width:100%!important}.w-auto{width:auto!important}

{# /* // Height */ #}
.h-auto{height:auto!important}


        </style>
<link rel="stylesheet" type="text/css" href="//acdn.mitiendanube.com/stores/001/779/198/themes/amazonas/style-colors-9fa1de3769eeb638533de67576c29f97.css" media="all" />
<link rel="stylesheet" href="//acdn.mitiendanube.com/stores/001/779/198/themes/amazonas/style-async-8f7541ebe38e22a0658215877cadd10c.css" media="print" onload="this.media='all'">
<style>
            
        </style>
<link href="//acdn.mitiendanube.com/stores/001/779/198/themes/common/logo-409612259-1710687006-dc56a319d24ced9e008d004b40a6b90d1710687006.ico?0" class="js-favicon" rel="icon" type="image/x-icon" />
<link href="//acdn.mitiendanube.com/stores/001/779/198/themes/common/logo-409612259-1710687006-dc56a319d24ced9e008d004b40a6b90d1710687006.ico?0" class="js-favicon" rel="shortcut icon" type="image/x-icon" />
<link rel="canonical" href="https://tekocreaciones.mitiendanube.com/signals/iwl.js/" />
<meta name="nuvempay-logo" content="//d26lpennugtm8s.cloudfront.net/assets/common/img/logos/payment/new_logos_payment/nuvempago@2x.png" />
<meta name="google-site-verification" content="_RlgfCInDpEflUiiTh28heqQfKCGXXsxnKYTetC8LRo" />
<meta name="p:domain_verify" content="1ea01490410ff92d26033a837124d520" />
<script type="text/javascript">
    var LS = LS || {};

    LS.store = {
        id : 1779198,
        url : "tekocreaciones.mitiendanube.com",
        custom_url : "tekocreaciones.mitiendanube.com",
        checkout_express : false,
        gads_measurement_id : "",
    };
    LS.cart = {
        id : null,
        subtotal : 0,
        has_non_shippable_products: false,
        has_shippable_products: false,
        items : [
                    ]
    };
    LS.abStorefrontCartExperiments = null;
    LS.lang = "es_AR";
    LS.langCode = "es";
    LS.currency = {
        code : "ARS",
        display_short: "\u0024",
        display_long: "\u0024\u0020ARS",
        cents_separator : ",",
        thousands_separator : "."
    };
    LS.country = "AR";
                LS.customer = null;
    LS.template= "404";
    LS.theme = {
        code: "amazonas",
        name: "Amazonas",
        custom: false,
    };
    LS.metricsWorkerScriptUrl = "https://acdn.mitiendanube.com/assets/stores/js/metrics-worker-c984926f96a2e4787f155a9755d6944a30.js?v=69594491"

    LS.socialScripts = [];
    LS.DOMReady = function(fn) {
        if (document.addEventListener) {
            document.addEventListener('DOMContentLoaded', fn);
        } else {
            document.attachEvent('onreadystatechange', function() {
                if (document.readyState === 'interactive')
                    fn();
            });
        }
    };

    // Making it a thenable so it can be made into a full fledged Promise later
    LS._readyCallbacks = [];
    LS.ready = {
        then: function(callback){
            LS._readyCallbacks.push(callback);
        }
    };

    window.addEventListener('load', () => {
        if(!window.cartService) {
            return;
        }

        window.cartService.setCurrentLoadTime(1721960592);
    });

    window.pageData = {
        id: "",
        name: ""
    }

    window.initialCart = {"id":null,"subtotal":0,"total":0,"discounts":0,"promotions":[],"shipping_zipcode":null};
    window.metricServiceDispatchQueue = [];
    window.metricService = { dispatch: (event) => window.metricServiceDispatchQueue.push(event) };

    window.translations = {
        cart: {
            error_messages: {
                out_of_stock: 'No hay más stock de este producto.',
                unavailable_product: 'Este producto no está disponible.',
                update_error: 'Ocurrió un error al actualizar el carrito.'
            },
            name: 'Carrito de compras'
        }
    };
</script>
<script>
        window.recaptchaEnabled = true;
        window.recaptchaV2 = { siteKey: '6LdvubwUAAAAAKg5583RDx5WbiQg-J3lUa_INUHR' };
        window.recaptchaV3 = { siteKey: '6LezGnQcAAAAAD5T1ReYv_OMo1EJbDUfPu7srRhU' };
    </script>
<script>
    window.enableNativeLibraries = true;
    window.hasMetricsTag = false;
</script>
<script type="text/javascript" src="//acdn.mitiendanube.com/assets/stores/js/linkedstore-v2-e55a66e7b1ac469db7582e367b7bddf430.js?v=69594491" async="true"></script>
<script>window.vanillaJS = true;</script>
<script type="text/javascript">
            window.skipJQuery = true;
    
    LS.ready.then(() =>  {
        if (!window.jQueryNuvem) {
            window.jQueryNuvem = $
        }
    });
</script>
<script type="text/javascript">

    function ga_send_event(category, action, label, value) {
                    return;
            }

    </script>
<script>
        !function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
        n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
        n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
        t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
        document,'script','https://connect.facebook.net/en_US/fbevents.js');
    </script>
<noscript>
        <img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=3478284019107587&ev=PageView&noscript=1"/>
    </noscript>
<script>
        var fb_params = {
            referrer: document.referrer,
            userAgent: navigator.userAgent,
            language: 'es-AR'
        };
                let pixelFunction = 'track';
        let pixelEvent = null;
        let eventID = null;
        const fbTimestamp = new Date().getTime();
        const contentType = 'product';
        
        LS.ready.then(function() {
            let sessionID = cookieService.get('store_login_session');
            if (sessionID) {
                sessionID = sessionID.slice(-40).toLowerCase();
            }
            fbq('init', '3478284019107587',
                { external_id: sessionID, agent: 'tiendanube-core' }
            );
            fbq('track', 'PageView');
            if(pixelEvent) {
                fbq(pixelFunction, pixelEvent, fb_params, { eventID });
                if (pixelEvent === 'AddToCart') {
                    const cartItemId = '';
                    const unitPrice = 0;
                    const quantity = fb_params['value'] / unitPrice;
                    const data = {
                        ...fb_params,
                        quantity
                    };
                    sendNubeSocialTracking(LS.cart.id, cartItemId, data, eventID);
                }
            }

                        LS.on(LS.events.productAddedToCart, function (event, data) {
                if (!data) {
                    data = event.detail;
                }

                const { cart_item: cartItem, quantity_added: quantityAdded } = data;
                const value = cartItem.unit_price / 100 * quantityAdded;

                // Facebook Pixel does not have an event to remove products from the cart.
                if (value <= 0) {
                    return;
                }

                const ajaxAddToCartTimestamp = new Date().getTime();
                const eventName = 'AddToCart';
                                const eventId = `${cartItem.variant_id}_add_to_cart_${ajaxAddToCartTimestamp}`;
                
                const customData = {
                    referrer: document.referrer,
                    userAgent: navigator.userAgent,
                    language: 'es-AR',
                    content_ids: [cartItem.variant_id.toString()],
                    content_type: 'product',
                    currency: LS.currency.code,
                    quantity: quantityAdded,
                    value
                };

                trackAddToCartAJAX(customData, eventId);
                sendNubeSocialTracking(LS.cart.id, cartItem.id, customData, eventId);
            });
        });

        function trackAddToCartAJAX(customData, eventID) {
            const eventName = 'AddToCart';
            fbq('track', eventName, customData, { eventID });
        }

        async function sendNubeSocialTracking(cartId, cartItemId, customData, eventId) {
            let data = {
                event_name: 'AddToCart',
                cart_id: cartId,
                cart_product_id: cartItemId,
                event_id: eventId,
            };

            Object.assign(data, customData)

            setTimeout(function() {
                new Image().src = '/fb-capi/?' + new URLSearchParams(data);
            }, 500);
        }
    </script>
<script type="text/javascript">
    function amplitude_log_event(event, properties) {
        // dummy function
        return true;
    }
</script>
<script type="application/ld+json" data-component="structured-data.page">
    {
        "@context": "https://schema.org/",
        "@type": "WebPage",
        "name": "",
                "breadcrumb": {
            "@type": "BreadcrumbList",
            "itemListElement": [
            {
                "@type": "ListItem",
                "position": 1,
                "name": "Inicio",
                "item": "https://tekocreaciones.mitiendanube.com"
            },                                                    ]
        }    }
    </script>
</head>
<body class="js-head-offset head-offset  template-404" data-rounded-borders="true" data-solid-icons="true">
<svg xmlns="http://www.w3.org/2000/svg" class="hidden">
<symbol id="check" viewBox="0 0 512 512">
<path d="M173.898 439.404l-166.4-166.4c-9.997-9.997-9.997-26.206 0-36.204l36.203-36.204c9.997-9.998 26.207-9.998 36.204 0L192 312.69 432.095 72.596c9.997-9.997 26.207-9.997 36.204 0l36.203 36.204c9.997 9.997 9.997 26.206 0 36.204l-294.4 294.401c-9.998 9.997-26.207 9.997-36.204-.001z" />
</symbol>
<symbol id="check-double" viewBox="0 0 448 512">
<path d="M444.09 166.99l-27.39-28.37c-2.6-1.96-5.53-2.93-8.8-2.93-3.27 0-5.87.98-7.82 2.93L142.81 396.86l-94.88-94.88c-1.96-2.61-4.55-3.91-7.82-3.91-3.27 0-6.21 1.3-8.8 3.91l-27.4 27.38c-2.6 2.61-3.91 5.55-3.91 8.8s1.31 5.87 3.91 7.82l130.1 131.07c2.6 1.96 5.53 2.94 8.8 2.94 3.27 0 5.87-.98 7.82-2.94L444.08 183.6c2.6-2.61 3.91-5.55 3.91-8.8.01-3.24-1.3-5.86-3.9-7.81zM131.88 285.04c2.62 1.97 5.58 2.96 8.88 2.96s5.92-.99 7.89-2.96L353.34 80.35c2.62-2.64 3.95-5.6 3.95-8.88 0-3.28-1.33-5.92-3.95-7.89l-27.63-28.62c-2.62-1.97-5.58-2.96-8.88-2.96s-5.92.99-7.89 2.96L140.76 204.12l-60.41-60.41c-1.97-2.64-4.59-3.95-7.89-3.95s-6.26 1.31-8.88 3.95l-27.63 27.63c-2.62 2.64-3.95 5.6-3.95 8.88 0 3.29 1.33 5.92 3.95 7.89l95.93 96.93z" />
</symbol>
<symbol id="check-circle" viewBox="0 0 512 512">
<path d="M256 8C119.033 8 8 119.033 8 256s111.033 248 248 248 248-111.033 248-248S392.967 8 256 8zm0 48c110.532 0 200 89.451 200 200 0 110.532-89.451 200-200 200-110.532 0-200-89.451-200-200 0-110.532 89.451-200 200-200m140.204 130.267l-22.536-22.718c-4.667-4.705-12.265-4.736-16.97-.068L215.346 303.697l-59.792-60.277c-4.667-4.705-12.265-4.736-16.97-.069l-22.719 22.536c-4.705 4.667-4.736 12.265-.068 16.971l90.781 91.516c4.667 4.705 12.265 4.736 16.97.068l172.589-171.204c4.704-4.668 4.734-12.266.067-16.971z" />
</symbol>
<symbol id="check-circle-filled" viewBox="0 0 512 512">
<path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z" />
</symbol>
<symbol id="history" viewBox="0 0 512 512">
<path d="M20 24h10c6.627 0 12 5.373 12 12v94.625C85.196 57.047 165.239 7.715 256.793 8.001 393.18 8.428 504.213 120.009 504 256.396 503.786 393.181 392.834 504 256 504c-63.926 0-122.202-24.187-166.178-63.908-5.113-4.618-5.354-12.561-.482-17.433l7.069-7.069c4.503-4.503 11.749-4.714 16.482-.454C150.782 449.238 200.935 470 256 470c117.744 0 214-95.331 214-214 0-117.744-95.331-214-214-214-82.862 0-154.737 47.077-190.289 116H164c6.627 0 12 5.373 12 12v10c0 6.627-5.373 12-12 12H20c-6.627 0-12-5.373-12-12V36c0-6.627 5.373-12 12-12zm321.647 315.235l4.706-6.47c3.898-5.36 2.713-12.865-2.647-16.763L272 263.853V116c0-6.627-5.373-12-12-12h-8c-6.627 0-12 5.373-12 12v164.147l84.884 61.734c5.36 3.899 12.865 2.714 16.763-2.646z" />
</symbol>
<symbol id="edit" viewBox="0 0 576 512">
<path d="M402.6 83.2l90.2 90.2c3.8 3.8 3.8 10 0 13.8L274.4 405.6l-92.8 10.3c-12.4 1.4-22.9-9.1-21.5-21.5l10.3-92.8L388.8 83.2c3.8-3.8 10-3.8 13.8 0zm162-22.9l-48.8-48.8c-15.2-15.2-39.9-15.2-55.2 0l-35.4 35.4c-3.8 3.8-3.8 10 0 13.8l90.2 90.2c3.8 3.8 10 3.8 13.8 0l35.4-35.4c15.2-15.3 15.2-40 0-55.2zM384 346.2V448H64V128h229.8c3.2 0 6.2-1.3 8.5-3.5l40-40c7.6-7.6 2.2-20.5-8.5-20.5H48C21.5 64 0 85.5 0 112v352c0 26.5 21.5 48 48 48h352c26.5 0 48-21.5 48-48V306.2c0-10.7-12.9-16-20.5-8.5l-40 40c-2.2 2.3-3.5 5.3-3.5 8.5z" />
</symbol>
<symbol id="whatsapp" viewBox="0 0 448 512">
<path d="M380.9 97.1C339 55.1 283.2 32 223.9 32c-122.4 0-222 99.6-222 222 0 39.1 10.2 77.3 29.6 111L0 480l117.7-30.9c32.4 17.7 68.9 27 106.1 27h.1c122.3 0 224.1-99.6 224.1-222 0-59.3-25.2-115-67.1-157zm-157 341.6c-33.2 0-65.7-8.9-94-25.7l-6.7-4-69.8 18.3L72 359.2l-4.4-7c-18.5-29.4-28.2-63.3-28.2-98.2 0-101.7 82.8-184.5 184.6-184.5 49.3 0 95.6 19.2 130.4 54.1 34.8 34.9 56.2 81.2 56.1 130.5 0 101.8-84.9 184.6-186.6 184.6zm101.2-138.2c-5.5-2.8-32.8-16.2-37.9-18-5.1-1.9-8.8-2.8-12.5 2.8-3.7 5.6-14.3 18-17.6 21.8-3.2 3.7-6.5 4.2-12 1.4-32.6-16.3-54-29.1-75.5-66-5.7-9.8 5.7-9.1 16.3-30.3 1.8-3.7.9-6.9-.5-9.7-1.4-2.8-12.5-30.1-17.1-41.2-4.5-10.8-9.1-9.3-12.5-9.5-3.2-.2-6.9-.2-10.6-.2-3.7 0-9.7 1.4-14.8 6.9-5.1 5.6-19.4 19-19.4 46.3 0 27.3 19.9 53.7 22.6 57.4 2.8 3.7 39.1 59.7 94.8 83.8 35.2 15.2 49 16.5 66.6 13.9 10.7-1.6 32.8-13.4 37.4-26.4 4.6-13 4.6-24.1 3.2-26.4-1.3-2.5-5-3.9-10.5-6.6z" />
</symbol>
<symbol id="instagram" viewBox="0 0 448 512">
<path d="M224.1 141c-63.6 0-114.9 51.3-114.9 114.9s51.3 114.9 114.9 114.9S339 319.5 339 255.9 287.7 141 224.1 141zm0 189.6c-41.1 0-74.7-33.5-74.7-74.7s33.5-74.7 74.7-74.7 74.7 33.5 74.7 74.7-33.6 74.7-74.7 74.7zm146.4-194.3c0 14.9-12 26.8-26.8 26.8-14.9 0-26.8-12-26.8-26.8s12-26.8 26.8-26.8 26.8 12 26.8 26.8zm76.1 27.2c-1.7-35.9-9.9-67.7-36.2-93.9-26.2-26.2-58-34.4-93.9-36.2-37-2.1-147.9-2.1-184.9 0-35.8 1.7-67.6 9.9-93.9 36.1s-34.4 58-36.2 93.9c-2.1 37-2.1 147.9 0 184.9 1.7 35.9 9.9 67.7 36.2 93.9s58 34.4 93.9 36.2c37 2.1 147.9 2.1 184.9 0 35.9-1.7 67.7-9.9 93.9-36.2 26.2-26.2 34.4-58 36.2-93.9 2.1-37 2.1-147.8 0-184.8zM398.8 388c-7.8 19.6-22.9 34.7-42.6 42.6-29.5 11.7-99.5 9-132.1 9s-102.7 2.6-132.1-9c-19.6-7.8-34.7-22.9-42.6-42.6-11.7-29.5-9-99.5-9-132.1s-2.6-102.7 9-132.1c7.8-19.6 22.9-34.7 42.6-42.6 29.5-11.7 99.5-9 132.1-9s102.7-2.6 132.1 9c19.6 7.8 34.7 22.9 42.6 42.6 11.7 29.5 9 99.5 9 132.1s2.7 102.7-9 132.1z" />
</symbol>
<symbol id="facebook" viewBox="0 0 1024 1024">
<path d="M1024 512a512 512 0 1 0-592 505.8V660H302V512h130V399.2C432 270.9 508.4 200 625.4 200c56 0 114.6 10 114.6 10v126h-64.6c-63.6 0-83.4 39.5-83.4 80v96h142l-22.7 148H592v357.8A512 512 0 0 0 1024 512z" />
</symbol>
<symbol id="facebook-f" viewBox="0 0 320 512">
<path d="M279.1 288l14.3-92.7h-89v-60c0-25.4 12.5-50.2 52.3-50.2H297V6.4S260.4 0 225.4 0C152 0 104.3 44.4 104.3 124.7v70.6H22.9V288h81.4v224h100.2V288z" />
</symbol>
<symbol id="twitter" viewBox="0 0 512 512">
<path d="M389.2 48h70.6L305.6 224.2 487 464H345L233.7 318.6 106.5 464H35.8L200.7 275.5 26.8 48H172.4L272.9 180.9 389.2 48zM364.4 421.8h39.1L151.1 88h-42L364.4 421.8z" />
</symbol>
<symbol id="pinterest" viewBox="0 0 384 512">
<path d="M204 6.5C101.4 6.5 0 74.9 0 185.6 0 256 39.6 296 63.6 296c9.9 0 15.6-27.6 15.6-35.4 0-9.3-23.7-29.1-23.7-67.8 0-80.4 61.2-137.4 140.4-137.4 68.1 0 118.5 38.7 118.5 109.8 0 53.1-21.3 152.7-90.3 152.7-24.9 0-46.2-18-46.2-43.8 0-37.8 26.4-74.4 26.4-113.4 0-66.2-93.9-54.2-93.9 25.8 0 16.8 2.1 35.4 9.6 50.7-13.8 59.4-42 147.9-42 209.1 0 18.9 2.7 37.5 4.5 56.4 3.4 3.8 1.7 3.4 6.9 1.5 50.4-69 48.6-82.5 71.4-172.8 12.3 23.4 44.1 36 69.3 36 106.2 0 153.9-103.5 153.9-196.8C384 71.3 298.2 6.5 204 6.5z" />
</symbol>
</svg>
<svg xmlns="http://www.w3.org/2000/svg" class="hidden">
<symbol id="bars" viewBox="0 0 448 512">
<path d="M16 132h416c8.837 0 16-7.163 16-16V76c0-8.837-7.163-16-16-16H16C7.163 60 0 67.163 0 76v40c0 8.837 7.163 16 16 16zm0 160h416c8.837 0 16-7.163 16-16v-40c0-8.837-7.163-16-16-16H16c-8.837 0-16 7.163-16 16v40c0 8.837 7.163 16 16 16zm0 160h416c8.837 0 16-7.163 16-16v-40c0-8.837-7.163-16-16-16H16c-8.837 0-16 7.163-16 16v40c0 8.837 7.163 16 16 16z" />
</symbol>
<symbol id="cart" viewBox="0 0 38 32.5">
<path d="M18.5,28.5a4,4,0,1,1-4-4A4,4,0,0,1,18.5,28.5Zm11-4a4,4,0,1,0,4,4A4,4,0,0,0,29.5,24.5Zm5.44-3.44,3-13A2.5,2.5,0,0,0,35.5,5H16a2.5,2.5,0,0,0,0,5H32.36l-1.85,8h-17L9.94,2A2.49,2.49,0,0,0,7.5,0h-5a2.5,2.5,0,0,0,0,5h3L9.06,21a2.49,2.49,0,0,0,2.44,2h21A2.51,2.51,0,0,0,34.94,21.06Z" />
</symbol>
<symbol id="search" viewBox="0 0 31.5 32">
<path d="M30.77,27.73l-8-8a12.57,12.57,0,1,0-3.64,3.43l8.15,8.16a2.51,2.51,0,0,0,3.54,0A2.52,2.52,0,0,0,30.77,27.73ZM5,12.5A7.5,7.5,0,1,1,12.5,20,7.5,7.5,0,0,1,5,12.5Z" />
</symbol>
<symbol id="user" viewBox="0 0 29 32.49">
<path d="M26.5,32.49H2.5A2.5,2.5,0,0,1,0,30C0,23.8,6.5,18.76,14.5,18.76S29,23.8,29,30A2.5,2.5,0,0,1,26.5,32.49Zm-20.67-5H23.17c-1.5-2.17-4.87-3.73-8.67-3.73S7.33,25.32,5.83,27.49ZM14.5,5a4,4,0,1,1-4,4,4,4,0,0,1,4-4m0-5a9,9,0,1,0,9,9,9,9,0,0,0-9-9Z" />
</symbol>
<symbol id="chat" viewBox="0 0 39 34.14">
<path d="M6.68,24.43a2.5,2.5,0,0,1-2-3.94A5.43,5.43,0,0,1,0,15.13V5.41A5.42,5.42,0,0,1,5.41,0H22.9a5.41,5.41,0,0,1,5.41,5.41v9.72a5.41,5.41,0,0,1-5.41,5.41H11.69L8.43,23.72A2.53,2.53,0,0,1,6.68,24.43ZM5.41,5A.42.42,0,0,0,5,5.41v9.72a.42.42,0,0,0,.41.41H22.9a.42.42,0,0,0,.41-.41V5.41A.42.42,0,0,0,22.9,5Zm26.9,29.14A2.45,2.45,0,0,1,31,33.75L25.5,30.26H17.15a5.42,5.42,0,0,1-5.42-5.42,2.5,2.5,0,0,1,5,0,.44.44,0,0,0,.42.42H33.59a.43.43,0,0,0,.41-.42V15.13a.43.43,0,0,0-.41-.42h-.75a2.5,2.5,0,0,1,0-5h.75A5.42,5.42,0,0,1,39,15.13v9.71a5.41,5.41,0,0,1-4.64,5.36,2.5,2.5,0,0,1-2,3.94Z" />
</symbol>
<symbol id="arrow" viewBox="0 0 448 512">
<path d="M190.5 66.9l22.2-22.2c9.4-9.4 24.6-9.4 33.9 0L441 239c9.4 9.4 9.4 24.6 0 33.9L246.6 467.3c-9.4 9.4-24.6 9.4-33.9 0l-22.2-22.2c-9.5-9.5-9.3-25 .4-34.3L311.4 296H24c-13.3 0-24-10.7-24-24v-32c0-13.3 10.7-24 24-24h287.4L190.9 101.2c-9.8-9.3-10-24.8-.4-34.3z" />
</symbol>
<symbol id="chevron" viewBox="0 0 320 512">
<path d="M285.476 272.971L91.132 467.314c-9.373 9.373-24.569 9.373-33.941 0l-22.667-22.667c-9.357-9.357-9.375-24.522-.04-33.901L188.505 256 34.484 101.255c-9.335-9.379-9.317-24.544.04-33.901l22.667-22.667c9.373-9.373 24.569-9.373 33.941 0L285.475 239.03c9.373 9.372 9.373 24.568.001 33.941z" />
</symbol>
<symbol id="chevron-down" viewBox="0 0 448 512">
<path d="M207.029 381.476L12.686 187.132c-9.373-9.373-9.373-24.569 0-33.941l22.667-22.667c9.357-9.357 24.522-9.375 33.901-.04L224 284.505l154.745-154.021c9.379-9.335 24.544-9.317 33.901.04l22.667 22.667c9.373 9.373 9.373 24.569 0 33.941L240.971 381.476c-9.373 9.372-24.569 9.372-33.942 0z" />
</symbol>
<symbol id="arrows-h" viewBox="0 0 512 512">
<path d="M105.815 288h300.371l-46.208 43.728c-9.815 9.289-10.03 24.846-.474 34.402l10.84 10.84c9.373 9.373 24.569 9.373 33.941 0l98.343-98.343c12.497-12.497 12.497-32.758 0-45.255l-98.343-98.343c-9.373-9.373-24.569-9.373-33.941 0l-10.84 10.84c-9.556 9.556-9.341 25.113.474 34.402L406.186 224H105.815l46.208-43.728c9.815-9.289 10.03-24.846.474-34.402l-10.84-10.84c-9.373-9.373-24.569-9.373-33.941 0L9.373 233.372c-12.497 12.497-12.497 32.758 0 45.255l98.343 98.343c9.373 9.373 24.569 9.373 33.941 0l10.84-10.84c9.556-9.556 9.341-25.113-.474-34.402L105.815 288z" />
</symbol>
<symbol id="sort-alt" viewBox="0 0 384 512">
<path d="M176 352h-48V48a16 16 0 0 0-16-16H80a16 16 0 0 0-16 16v304H16c-14.19 0-21.36 17.24-11.29 27.31l80 96a16 16 0 0 0 22.62 0l80-96C197.35 369.26 190.22 352 176 352zm203.29-219.31l-80-96a16 16 0 0 0-22.62 0l-80 96C186.65 142.74 193.78 160 208 160h48v304a16 16 0 0 0 16 16h32a16 16 0 0 0 16-16V160h48c14.19 0 21.36-17.24 11.29-27.31z" />
</symbol>
<symbol id="minus" viewBox="0 0 448 512">
<path d="M416 208H32c-17.67 0-32 14.33-32 32v32c0 17.67 14.33 32 32 32h384c17.67 0 32-14.33 32-32v-32c0-17.67-14.33-32-32-32z" />
</symbol>
<symbol id="plus" viewBox="0 0 448 512">
<path d="M416 208H272V64c0-17.67-14.33-32-32-32h-32c-17.67 0-32 14.33-32 32v144H32c-17.67 0-32 14.33-32 32v32c0 17.67 14.33 32 32 32h144v144c0 17.67 14.33 32 32 32h32c17.67 0 32-14.33 32-32V304h144c17.67 0 32-14.33 32-32v-32c0-17.67-14.33-32-32-32z" />
</symbol>
<symbol id="circle-notch" viewBox="0 0 512 512">
<path d="M288 39.056v16.659c0 10.804 7.281 20.159 17.686 23.066C383.204 100.434 440 171.518 440 256c0 101.689-82.295 184-184 184-101.689 0-184-82.295-184-184 0-84.47 56.786-155.564 134.312-177.219C216.719 75.874 224 66.517 224 55.712V39.064c0-15.709-14.834-27.153-30.046-23.234C86.603 43.482 7.394 141.206 8.003 257.332c.72 137.052 111.477 246.956 248.531 246.667C393.255 503.711 504 392.788 504 256c0-115.633-79.14-212.779-186.211-240.236C302.678 11.889 288 23.456 288 39.056z" />
</symbol>
<symbol id="filter" viewBox="0 0 512 512">
<path d="M487.976 0H24.028C2.71 0-8.047 25.866 7.058 40.971L192 225.941V432c0 7.831 3.821 15.17 10.237 19.662l80 55.98C298.02 518.69 320 507.493 320 487.98V225.941l184.947-184.97C520.021 25.896 509.338 0 487.976 0z" />
</symbol>
<symbol id="times" viewBox="0 0 352 512" aria-hidden="true">
<path d="M242.72 256l100.07-100.07c12.28-12.28 12.28-32.19 0-44.48l-22.24-22.24c-12.28-12.28-32.19-12.28-44.48 0L176 189.28 75.93 89.21c-12.28-12.28-32.19-12.28-44.48 0L9.21 111.45c-12.28 12.28-12.28 32.19 0 44.48L109.28 256 9.21 356.07c-12.28 12.28-12.28 32.19 0 44.48l22.24 22.24c12.28 12.28 32.2 12.28 44.48 0L176 322.72l100.07 100.07c12.28 12.28 32.2 12.28 44.48 0l22.24-22.24c12.28-12.28 12.28-32.19 0-44.48L242.72 256z" />
</symbol>
<symbol id="trash-alt" viewBox="0 0 448 512">
<path d="M32 464a48 48 0 0 0 48 48h288a48 48 0 0 0 48-48V128H32zm272-256a16 16 0 0 1 32 0v224a16 16 0 0 1-32 0zm-96 0a16 16 0 0 1 32 0v224a16 16 0 0 1-32 0zm-96 0a16 16 0 0 1 32 0v224a16 16 0 0 1-32 0zM432 32H312l-9.4-18.7A24 24 0 0 0 281.1 0H166.8a23.72 23.72 0 0 0-21.4 13.3L136 32H16A16 16 0 0 0 0 48v32a16 16 0 0 0 16 16h416a16 16 0 0 0 16-16V48a16 16 0 0 0-16-16z" />
</symbol>
<symbol id="eye" viewBox="0 0 576 512">
<path d="M572.52 241.4C518.29 135.59 410.93 64 288 64S57.68 135.64 3.48 241.41a32.35 32.35 0 0 0 0 29.19C57.71 376.41 165.07 448 288 448s230.32-71.64 284.52-177.41a32.35 32.35 0 0 0 0-29.19zM288 400a144 144 0 1 1 144-144 143.93 143.93 0 0 1-144 144zm0-240a95.31 95.31 0 0 0-25.31 3.79 47.85 47.85 0 0 1-66.9 66.9A95.78 95.78 0 1 0 288 160z" />
</symbol>
<symbol id="eye-closed" viewBox="0 0 640 512">>
<path d="M320 400c-75.85 0-137.25-58.71-142.9-133.11L72.2 185.82c-13.79 17.3-26.48 35.59-36.72 55.59a32.35 32.35 0 0 0 0 29.19C89.71 376.41 197.07 448 320 448c26.91 0 52.87-4 77.89-10.46L346 397.39a144.13 144.13 0 0 1-26 2.61zm313.82 58.1l-110.55-85.44a331.25 331.25 0 0 0 81.25-102.07 32.35 32.35 0 0 0 0-29.19C550.29 135.59 442.93 64 320 64a308.15 308.15 0 0 0-147.32 37.7L45.46 3.37A16 16 0 0 0 23 6.18L3.37 31.45A16 16 0 0 0 6.18 53.9l588.36 454.73a16 16 0 0 0 22.46-2.81l19.64-25.27a16 16 0 0 0-2.82-22.45zm-183.72-142l-39.3-30.38A94.75 94.75 0 0 0 416 256a94.76 94.76 0 0 0-121.31-92.21A47.65 47.65 0 0 1 304 192a46.64 46.64 0 0 1-1.54 10l-73.61-56.89A142.31 142.31 0 0 1 320 112a143.92 143.92 0 0 1 144 144c0 21.63-5.29 41.79-13.9 60.11z">
</symbol>
<symbol id="credit-card" viewBox="0 0 576 512">
<path d="M498.6,41.6H77.5C34.7,41.6,0,76.4,0,119.1v273.8c0,42.7,34.7,77.4,77.5,77.4h421c42.8,0,77.5-34.7,77.6-77.5V119.1
	C576.1,76.3,541.3,41.6,498.6,41.6z M203.8,386.1H98.5c-7.9,0-14.3-6.4-14.3-14.3c0-7.9,6.4-14.3,14.3-14.3h105.3
	c7.9,0,14.3,6.4,14.3,14.3S211.7,386.1,203.8,386.1z M218.1,245.5c0,7.9-6.4,14.3-14.3,14.3H98.5c-7.9,0-14.3-6.4-14.3-14.3V140.2 c0-7.9,6.4-14.3,14.3-14.3h105.3c7.9,0,14.3,6.4,14.3,14.3V245.5z M351.2,386.1H245.9c-7.9,0-14.3-6.4-14.3-14.3 c0-7.9,6.4-14.3,14.3-14.3h105.3c7.9,0,14.3,6.4,14.3,14.3S359.1,386.1,351.2,386.1z M498.6,386.1H393.3c-7.9,0-14.3-6.4-14.3-14.3 c0-7.9,6.4-14.3,14.3-14.3h105.2c7.9,0,14.3,6.4,14.3,14.3S506.4,386.1,498.6,386.1z M498.5,154.5h-42.1c-7.9,0-14.3-6.4-14.3-14.3 c0-7.9,6.4-14.3,14.3-14.3h42.1c7.9,0,14.3,6.4,14.3,14.3C512.8,148.1,506.4,154.5,498.5,154.5z" />
</symbol>
<symbol id="money-bill" viewBox="0 0 640 512" aria-hidden="true">
<path d="M608 64H32A32 32 0 000 96v320a32 32 0 0032 32h576a32 32 0 0032-32V96a32 32 0 00-32-32zM48 400v-64a64 64 0 0164 64H48zm0-224v-64h64a64 64 0 01-64 64zm272 176c-44.2 0-80-43-80-96s35.8-96 80-96 80 43 80 96-35.8 96-80 96zm272 48h-64a64 64 0 0164-64v64zm0-224a64 64 0 01-64-64h64v64z" />
</symbol>
<symbol id="tag" viewBox="0 0 512 512">
<path d="M0 252.118V48C0 21.49 21.49 0 48 0h204.118a48 48 0 0 1 33.941 14.059l211.882 211.882c18.745 18.745 18.745 49.137 0 67.882L293.823 497.941c-18.745 18.745-49.137 18.745-67.882 0L14.059 286.059A48 48 0 0 1 0 252.118zM112 64c-26.51 0-48 21.49-48 48s21.49 48 48 48 48-21.49 48-48-21.49-48-48-48z" />
</symbol>
<symbol id="info-circle" viewBox="0 0 512 512">
<path d="M256 8C119.043 8 8 119.083 8 256c0 136.997 111.043 248 248 248s248-111.003 248-248C504 119.083 392.957 8 256 8zm0 110c23.196 0 42 18.804 42 42s-18.804 42-42 42-42-18.804-42-42 18.804-42 42-42zm56 254c0 6.627-5.373 12-12 12h-88c-6.627 0-12-5.373-12-12v-24c0-6.627 5.373-12 12-12h12v-64h-12c-6.627 0-12-5.373-12-12v-24c0-6.627 5.373-12 12-12h64c6.627 0 12 5.373 12 12v100h12c6.627 0 12 5.373 12 12v24z" />
</symbol>
<symbol id="map-marker-alt" viewBox="0 0 384 512">
<path d="M172.268 501.67C26.97 291.031 0 269.413 0 192 0 85.961 85.961 0 192 0s192 85.961 192 192c0 77.413-26.97 99.031-172.268 309.67-9.535 13.774-29.93 13.773-39.464 0zM192 272c44.183 0 80-35.817 80-80s-35.817-80-80-80-80 35.817-80 80 35.817 80 80 80z" />
</symbol>
<symbol id="calendar" viewBox="0 0 448 512">
<path d="M0 464c0 26.5 21.5 48 48 48h352c26.5 0 48-21.5 48-48V192H0v272zm64-192c0-8.8 7.2-16 16-16h96c8.8 0 16 7.2 16 16v96c0 8.8-7.2 16-16 16H80c-8.8 0-16-7.2-16-16v-96zM400 64h-48V16c0-8.8-7.2-16-16-16h-32c-8.8 0-16 7.2-16 16v48H160V16c0-8.8-7.2-16-16-16h-32c-8.8 0-16 7.2-16 16v48H48C21.5 64 0 85.5 0 112v48h448v-48c0-26.5-21.5-48-48-48z" />
</symbol>
<symbol id="usd-circle" viewBox="0 0 496 512">
<path d="M248 8C111 8 0 119 0 256s111 248 248 248 248-111 248-248S385 8 248 8zm24 376v16c0 8.8-7.2 16-16 16h-16c-8.8 0-16-7.2-16-16v-16.2c-16.5-.6-32.6-5.8-46.4-15.1-8.7-5.9-10-18.1-2.3-25.2l12-11.3c5.4-5.1 13.3-5.4 19.7-1.6 6.1 3.6 12.9 5.4 19.9 5.4h45c11.3 0 20.5-10.5 20.5-23.4 0-10.6-6.3-19.9-15.2-22.7L205 268c-29-8.8-49.2-37-49.2-68.6 0-39.3 30.6-71.3 68.2-71.4v-16c0-8.8 7.2-16 16-16h16c8.8 0 16 7.2 16 16v16.2c16.5.6 32.6 5.8 46.4 15.1 8.7 5.9 10 18.1 2.3 25.2l-12 11.3c-5.4 5.1-13.3 5.4-19.7 1.6-6.1-3.6-12.9-5.4-19.9-5.4h-45c-11.3 0-20.5 10.5-20.5 23.4 0 10.6 6.3 19.9 15.2 22.7l72 21.9c29 8.8 49.2 37 49.2 68.6.2 39.3-30.4 71.2-68 71.4z" />
</symbol>
<symbol id="truck" viewBox="0 0 640 512">
<path d="M624 352h-16V243.9c0-12.7-5.1-24.9-14.1-33.9L494 110.1c-9-9-21.2-14.1-33.9-14.1H416V48c0-26.5-21.5-48-48-48H48C21.5 0 0 21.5 0 48v320c0 26.5 21.5 48 48 48h16c0 53 43 96 96 96s96-43 96-96h128c0 53 43 96 96 96s96-43 96-96h48c8.8 0 16-7.2 16-16v-32c0-8.8-7.2-16-16-16zM160 464c-26.5 0-48-21.5-48-48s21.5-48 48-48 48 21.5 48 48-21.5 48-48 48zm320 0c-26.5 0-48-21.5-48-48s21.5-48 48-48 48 21.5 48 48-21.5 48-48 48zm80-208H416V144h44.1l99.9 99.9V256z" />
</symbol>
<symbol id="store-alt" viewBox="0 0 640 512">
<path d="M320 384H128V224H64v256c0 17.7 14.3 32 32 32h256c17.7 0 32-14.3 32-32V224h-64v160zm314.6-241.8l-85.3-128c-6-8.9-16-14.2-26.7-14.2H117.4c-10.7 0-20.7 5.3-26.6 14.2l-85.3 128c-14.2 21.3 1 49.8 26.6 49.8H608c25.5 0 40.7-28.5 26.6-49.8zM512 496c0 8.8 7.2 16 16 16h32c8.8 0 16-7.2 16-16V224h-64v272z" />
</symbol>
<symbol id="heart" viewBox="0 0 512 512">
<path d="M462.3 62.6C407.5 15.9 326 24.3 275.7 76.2L256 96.5l-19.7-20.3C186.1 24.3 104.5 15.9 49.7 62.6c-62.8 53.6-66.1 149.8-9.9 207.9l193.5 199.8c12.5 12.9 32.8 12.9 45.3 0l193.5-199.8c56.3-58.1 53-154.3-9.8-207.9z" />
</symbol>
<symbol id="play" viewBox="0 0 488 512">
<path d="M424.4 214.7L72.4 6.6C43.8-10.3 0 6.1 0 47.9V464c0 37.5 40.7 60.1 72.4 41.3l352-208c31.4-18.5 31.5-64.1 0-82.6z" />
</symbol>
<symbol id="phone" viewBox="0 0 512 512">
<path d="M493.4 24.6l-104-24c-11.3-2.6-22.9 3.3-27.5 13.9l-48 112c-4.2 9.8-1.4 21.3 6.9 28l60.6 49.6c-36 76.7-98.9 140.5-177.2 177.2l-49.6-60.6c-6.8-8.3-18.2-11.1-28-6.9l-112 48C3.9 366.5-2 378.1.6 389.4l24 104C27.1 504.2 36.7 512 48 512c256.1 0 464-207.5 464-464 0-11.2-7.7-20.9-18.6-23.4z" />
</symbol>
<symbol id="email" viewBox="0 0 512 512">
<path d="M502.3 190.8c3.9-3.1 9.7-.2 9.7 4.7V400c0 26.5-21.5 48-48 48H48c-26.5 0-48-21.5-48-48V195.6c0-5 5.7-7.8 9.7-4.7 22.4 17.4 52.1 39.5 154.1 113.6 21.1 15.4 56.7 47.8 92.2 47.6 35.7.3 72-32.8 92.3-47.6 102-74.1 131.6-96.3 154-113.7zM256 320c23.2.4 56.6-29.2 73.4-41.4 132.7-96.3 142.8-104.7 173.4-128.7 5.8-4.5 9.2-11.5 9.2-18.9v-19c0-26.5-21.5-48-48-48H48C21.5 64 0 85.5 0 112v19c0 7.4 3.4 14.3 9.2 18.9 30.6 23.9 40.7 32.4 173.4 128.7 16.8 12.2 50.2 41.8 73.4 41.4z" />
</symbol>
</svg>
<div class="js-overlay site-overlay" style="display: none;"></div>
<header class="js-head-main head-main head-primary head-fix transition-soft " data-store="head">
<section class="js-topbar section-topbar ">
<div class="container-fluid">
<div class="row">
<div class="col text-left d-none d-md-block">
<a class="social-icon" href="https://instagram.com/teko_creaciones" target="_blank" aria-label="instagram Teko Creaciones">
<svg class="icon-inline icon-md"><use xlink:href="#instagram" /></svg>
</a>
</div>
<div class="col col-md-6 font-small text-center">
<a class="link-contrast" href="https://www.instagram.com/teko_creaciones/">
¡NO OLVIDES ETIQUETARNOS EN INSTAGRAM CON TU PRODUCTO TEKO!
</a>
</div> <div class="col text-right d-none d-md-block">
</div>
</div>
</div>
</section>
<div class="container-fluid ">
<div class=" row no-gutters align-items-center">
<div class="col-auto text-left d-block d-md-none">
<a href="#" class="js-modal-open utilities-link utilities-item" data-toggle="#nav-hamburger" aria-label="Menú" data-component="menu-button">
<svg class="icon-inline icon-2x icon-w-14"><use xlink:href="#bars" /></svg>
</a>
<div class="js-quick-login-badge badge badge-overlap swing" style="display: none;"></div>
</div>
<div class="col-auto order-2  d-block d-md-none">
<a href="#" class="js-modal-open utilities-link utilities-item" data-toggle="#nav-search" aria-label="Buscador">
<svg class="icon-inline icon-2x"><use xlink:href="#search" /></svg>
</a>
</div>
<div class="col-md-3 col-lg-3 col text-center text-md-left">
<div id="logo" class="logo-img-container ">
<a href="https://tekocreaciones.mitiendanube.com" title><img src="//acdn.mitiendanube.com/stores/001/779/198/themes/common/logo-1836785482-1710686768-d2beb62591c040505caece8144dbb79e1710686769-320-0.webp" alt="Teko Creaciones" class="logo-img transition-soft logo-img-big" width="575" height="230" /></a>
</div>
</div>
<div class="col-6 d-none d-md-block text-center col-md-6 col-lg-6">
<form class="js-search-container js-search-form search-container" action="/search/" method="get">
<div class="form-group m-0">
<input class="js-search-input form-control search-input" autocomplete="off" type="search" name="q" placeholder="¿Qué estás buscando?" aria-label="¿Qué estás buscando?" />
<button type="submit" class="btn search-input-submit" value="Buscar" aria-label="Buscar">
<svg class="icon-inline icon-2x"><use xlink:href="#search" /></svg>
</button>
</div>
</form>
<div class="js-search-suggest search-suggest">
</div>
</div>
<div class="col-auto order-last col-md-3 col-lg-3 text-right ">
<div class="utilities-container  ">
<div class="js-utilities-item nav-dropdown utilities-item transition-soft d-none d-md-inline-block ">
<div class="utility-head text-center">
<svg class="icon-inline icon-2x icon-w-20 "><use xlink:href="#chat" /></svg>
<span class="utility-name transition-soft d-block font-weight-bold ">Ayuda</span>
</div>
<ul class="js-subutility-list nav-dropdown-content subutility-list">
<li class="subutility-list-item">
<a href="https://wa.me/543435352957" class="contact-link">
<svg class="icon-inline icon-md mr-1"><use xlink:href="#whatsapp" /></svg> 543435352957
</a>
</li>
<li class="subutility-list-item">
<a href="/cdn-cgi/l/email-protection#1662737d7975647377757f7978736556717b777f7a3875797b" class="contact-link">
<svg class="icon-inline icon-md mr-1"><use xlink:href="#email" /></svg> <span class="__cf_email__" data-cfemail="ef9b8a84808c9d8a8e8c8680818a9caf88828e8683c18c8082">[email&#160;protected]</span>
</a>
</li>
</ul>
</div>
<div class="nav-dropdown utilities-item transition-soft d-none d-md-inline-block " data-store="account-links">
<div class="js-utilities-item">
<div class="utility-head text-center">
<svg class="icon-inline icon-2x icon-w-18 "><use xlink:href="#user" /></svg>
<a data-toggle="#quick-login" class="js-modal-open js-quick-login-badge" style="display: none;">
<div class="badge badge-overlap swing"></div>
</a>
<span class="utility-name transition-soft d-block font-weight-bold ">
Mi cuenta
</span>
</div>
<ul class="js-subutility-list nav-dropdown-content subutility-list">
<li class="subutility-list-item nav-accounts-item"><a href="/account/register" title class="nav-accounts-link">Crear cuenta</a></li>
<li class="subutility-list-item nav-accounts-item"><a href="/account/login/" title class="js-login nav-accounts-link">Iniciar sesión</a></li>
</ul>
</div>
</div>
<div class="utilities-item ">
<div id="ajax-cart" class="cart-summary transition-soft utility-head text-center" data-component="cart-button">
<a href="#" class="js-modal-open js-toggle-cart js-fullscreen-modal-open" data-toggle="#modal-cart" data-modal-url="modal-fullscreen-cart">
<svg class="icon-inline icon-2x icon-w-19 "><use xlink:href="#cart" /></svg>
<span class="utility-name transition-soft d-none  font-weight-bold d-md-block">Mi carrito</span>
<span class="js-cart-widget-amount badge badge-amount">0</span>
</a>
</div>
</div>
</div>
<div class="d-none d-md-block">
<div class="js-alert-added-to-cart notification-floating notification-hidden " style="display: none;">
<div class="notification notification-primary notification-cart position-relative col-12 float-right">
<div class="js-cart-notification-arrow-up notification-arrow-up"></div>
<div class="js-cart-notification-close notification-close">
<svg class="icon-inline icon-2x icon-w-12 svg-icon-primary notification-icon"><use xlink:href="#times" /></svg>
</div>
<div class="js-cart-notification-item row" data-store="cart-notification-item">
<div class="col-2 pr-0 notification-img">
<img src class="js-cart-notification-item-img img-fluid" />
<svg class="icon-inline icon-sm svg-icon-primary"><use xlink:href="#check-circle-filled" /></svg>
</div>
<div class="col-10 text-left">
<div class="mb-1 mr-4">
<span class="js-cart-notification-item-name"></span>
<span class="js-cart-notification-item-variant-container" style="display: none;">
(<span class="js-cart-notification-item-variant"></span>)
</span>
</div>
<div class="mb-1">
<span class="js-cart-notification-item-quantity"></span>
<span> x </span>
<span class="js-cart-notification-item-price"></span>
</div>
<strong>¡Agregado al carrito con éxito!</strong>
</div>
</div>
<div class="divider my-3"></div>
<div class="row text-primary h5 font-weight-normal mb-3">
<span class="col-auto text-left ml-2">
<strong>Total</strong>
(<span class="js-cart-widget-amount">
0
</span>
<span class="js-cart-counts-plural" style="display: none;">
productos):
</span>
<span class="js-cart-counts-singular" style="display: none;">
producto):
</span>
</span>
<strong class="js-cart-total col text-right mr-2">$0,00</strong>
</div>
<a href="#" class="js-modal-open js-cart-notification-close js-fullscreen-modal-open btn btn-primary btn-medium w-100 d-inline-block" data-toggle="#modal-cart" data-modal-url="modal-fullscreen-cart">
Ver carrito
</a>
</div>
</div>
</div>
</div>
</div>
<div class="d-md-none">
<div class="js-alert-added-to-cart notification-floating notification-hidden " style="display: none;">
<div class="notification notification-primary notification-cart position-relative ">
<div class="js-cart-notification-arrow-up notification-arrow-up"></div>
<div class="js-cart-notification-close notification-close">
<svg class="icon-inline icon-2x icon-w-12 svg-icon-primary notification-icon"><use xlink:href="#times" /></svg>
</div>
<div class="js-cart-notification-item row" data-store="cart-notification-item">
<div class="col-2 pr-0 notification-img">
<img src class="js-cart-notification-item-img img-fluid" />
<svg class="icon-inline icon-sm svg-icon-primary"><use xlink:href="#check-circle-filled" /></svg>
</div>
<div class="col-10 text-left">
<div class="mb-1 mr-4">
<span class="js-cart-notification-item-name"></span>
<span class="js-cart-notification-item-variant-container" style="display: none;">
(<span class="js-cart-notification-item-variant"></span>)
</span>
</div>
<div class="mb-1">
<span class="js-cart-notification-item-quantity"></span>
<span> x </span>
<span class="js-cart-notification-item-price"></span>
</div>
<strong>¡Agregado al carrito con éxito!</strong>
</div>
</div>
<div class="divider my-3"></div>
<div class="row text-primary h5 font-weight-normal mb-3">
<span class="col-auto text-left ml-2">
<strong>Total</strong>
(<span class="js-cart-widget-amount">
0
</span>
<span class="js-cart-counts-plural" style="display: none;">
productos):
</span>
<span class="js-cart-counts-singular" style="display: none;">
producto):
</span>
</span>
<strong class="js-cart-total col text-right mr-2">$0,00</strong>
</div>
<a href="#" class="js-modal-open js-cart-notification-close js-fullscreen-modal-open btn btn-primary btn-medium w-100 d-inline-block" data-toggle="#modal-cart" data-modal-url="modal-fullscreen-cart">
Ver carrito
</a>
</div>
</div>
</div>
<div class="row align-items-center nav-row ">
<div class="col text-center p-0 d-none d-md-block"><div class="nav-desktop">
<ul class="js-nav-desktop-list nav-desktop-list" data-store="navigation" data-component="menu">
<li class="js-item-desktop nav-item-desktop nav-dropdown nav-main-item  nav-item item-with-subitems" data-component="menu.item">
<div class="nav-item-container ">
<a class=" nav-list-link " href="https://tekocreaciones.mitiendanube.com/productos/">Productos
<span class="nav-list-arrow transition-soft">
<svg class="icon-inline icon-md"><use xlink:href="#chevron-down" /></svg>
</span>
</a>
</div>
<div class="js-desktop-dropdown nav-dropdown-content desktop-dropdown"> <ul class="desktop-list-subitems list-subitems nav-list-accordion">
<li class="js-item-desktop nav-item-desktop  nav-item item-with-subitems" data-component="menu.item">
<div class="nav-item-container ">
<a class=" nav-list-link " href="https://tekocreaciones.mitiendanube.com/combos-materos/">COMBOS MATEROS
</a>
</div>
<ul class=" list-subitems nav-list-accordion">
<li class="js-item-desktop nav-item-desktop  nav-item" data-component="menu.item">
<a class="nav-list-link " href="https://tekocreaciones.mitiendanube.com/combos-materos/mochila-y-set-matero/">Mochila y set matero</a>
</li>
<li class="js-item-desktop nav-item-desktop  nav-item" data-component="menu.item">
<a class="nav-list-link " href="https://tekocreaciones.mitiendanube.com/combos-materos/bolso-y-set-matero/">Bolso redondo y set matero</a>
</li>
<li class="js-item-desktop nav-item-desktop  nav-item" data-component="menu.item">
<a class="nav-list-link " href="https://tekocreaciones.mitiendanube.com/combos-materos/bolso-cuadrado-y-set-matero/">Bolso cuadrado y set matero</a>
</li>
</ul>
</li>
<li class="js-item-desktop nav-item-desktop  nav-item" data-component="menu.item">
<a class="nav-list-link " href="https://tekocreaciones.mitiendanube.com/set-materos2/">SET MATEROS</a>
</li>
<li class="js-item-desktop nav-item-desktop  nav-item" data-component="menu.item">
<a class="nav-list-link " href="https://tekocreaciones.mitiendanube.com/mochilas-materas/">MOCHILAS MATERAS</a>
</li>
<li class="js-item-desktop nav-item-desktop  nav-item" data-component="menu.item">
<a class="nav-list-link " href="https://tekocreaciones.mitiendanube.com/super-yerbera/">YERBERAS INDIVIDUALES </a>
</li>
<li class="js-item-desktop nav-item-desktop  nav-item" data-component="menu.item">
<a class="nav-list-link " href="https://tekocreaciones.mitiendanube.com/termos-mates-y-cafeteros/">TERMOS, MATES Y CAFETEROS</a>
</li>
<li class="js-item-desktop nav-item-desktop  nav-item" data-component="menu.item">
<a class="nav-list-link " href="https://tekocreaciones.mitiendanube.com/neceseres/">ORGANIZADORES PERSONALES </a>
</li>
<li class="js-item-desktop nav-item-desktop  nav-item" data-component="menu.item">
<a class="nav-list-link " href="https://tekocreaciones.mitiendanube.com/cartucheras/">CARTUCHERAS Y PORTAFOTOCOPIAS </a>
</li>
<li class="js-item-desktop nav-item-desktop  nav-item" data-component="menu.item">
<a class="nav-list-link " href="https://tekocreaciones.mitiendanube.com/bolsa-palanquera1/">BOLSA PARA AUTOS</a>
</li>
<li class="js-item-desktop nav-item-desktop  nav-item" data-component="menu.item">
<a class="nav-list-link " href="https://tekocreaciones.mitiendanube.com/porta-cargadores/">PORTA CELULAR</a>
</li>
<li class="js-item-desktop nav-item-desktop  nav-item" data-component="menu.item">
<a class="nav-list-link " href="https://tekocreaciones.mitiendanube.com/articulos-de-playa/">PLAYA</a>
</li>
</ul>
</div> </li>
<li class="js-item-desktop nav-item-desktop nav-main-item nav-item" data-component="menu.item">
<a class="nav-list-link " href="https://tekocreaciones.mitiendanube.com/ventas-por-mayor/">Ventas por mayor</a>
</li>
<li class="js-item-desktop nav-item-desktop nav-main-item nav-item" data-component="menu.item">
<a class="nav-list-link " href="https://tekocreaciones.mitiendanube.com/como-comprar/">Cómo Comprar</a>
</li>
<li class="js-item-desktop nav-item-desktop nav-main-item nav-item" data-component="menu.item">
<a class="nav-list-link " href="/contacto/">Contacto</a>
</li>
</ul>
</div></div>
</div>
</div>
</header>
<div class="js-notification js-notification-cookie-banner notification notification-fixed-bottom notification-above notification-primary col-12 col-lg-6 offset-lg-3 opacity-90" style="display: none;">
<div class="mb-4">Al navegar por este sitio <strong>aceptás el uso de cookies</strong> para agilizar tu experiencia de compra.</div>
<div class="text-center mb-3">
<a href="#" class="js-notification-close js-acknowledge-cookies btn btn-secondary btn-medium invert" data-amplitude-event-name="cookie_banner_acknowledge_click">Entendido</a>
</div>
</div>
<div id="quick-login" class="js-modal  modal modal-bottom modal-centered-small modal-center transition-slide modal-centered transition-soft modal-zindex-top" style="display: none;">
<span class="js-modal-close modal-close no-header float-right mr-0">
<svg class="icon-inline icon-lg modal-close-icon icon-w-10"><use xlink:href="#times" /></svg>
</span>
<div class="modal-body">
<div class="text-center h5 mt-3">¡Qué bueno verte de nuevo!</div>
<div class="text-center p-2">Iniciá sesión para comprar más rápido y ver todos tus pedidos.</div>
<form id="quick-login-form" action="/account/login/" method="post" class="js-form form " data-store="account-login">
<div class="form-group ">
<input type="hidden" class=" form-control  " autocorrect="off" autocapitalize="off" name="redirect_to" value="ar/error_404" />
</div>
<div class="form-group ">
<input type="hidden" class=" form-control  " autocorrect="off" autocapitalize="off" name="from" value="quick-login" />
</div>
<div class="form-group ">
<label class="form-label " for="email">Email</label>
<input type="email" class=" form-control js-account-input " autocorrect="off" autocapitalize="off" name="email" />
</div>
<div class="form-group ">
<label class="form-label " for="password">Contraseña</label>
<input type="password" class="js-password-input form-control js-account-input " autocorrect="off" autocapitalize="off" autocomplete="off" name="password" />
<a aria-label="Ver contraseña" class="js-password-view btn form-toggle-eye">
<span class="js-eye-open" style="display: none;">
<svg class="icon-inline svg-icon-primary icon-w-20"><use xlink:href="#eye" /></svg>
</span>
<span class="js-eye-closed">
<svg class="icon-inline svg-icon-primary icon-w-20"><use xlink:href="#eye-closed" /></svg>
</span>
</a>
<div class="mt-4 text-center">
<a href="/account/reset" class="btn-link btn-link-primary font-small float-right mb-4 mt-3n"></a>
</div>
</div>
<button class="btn btn-primary btn-block" type="submit" value="Iniciar sesión" name>
Iniciar sesión
<span class="js-form-spinner" style="display:none;">
<svg class="icon-inline icon-spin h5"><use xlink:href="#circle-notch" /></svg>
</span>
</button>
</form>
</div>
</div>
<div class="js-modal-overlay modal-overlay modal-zindex-top" data-modal-id="#quick-login" style="display: none;"></div>
<div id="nav-hamburger" class="js-modal  modal modal-nav-hamburger head-primary modal-docked-small modal-left transition-fade modal-full transition-soft " style="display: none;">
<div class="modal-with-fixed-footer">
<div class="modal-scrollable-area">
<div class="modal-topbar">
<div class="row navigation-topbar">
<div class="col-8 text-left px-2">
<a class="social-icon" href="https://instagram.com/teko_creaciones" target="_blank" aria-label="instagram Teko Creaciones">
<svg class="icon-inline icon-md"><use xlink:href="#instagram" /></svg>
</a>
</div>
<div class="col-4 text-right">
</div>
</div> </div>
<span class="js-modal-close modal-close no-header ">
<svg class="icon-inline icon-lg modal-close-icon icon-w-10"><use xlink:href="#times" /></svg>
</span>
<div class="modal-body">
<div class="nav-primary">
<ul class="nav-list" data-store="navigation" data-component="menu">
<li class=" nav-item item-with-subitems" data-component="menu.item">
<div class="nav-item-container js-nav-list-toggle-accordion">
<a class="js-toggle-page-accordion nav-list-link " href="#">Productos
<span class="nav-list-arrow transition-soft">
<svg class="icon-inline icon-md"><use xlink:href="#chevron-down" /></svg>
</span>
</a>
</div>
<ul class="js-pages-accordion list-subitems nav-list-accordion" style="display:none;">
<li class="nav-item nav-item-desktop">
<a class="nav-list-link " href="https://tekocreaciones.mitiendanube.com/productos/">
<strong>
Ver todos los productos
</strong>
</a>
</li>
<li class=" nav-item item-with-subitems" data-component="menu.item">
<div class="nav-item-container js-nav-list-toggle-accordion">
<a class="js-toggle-page-accordion nav-list-link " href="#">COMBOS MATEROS
<span class="nav-list-arrow transition-soft">
<svg class="icon-inline icon-md"><use xlink:href="#chevron-down" /></svg>
</span>
</a>
</div>
<ul class="js-pages-accordion list-subitems nav-list-accordion" style="display:none;">
<li class="nav-item nav-item-desktop">
<a class="nav-list-link " href="https://tekocreaciones.mitiendanube.com/combos-materos/">
<strong>
Ver todo en COMBOS MATEROS
</strong>
</a>
</li>
<li class=" nav-item" data-component="menu.item">
<a class="nav-list-link " href="https://tekocreaciones.mitiendanube.com/combos-materos/mochila-y-set-matero/">Mochila y set matero</a>
</li>
<li class=" nav-item" data-component="menu.item">
<a class="nav-list-link " href="https://tekocreaciones.mitiendanube.com/combos-materos/bolso-y-set-matero/">Bolso redondo y set matero</a>
</li>
<li class=" nav-item" data-component="menu.item">
<a class="nav-list-link " href="https://tekocreaciones.mitiendanube.com/combos-materos/bolso-cuadrado-y-set-matero/">Bolso cuadrado y set matero</a>
</li>
</ul>
</li>
<li class=" nav-item" data-component="menu.item">
<a class="nav-list-link " href="https://tekocreaciones.mitiendanube.com/set-materos2/">SET MATEROS</a>
</li>
<li class=" nav-item" data-component="menu.item">
<a class="nav-list-link " href="https://tekocreaciones.mitiendanube.com/mochilas-materas/">MOCHILAS MATERAS</a>
</li>
<li class=" nav-item" data-component="menu.item">
<a class="nav-list-link " href="https://tekocreaciones.mitiendanube.com/super-yerbera/">YERBERAS INDIVIDUALES </a>
</li>
<li class=" nav-item" data-component="menu.item">
<a class="nav-list-link " href="https://tekocreaciones.mitiendanube.com/termos-mates-y-cafeteros/">TERMOS, MATES Y CAFETEROS</a>
</li>
<li class=" nav-item" data-component="menu.item">
<a class="nav-list-link " href="https://tekocreaciones.mitiendanube.com/neceseres/">ORGANIZADORES PERSONALES </a>
</li>
<li class=" nav-item" data-component="menu.item">
<a class="nav-list-link " href="https://tekocreaciones.mitiendanube.com/cartucheras/">CARTUCHERAS Y PORTAFOTOCOPIAS </a>
</li>
<li class=" nav-item" data-component="menu.item">
<a class="nav-list-link " href="https://tekocreaciones.mitiendanube.com/bolsa-palanquera1/">BOLSA PARA AUTOS</a>
</li>
<li class=" nav-item" data-component="menu.item">
<a class="nav-list-link " href="https://tekocreaciones.mitiendanube.com/porta-cargadores/">PORTA CELULAR</a>
</li>
<li class=" nav-item" data-component="menu.item">
<a class="nav-list-link " href="https://tekocreaciones.mitiendanube.com/articulos-de-playa/">PLAYA</a>
</li>
</ul>
</li>
<li class=" nav-item" data-component="menu.item">
<a class="nav-list-link " href="https://tekocreaciones.mitiendanube.com/ventas-por-mayor/">Ventas por mayor</a>
</li>
<li class=" nav-item" data-component="menu.item">
<a class="nav-list-link " href="https://tekocreaciones.mitiendanube.com/como-comprar/">Cómo Comprar</a>
</li>
<li class=" nav-item" data-component="menu.item">
<a class="nav-list-link " href="/contacto/">Contacto</a>
</li>
</ul>
</div>
</div>
</div>
<div class="modal-footer  p-0">
<div class="nav-secondary" data-store="account-links">
<ul class="nav-account">
<svg class="icon-inline icon-2x icon-w-14 mr-2 ml-3"><use xlink:href="#user" /></svg>
<li class="nav-accounts-item"><a href="/account/register" title class="nav-accounts-link">Crear cuenta</a></li>
<li class="nav-accounts-item position-relative">
<a href="/account/login/" title class="js-login nav-accounts-link">Iniciar sesión</a>
<a data-toggle="#quick-login" class="js-modal-open js-quick-login-badge" style="display: none;">
<span class="js-quick-login-badge badge badge-float"></span>
</a>
</li>
</ul>
</div>
</div>
</div>
</div>
<div class="js-modal-overlay modal-overlay " data-modal-id="#nav-hamburger" style="display: none;"></div>
<div id="nav-search" class="js-modal  modal modal-nav-search modal-left transition-slide modal-docked-md transition-soft " style="display: none;">
<div class="js-modal-close  modal-header">
<span class="modal-close ">
<svg class="icon-inline modal-close-icon icon-w-10"><use xlink:href="#times" /></svg>
</span>
Buscar </div>
<div class="modal-body">
<form class="js-search-container js-search-form search-container" action="/search/" method="get">
<div class="form-group m-0">
<input class="js-search-input form-control search-input" autocomplete="off" type="search" name="q" placeholder="¿Qué estás buscando?" aria-label="¿Qué estás buscando?" />
<button type="submit" class="btn search-input-submit" value="Buscar" aria-label="Buscar">
<svg class="icon-inline icon-2x"><use xlink:href="#search" /></svg>
</button>
</div>
</form>
<div class="js-search-suggest search-suggest">
</div>
</div>
</div>
<div class="js-modal-overlay modal-overlay " data-modal-id="#nav-search" style="display: none;"></div>
<div id="modal-cart" class="js-modal js-fullscreen-modal modal modal- modal-right transition-slide modal-docked-md transition-soft " style="display: none;" data-component="cart">
<form action="/comprar/" method="post" class="js-ajax-cart-panel " data-store="cart-form">
<div class="js-modal-close js-fullscreen-modal-close modal-header">
<span class="modal-close ">
<svg class="icon-inline modal-close-icon icon-w-10"><use xlink:href="#times" /></svg>
</span>
Carrito de Compras </div>
<div class="modal-body">
<div class="js-ajax-cart-list cart-row">
</div>
<div class="js-empty-ajax-cart cart-row">
<div class="alert alert-info" data-component="cart.empty-message">El carrito de compras está vacío. </div>
</div>
<div id="error-ajax-stock" style="display: none;">
<div class="alert alert-warning">
¡Uy! No tenemos más stock de este producto para agregarlo al carrito. Si querés podés<a href="/productos/" class="btn-link ml-1">ver otros acá</a>
</div>
</div>
<div class="cart-row">
<div class="subtotal-price hidden" data-priceraw="0"></div>
<div id="store-curr" class="hidden">ARS</div>
<h5 class="js-visible-on-cart-filled row mb-1" style="display:none;" data-store="cart-subtotal">
<span class="col-7">
Subtotal
<small class="js-subtotal-shipping-wording"> (sin envío)</small>
:
</span>
<strong class="js-ajax-cart-total js-cart-subtotal col text-right" data-priceraw="0" data-component="cart.subtotal" data-component-value="0">$0,00</strong>
</h5>
<div class="js-total-promotions text-accent font-weight-bold">
<span class="js-promo-in" style="display:none;">en</span>
<span class="js-promo-all" style="display:none;">todos los productos</span>
<span class="js-promo-buying" style="display:none;"> comprando</span>
<span class="js-promo-units-or-more" style="display:none;"> o más</span>
</div>
<div class="js-fulfillment-info js-allows-non-shippable" style="display: none">
<div class="js-visible-on-cart-filled divider" style="display:none;"></div>
<div class="js-visible-on-cart-filled js-has-new-shipping js-shipping-calculator-container">
<div class="js-shipping-method-unavailable alert alert-warning row m-1" style="display: none;">
<div class="col-11 text-left"><strong>El medio de envío que habías elegido ya no se encuentra disponible para este carrito. </strong></br>
¡No te preocupes! Podés elegir otro.</div>
</div>
<div id="cart-shipping-container" class="row" style="display: none;" data-shipping-url="/envio/">
<span id="cart-selected-shipping-method" data-code class="hidden"></span>
<div class="mb-2 col-12" data-store="shipping-calculator">
<div class="js-shipping-calculator-head shipping-calculator-head position-relative transition-soft with-form ">
<div class="js-shipping-calculator-with-zipcode  mb-4 w-100 transition-up position-absolute">
<div class="container p-0">
<div class="row align-items-center">
<span class="col pr-0">
<span class="font-small align-bottom">
<span>Entregas para el CP:</span>
<strong class="js-shipping-calculator-current-zip"></strong>
</span>
</span>
<div class="col-auto pl-0">
<a class="js-shipping-calculator-change-zipcode btn btn-secondary btn-small float-right py-1 px-2 px-sm-3" href="#">Cambiar CP</a>
</div>
</div>
</div>
</div>
<div class="js-shipping-calculator-form shipping-calculator-form transition-up position-absolute">
<div class="form-group form-row form-group-inline align-items-center mb-3">
<div class="col-12 mb-2 form-label">
<svg class="icon-inline icon-lg icon-w-20 svg-icon-text mr-2 align-text-bottom"><use xlink:href="#truck" /></svg>
<span class="align-middle">
Medios de envío
</span>
</div>
<div class="form-control-container col-6 col-lg-7 pr-0">
<input type="tel" class=" form-control js-shipping-input form-control-inline" autocorrect="off" autocapitalize="off" name="zipcode" placeholder="Tu código postal" aria-label="Tu código postal" data-component="cart" />
</div>
<div class="col-6 col-lg-5 pl-0">
<button class="js-calculate-shipping btn btn-secondary btn-block" aria-label="Calcular envío">
<span class="js-calculate-shipping-wording">Calcular</span>
<span class="js-calculating-shipping-wording" style="display: none;">Calculando</span>
<span class="float-right loading" style="display: none;">
<svg class="icon-inline icon-smd icon-spin svg-icon-primary"><use xlink:href="#circle-notch" /></svg>
</span>
</button>
</div>
<div class="col-12">
<a class="font-small text-primary mt-2 mb-2 d-block " href="https://www.correoargentino.com.ar/formularios/cpa" target="_blank">No sé mi código postal</a>
</div>
<div class="col-12">
<div class="js-ship-calculator-error invalid-zipcode alert alert-danger" style="display: none;">
No encontramos este código postal. ¿Está bien escrito?
</div>
<div class="js-ship-calculator-error js-ship-calculator-common-error alert alert-danger" style="display: none;">Ocurrió un error al calcular el envío. Por favor intentá de nuevo en unos segundos.</div>
<div class="js-ship-calculator-error js-ship-calculator-external-error alert alert-danger" style="display: none;">El calculo falló por un problema con el medio de envío. Por favor intentá de nuevo en unos segundos.</div>
</div>
</div>
</div>
</div>
<div class="js-shipping-calculator-spinner shipping-spinner-container mb-3 float-left w-100 transition-soft text-center" style="display: none;"><div class="spinner-ellipsis"><div class="point"></div><div class="point"></div><div class="point"></div><div class="point"></div></div></div>
<div class="js-shipping-calculator-response mb-3 float-left w-100 transition-soft  radio-buttons-group" style="display: none;"></div>
</div>
<div class=" w-100 container-fluid" data-store="branches">
<span class="form-row align-items-end">
<div class="col-1 col-md-auto form-label">
<svg class="icon-inline icon-lg icon-w-20 svg-icon-text align-text-bottom"><use xlink:href="#store-alt" /></svg>
</div>
<div class="col-11 form-label">
<div>
Nuestro local
</div>
</div>
</span>
</div>
<div class="js-store-branches-container container-fluid">
<div class="box mt-3 p-0">
<div class="radio-buttons-group">
<ul class="list-unstyled radio-button-container">
<li class="radio-button-item" data-store="branch-item-branch_250159">
<label class="js-shipping-radio js-branch-radio radio-button" data-loop="branch-radio-1">
<input class="js-branch-method  shipping-method" data-price="0" type="radio" value="branch_250159" data-name="Teko Creaciones - Jorge Luis Borges 42, Paraná, Entre Rios - Atencion de Lun. a Sab. de 9 a 12 y de 16 a 20" data-code="branch_250159" data-cost="Gratis" name="option" style="display:none">
<div class="shipping-option row-fluid radio-button-content">
<div class="radio-button-icons-container">
<span class="radio-button-icons">
<span class="radio-button-icon unchecked"></span>
<span class="radio-button-icon checked">
<svg class="icon-inline icon-sm svg-icon-primary"><use xlink:href="#check" /></svg>
</span>
</span>
</div>
<div class="radio-button-label">
<div class="row">
<div class="col-9 font-small">
<div>Teko Creaciones - Jorge Luis Borges 42, Paraná, Entre Rios - Atencion de Lun. a Sab. de 9 a 12 y de 16 a 20</div>
</div>
<div class="col-3 text-right">
<h5 class="text-primary mb-0 d-inline-block">Gratis</h5>
</div>
</div>
</div>
</div>
</label>
</li>
</ul>
</div>
</div>
</div>
</div>
</div>
<div class="js-visible-on-cart-filled divider " style="display:none;"></div>
</div>
<div class="js-cart-total-container js-visible-on-cart-filled mb-3" style="display:none;" data-store="cart-total">
<h2 class="row text-primary mb-0">
<span class="col">Total:</span>
<span class="js-cart-total   col text-right" data-component="cart.total" data-component-value="0">$0,00</span>
</h2>
<div class="total-price hidden">
Total: $0,00
</div>
<div class="text-right">
<div style="display: none;" data-interest="0" data-cart-installment="1" class="js-installments-cart-total cart-installments text-accent font-small font-weight-bold mt-1 ">
O hasta
<span class="js-cart-installments-amount cart-installments-amount ">1</span>
<span>
cuotas
de
</span>
<span class="js-cart-installments cart-installments-money ">$0,00</span>
</div>
</div>
</div>
<div class="js-visible-on-cart-filled container-fluid" style="display:none;">
<div id="error-ajax-stock" class="alert alert-warning mt-1" role="alert" style="display:none;">
¡Uy! No tenemos más stock de este producto para agregarlo al carrito. Si querés podés<a href="/productos/" class="btn-link ml-1">ver otros acá</a>
</div>
<div>
<div class="js-ajax-cart-submit row mb-3" id="ajax-cart-submit-div">
<input class="btn btn-primary btn-block" type="submit" name="go_to_checkout" value="Iniciar Compra" data-component="cart.checkout-button" />
</div>
<div class="row">
<div class="js-ajax-cart-minimum alert alert-warning mt-4" style="display:none" id="ajax-cart-minumum-div">
El monto mínimo de compra es de $0,00 sin incluir el costo de envío
</div>
</div>
<input type="hidden" id="ajax-cart-minimum-value" value="0" />
<div class="row mb-2">
<div class="text-center w-100">
<a href="#" class="js-modal-close js-fullscreen-modal-close btn-link">Ver más productos</a>
</div>
</div>
</div>
</div>
</div>
</div>
</form>
</div>
<div class="js-modal-overlay modal-overlay " data-modal-id="#modal-cart" style="display: none;"></div>
<div class="mt-4">
<section class="page-header" data-store="page-title">
<div class="container">
<div class="row">
<div class="col text-center ">
<h1 class="text-center h2 h1-md  text-primary">Error - 404</h1>
</div>
</div>
</div>
</section>
<section id="404">
<div class="container">
<div class="row">
<div class="col-12 text-center">
<p class="mb-1">La página que estás buscando no existe.</p></br>
</div>
</div>
<div class="row">
<div class="col-12 text-center">
Quizás te interesen los siguientes productos.
</div>
</div>
<div class="row mt-3">
<div class="js-item-product  col-6 col-md-4 col-lg-3" data-product-type="list" data-product-id="216559565" data-store="product-item-216559565" data-component="product-list-item" data-component-value="216559565" data-grid-classes="col-6 col-md-4 col-lg-3">
<div class="item item-rounded item-product box-rounded p-0">
<div id="quick216559565" class="js-product-container js-quickshop-container position-relative js-quickshop-has-variants" data-variants="[{&quot;product_id&quot;:216559565,&quot;price_short&quot;:&quot;$18.000,00&quot;,&quot;price_long&quot;:&quot;$18.000,00 ARS&quot;,&quot;price_number&quot;:18000,&quot;price_number_raw&quot;:1800000,&quot;price_with_payment_discount_short&quot;:null,&quot;compare_at_price_short&quot;:null,&quot;compare_at_price_long&quot;:null,&quot;compare_at_price_number&quot;:null,&quot;stock&quot;:1,&quot;sku&quot;:null,&quot;available&quot;:true,&quot;contact&quot;:false,&quot;option0&quot;:&quot;Celeste&quot;,&quot;option1&quot;:null,&quot;option2&quot;:null,&quot;id&quot;:947836109,&quot;image&quot;:667320880,&quot;image_url&quot;:&quot;\/\/acdn.mitiendanube.com\/stores\/001\/779\/198\/products\/34-05da4ded3f067a491117181258266302-1024-1024.png&quot;,&quot;installments_data&quot;:&quot;{\&quot;mercadopago\&quot;:{\&quot;1\&quot;:{\&quot;installment_value\&quot;:18000,\&quot;installment_value_cents\&quot;:1800000,\&quot;interest\&quot;:0,\&quot;total_value\&quot;:18000,\&quot;without_interests\&quot;:true},\&quot;2\&quot;:{\&quot;installment_value\&quot;:10701,\&quot;installment_value_cents\&quot;:1070100,\&quot;interest\&quot;:0.189,\&quot;total_value\&quot;:21402,\&quot;without_interests\&quot;:false},\&quot;3\&quot;:{\&quot;installment_value\&quot;:7365,\&quot;installment_value_cents\&quot;:736500,\&quot;interest\&quot;:0.2275,\&quot;total_value\&quot;:22095,\&quot;without_interests\&quot;:false},\&quot;6\&quot;:{\&quot;installment_value\&quot;:4006.2,\&quot;installment_value_cents\&quot;:400620,\&quot;interest\&quot;:0.3354,\&quot;total_value\&quot;:24037.2,\&quot;without_interests\&quot;:false},\&quot;9\&quot;:{\&quot;installment_value\&quot;:2873.6,\&quot;installment_value_cents\&quot;:287360,\&quot;interest\&quot;:0.4368,\&quot;total_value\&quot;:25862.4,\&quot;without_interests\&quot;:false},\&quot;12\&quot;:{\&quot;installment_value\&quot;:2337.15,\&quot;installment_value_cents\&quot;:233715,\&quot;interest\&quot;:0.5581,\&quot;total_value\&quot;:28045.8,\&quot;without_interests\&quot;:false},\&quot;18\&quot;:{\&quot;installment_value\&quot;:1865.2,\&quot;installment_value_cents\&quot;:186520,\&quot;interest\&quot;:0.8652,\&quot;total_value\&quot;:33573.6,\&quot;without_interests\&quot;:false},\&quot;24\&quot;:{\&quot;installment_value\&quot;:1648.425,\&quot;installment_value_cents\&quot;:164842.5,\&quot;interest\&quot;:1.1979,\&quot;total_value\&quot;:39562.2,\&quot;without_interests\&quot;:false}},\&quot;Pago Nube\&quot;:{\&quot;2\&quot;:{\&quot;installment_value\&quot;:9000,\&quot;installment_value_cents\&quot;:900000,\&quot;interest\&quot;:0,\&quot;total_value\&quot;:18000,\&quot;without_interests\&quot;:true}}}&quot;},{&quot;product_id&quot;:216559565,&quot;price_short&quot;:&quot;$18.000,00&quot;,&quot;price_long&quot;:&quot;$18.000,00 ARS&quot;,&quot;price_number&quot;:18000,&quot;price_number_raw&quot;:1800000,&quot;price_with_payment_discount_short&quot;:null,&quot;compare_at_price_short&quot;:null,&quot;compare_at_price_long&quot;:null,&quot;compare_at_price_number&quot;:null,&quot;stock&quot;:1,&quot;sku&quot;:null,&quot;available&quot;:true,&quot;contact&quot;:false,&quot;option0&quot;:&quot;Violeta&quot;,&quot;option1&quot;:null,&quot;option2&quot;:null,&quot;id&quot;:947836112,&quot;image&quot;:667320880,&quot;image_url&quot;:&quot;\/\/acdn.mitiendanube.com\/stores\/001\/779\/198\/products\/34-05da4ded3f067a491117181258266302-1024-1024.png&quot;,&quot;installments_data&quot;:&quot;{\&quot;mercadopago\&quot;:{\&quot;1\&quot;:{\&quot;installment_value\&quot;:18000,\&quot;installment_value_cents\&quot;:1800000,\&quot;interest\&quot;:0,\&quot;total_value\&quot;:18000,\&quot;without_interests\&quot;:true},\&quot;2\&quot;:{\&quot;installment_value\&quot;:10701,\&quot;installment_value_cents\&quot;:1070100,\&quot;interest\&quot;:0.189,\&quot;total_value\&quot;:21402,\&quot;without_interests\&quot;:false},\&quot;3\&quot;:{\&quot;installment_value\&quot;:7365,\&quot;installment_value_cents\&quot;:736500,\&quot;interest\&quot;:0.2275,\&quot;total_value\&quot;:22095,\&quot;without_interests\&quot;:false},\&quot;6\&quot;:{\&quot;installment_value\&quot;:4006.2,\&quot;installment_value_cents\&quot;:400620,\&quot;interest\&quot;:0.3354,\&quot;total_value\&quot;:24037.2,\&quot;without_interests\&quot;:false},\&quot;9\&quot;:{\&quot;installment_value\&quot;:2873.6,\&quot;installment_value_cents\&quot;:287360,\&quot;interest\&quot;:0.4368,\&quot;total_value\&quot;:25862.4,\&quot;without_interests\&quot;:false},\&quot;12\&quot;:{\&quot;installment_value\&quot;:2337.15,\&quot;installment_value_cents\&quot;:233715,\&quot;interest\&quot;:0.5581,\&quot;total_value\&quot;:28045.8,\&quot;without_interests\&quot;:false},\&quot;18\&quot;:{\&quot;installment_value\&quot;:1865.2,\&quot;installment_value_cents\&quot;:186520,\&quot;interest\&quot;:0.8652,\&quot;total_value\&quot;:33573.6,\&quot;without_interests\&quot;:false},\&quot;24\&quot;:{\&quot;installment_value\&quot;:1648.425,\&quot;installment_value_cents\&quot;:164842.5,\&quot;interest\&quot;:1.1979,\&quot;total_value\&quot;:39562.2,\&quot;without_interests\&quot;:false}},\&quot;Pago Nube\&quot;:{\&quot;2\&quot;:{\&quot;installment_value\&quot;:9000,\&quot;installment_value_cents\&quot;:900000,\&quot;interest\&quot;:0,\&quot;total_value\&quot;:18000,\&quot;without_interests\&quot;:true}}}&quot;}]">
<div class=" item-image">
<div style="padding-bottom: 100%;" class="position-relative" data-store="product-item-image-216559565">
<a href="https://tekocreaciones.mitiendanube.com/productos/vaso-cafetero-bicolor-550ml/" title="Vaso cafetero bicolor 550ml" aria-label="Vaso cafetero bicolor 550ml">
<img alt="Vaso cafetero bicolor 550ml" data-expand="-10" src="//acdn.mitiendanube.com/assets/themes/amazonas/static/images/empty-placeholder.png" data-srcset="//acdn.mitiendanube.com/stores/001/779/198/products/34-05da4ded3f067a491117181258266302-240-0.png 240w, //acdn.mitiendanube.com/stores/001/779/198/products/34-05da4ded3f067a491117181258266302-320-0.png 320w, //acdn.mitiendanube.com/stores/001/779/198/products/34-05da4ded3f067a491117181258266302-480-0.png 480w" class="js-item-image lazyautosizes lazyload img-absolute img-absolute-centered fade-in " width="1080" height="1080" />
<div class="placeholder-fade">
</div>
</a>
</div>
<div class=" labels " data-store="product-item-labels">
</div>
<span class="hidden" data-store="stock-product-216559565-2"></span> <div class="item-buy">
<div class="js-item-variants item-buy-variants px-1 py-2 p-md-3">
<form class="js-product-form" method="post" action="/comprar/">
<input type="hidden" name="add_to_cart" value="216559565" />
<div class="js-product-variants js-product-quickshop-variants form-row mb-2">
<div class="js-product-variants-group js-color-variants-container col-12 ">
<div class="form-group form-group-small mb-2">
<label class="form-label mb-1" for="variation_1">Color</label>
<select id="variation_1" class="form-select js-variation-option js-refresh-installment-data form-control-small " name="variation[0]">
<option value="Celeste" selected="selected">Celeste</option>
<option value="Violeta">Violeta</option>
</select>
<div class="form-select-icon">
<svg class="icon-inline icon-w-14 icon-lg"><use xlink:href="#chevron-down" /></svg>
</div>
</div>
</div>
</div>
<input type="submit" class="js-addtocart js-prod-submit-form btn btn-primary btn-small w-100 mb-2 cart" value="Agregar al carrito" />
<div class="js-addtocart js-addtocart-placeholder btn btn-primary btn-block btn-transition btn-small w-100 mb-2 disabled" style="display: none;">
<div class="d-inline-block">
<span class="js-addtocart-text">Agregar al carrito</span>
<span class="js-addtocart-success transition-container btn-transition-success-small">
<svg class="icon-inline svg-icon-invert btn-transition-success-icon"><use xlink:href="#check-circle" /></svg>
</span>
<div class="js-addtocart-adding transition-container transition-soft btn-transition-progress">
<div class="spinner-ellipsis invert">
<div class="point"></div>
<div class="point"></div>
<div class="point"></div>
<div class="point"></div>
</div>
</div>
</div>
</div> </form>
<a href="#" class="js-item-buy-close">
<svg class="icon-inline icon-lg svg-circle svg-icon-text"><use xlink:href="#times" /></svg>
</a>
</div>
</div>
</div>
<div class="item-description py-4 px-3" data-store="product-item-info-216559565">
<a href="https://tekocreaciones.mitiendanube.com/productos/vaso-cafetero-bicolor-550ml/" title="Vaso cafetero bicolor 550ml" aria-label="Vaso cafetero bicolor 550ml" class="item-link">
<div class="js-item-name item-name mb-3" data-store="product-item-name-216559565">Vaso cafetero bicolor 550ml</div>
<div class="item-price-container mb-1" data-store="product-item-price-216559565">
<span class="js-compare-price-display price-compare" style="display:none;">
$0,00
</span>
<span class="js-price-display item-price" data-product-price="1800000">
$18.000,00
</span>
</div>
</a>
<div class="js-max-installments-container js-max-installments item-installments">
<div class="js-max-installments product-installments installment-no-interest">
<span class="js-installment-amount product-installment-amount">2</span>
<span>
cuotas
sin interés
de
</span>
<span class="js-installment-price product-installment-value">$9.000,00</span>
</div>
</div>
</div>
<div class="item-actions row justify-content-center m-0 mb-3">
<div class="col-8 col-md-6 pr-1">
<a href="#" class="js-item-buy-open item-buy-open d-block btn btn-primary btn-small" title="Compra rápida de Vaso cafetero bicolor 550ml" aria-label="Compra rápida de Vaso cafetero bicolor 550ml" data-component="product-list-item.add-to-cart" data-component-value="216559565">Comprar</a>
</div>
<div class="col-4 col-md-6 pl-1">
<a href="https://tekocreaciones.mitiendanube.com/productos/vaso-cafetero-bicolor-550ml/" title="Vaso cafetero bicolor 550ml" aria-label="Vaso cafetero bicolor 550ml" class="d-block btn btn-secondary btn-small">
<svg class="icon-inline svg-icon-primary icon-w-19"><use xlink:href="#eye" /></svg>
<span class="d-none d-md-inline-block">Ver</span></a>
</div>
</div>
</div>
<script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script type="application/ld+json" data-component="structured-data.item">
    {
        "@context": "https://schema.org/",
        "@type": "Product",
        "mainEntityOfPage": {
            "@type": "WebPage",
            "@id": "https://tekocreaciones.mitiendanube.com/productos/vaso-cafetero-bicolor-550ml/"
        },
        "name": "Vaso cafetero bicolor 550ml",
        "image": "https://acdn.mitiendanube.com/stores/001/779/198/products/34-05da4ded3f067a491117181258266302-480-0.png",
        "description": "Solo el celeste viene con cordon ",
                                    "weight": {
                "@type": "QuantitativeValue",
                "unitCode": "KGM",
                "value": "0.3500"
            },
                "offers": {
            "@type": "Offer",
            "url": "https://tekocreaciones.mitiendanube.com/productos/vaso-cafetero-bicolor-550ml/",
            "priceCurrency": "ARS",
            "price": "18000",
                            "availability": "http://schema.org/InStock",
                "inventoryLevel": {
                    "@type": "QuantitativeValue",
                    "value": "2"
                },
                        "seller": {
                "@type": "Organization",
                "name": "Teko Creaciones"
            }
        }
    }
    </script>
</div>
</div>
<div class="js-item-product  col-6 col-md-4 col-lg-3" data-product-type="list" data-product-id="216533548" data-store="product-item-216533548" data-component="product-list-item" data-component-value="216533548" data-grid-classes="col-6 col-md-4 col-lg-3">
<div class="item item-rounded item-product box-rounded p-0">
<div id="quick216533548" class="js-product-container js-quickshop-container position-relative js-quickshop-has-variants" data-variants="[{&quot;product_id&quot;:216533548,&quot;price_short&quot;:&quot;$28.000,00&quot;,&quot;price_long&quot;:&quot;$28.000,00 ARS&quot;,&quot;price_number&quot;:28000,&quot;price_number_raw&quot;:2800000,&quot;price_with_payment_discount_short&quot;:null,&quot;compare_at_price_short&quot;:null,&quot;compare_at_price_long&quot;:null,&quot;compare_at_price_number&quot;:null,&quot;stock&quot;:0,&quot;sku&quot;:null,&quot;available&quot;:false,&quot;contact&quot;:false,&quot;option0&quot;:&quot;Blanco&quot;,&quot;option1&quot;:null,&quot;option2&quot;:null,&quot;id&quot;:947741282,&quot;image&quot;:667223736,&quot;image_url&quot;:&quot;\/\/acdn.mitiendanube.com\/stores\/001\/779\/198\/products\/3-30a7cb65daf340b44c17181190598464-1024-1024.png&quot;,&quot;installments_data&quot;:&quot;{\&quot;mercadopago\&quot;:{\&quot;1\&quot;:{\&quot;installment_value\&quot;:28000,\&quot;installment_value_cents\&quot;:2800000,\&quot;interest\&quot;:0,\&quot;total_value\&quot;:28000,\&quot;without_interests\&quot;:true},\&quot;2\&quot;:{\&quot;installment_value\&quot;:16646,\&quot;installment_value_cents\&quot;:1664600,\&quot;interest\&quot;:0.189,\&quot;total_value\&quot;:33292,\&quot;without_interests\&quot;:false},\&quot;3\&quot;:{\&quot;installment_value\&quot;:11456.666666667,\&quot;installment_value_cents\&quot;:1145666.6666667,\&quot;interest\&quot;:0.2275,\&quot;total_value\&quot;:34370,\&quot;without_interests\&quot;:false},\&quot;6\&quot;:{\&quot;installment_value\&quot;:6231.8666666667,\&quot;installment_value_cents\&quot;:623186.66666667,\&quot;interest\&quot;:0.3354,\&quot;total_value\&quot;:37391.2,\&quot;without_interests\&quot;:false},\&quot;9\&quot;:{\&quot;installment_value\&quot;:4470.0444444444,\&quot;installment_value_cents\&quot;:447004.44444444,\&quot;interest\&quot;:0.4368,\&quot;total_value\&quot;:40230.4,\&quot;without_interests\&quot;:false},\&quot;12\&quot;:{\&quot;installment_value\&quot;:3635.5666666667,\&quot;installment_value_cents\&quot;:363556.66666667,\&quot;interest\&quot;:0.5581,\&quot;total_value\&quot;:43626.8,\&quot;without_interests\&quot;:false},\&quot;18\&quot;:{\&quot;installment_value\&quot;:2901.4222222222,\&quot;installment_value_cents\&quot;:290142.22222222,\&quot;interest\&quot;:0.8652,\&quot;total_value\&quot;:52225.6,\&quot;without_interests\&quot;:false},\&quot;24\&quot;:{\&quot;installment_value\&quot;:2564.2166666667,\&quot;installment_value_cents\&quot;:256421.66666667,\&quot;interest\&quot;:1.1979,\&quot;total_value\&quot;:61541.2,\&quot;without_interests\&quot;:false}},\&quot;Pago Nube\&quot;:{\&quot;2\&quot;:{\&quot;installment_value\&quot;:14000,\&quot;installment_value_cents\&quot;:1400000,\&quot;interest\&quot;:0,\&quot;total_value\&quot;:28000,\&quot;without_interests\&quot;:true}}}&quot;},{&quot;product_id&quot;:216533548,&quot;price_short&quot;:&quot;$28.000,00&quot;,&quot;price_long&quot;:&quot;$28.000,00 ARS&quot;,&quot;price_number&quot;:28000,&quot;price_number_raw&quot;:2800000,&quot;price_with_payment_discount_short&quot;:null,&quot;compare_at_price_short&quot;:null,&quot;compare_at_price_long&quot;:null,&quot;compare_at_price_number&quot;:null,&quot;stock&quot;:0,&quot;sku&quot;:null,&quot;available&quot;:false,&quot;contact&quot;:false,&quot;option0&quot;:&quot;Negro&quot;,&quot;option1&quot;:null,&quot;option2&quot;:null,&quot;id&quot;:947741285,&quot;image&quot;:667223736,&quot;image_url&quot;:&quot;\/\/acdn.mitiendanube.com\/stores\/001\/779\/198\/products\/3-30a7cb65daf340b44c17181190598464-1024-1024.png&quot;,&quot;installments_data&quot;:&quot;{\&quot;mercadopago\&quot;:{\&quot;1\&quot;:{\&quot;installment_value\&quot;:28000,\&quot;installment_value_cents\&quot;:2800000,\&quot;interest\&quot;:0,\&quot;total_value\&quot;:28000,\&quot;without_interests\&quot;:true},\&quot;2\&quot;:{\&quot;installment_value\&quot;:16646,\&quot;installment_value_cents\&quot;:1664600,\&quot;interest\&quot;:0.189,\&quot;total_value\&quot;:33292,\&quot;without_interests\&quot;:false},\&quot;3\&quot;:{\&quot;installment_value\&quot;:11456.666666667,\&quot;installment_value_cents\&quot;:1145666.6666667,\&quot;interest\&quot;:0.2275,\&quot;total_value\&quot;:34370,\&quot;without_interests\&quot;:false},\&quot;6\&quot;:{\&quot;installment_value\&quot;:6231.8666666667,\&quot;installment_value_cents\&quot;:623186.66666667,\&quot;interest\&quot;:0.3354,\&quot;total_value\&quot;:37391.2,\&quot;without_interests\&quot;:false},\&quot;9\&quot;:{\&quot;installment_value\&quot;:4470.0444444444,\&quot;installment_value_cents\&quot;:447004.44444444,\&quot;interest\&quot;:0.4368,\&quot;total_value\&quot;:40230.4,\&quot;without_interests\&quot;:false},\&quot;12\&quot;:{\&quot;installment_value\&quot;:3635.5666666667,\&quot;installment_value_cents\&quot;:363556.66666667,\&quot;interest\&quot;:0.5581,\&quot;total_value\&quot;:43626.8,\&quot;without_interests\&quot;:false},\&quot;18\&quot;:{\&quot;installment_value\&quot;:2901.4222222222,\&quot;installment_value_cents\&quot;:290142.22222222,\&quot;interest\&quot;:0.8652,\&quot;total_value\&quot;:52225.6,\&quot;without_interests\&quot;:false},\&quot;24\&quot;:{\&quot;installment_value\&quot;:2564.2166666667,\&quot;installment_value_cents\&quot;:256421.66666667,\&quot;interest\&quot;:1.1979,\&quot;total_value\&quot;:61541.2,\&quot;without_interests\&quot;:false}},\&quot;Pago Nube\&quot;:{\&quot;2\&quot;:{\&quot;installment_value\&quot;:14000,\&quot;installment_value_cents\&quot;:1400000,\&quot;interest\&quot;:0,\&quot;total_value\&quot;:28000,\&quot;without_interests\&quot;:true}}}&quot;}]">
<div class=" item-image">
<div style="padding-bottom: 100%;" class="position-relative" data-store="product-item-image-216533548">
<a href="https://tekocreaciones.mitiendanube.com/productos/termo-simil-stanley-1-2l/" title="Termo Simil Stanley 1.2L" aria-label="Termo Simil Stanley 1.2L">
<img alt="Termo Simil Stanley 1.2L" data-expand="-10" src="//acdn.mitiendanube.com/assets/themes/amazonas/static/images/empty-placeholder.png" data-srcset="//acdn.mitiendanube.com/stores/001/779/198/products/3-30a7cb65daf340b44c17181190598464-240-0.png 240w, //acdn.mitiendanube.com/stores/001/779/198/products/3-30a7cb65daf340b44c17181190598464-320-0.png 320w, //acdn.mitiendanube.com/stores/001/779/198/products/3-30a7cb65daf340b44c17181190598464-480-0.png 480w" class="js-item-image lazyautosizes lazyload img-absolute img-absolute-centered fade-in " width="1080" height="1080" />
<div class="placeholder-fade">
</div>
</a>
</div>
<div class=" labels " data-store="product-item-labels">
<div class="label label-default">Sin stock</div>
</div>
<span class="hidden" data-store="stock-product-216533548-0"></span> </div>
<div class="item-description py-4 px-3" data-store="product-item-info-216533548">
<a href="https://tekocreaciones.mitiendanube.com/productos/termo-simil-stanley-1-2l/" title="Termo Simil Stanley 1.2L" aria-label="Termo Simil Stanley 1.2L" class="item-link">
<div class="js-item-name item-name mb-3" data-store="product-item-name-216533548">Termo Simil Stanley 1.2L</div>
<div class="item-price-container mb-1" data-store="product-item-price-216533548">
<span class="js-compare-price-display price-compare" style="display:none;">
$0,00
</span>
<span class="js-price-display item-price" data-product-price="2800000">
$28.000,00
</span>
</div>
</a>
<div class="js-max-installments-container js-max-installments item-installments">
<div class="js-max-installments product-installments installment-no-interest">
<span class="js-installment-amount product-installment-amount">2</span>
<span>
cuotas
sin interés
de
</span>
<span class="js-installment-price product-installment-value">$14.000,00</span>
</div>
</div>
</div>
<div class="item-actions row justify-content-center m-0 mb-3">
<div class="col-12 col-md-6">
<a href="https://tekocreaciones.mitiendanube.com/productos/termo-simil-stanley-1-2l/" title="Termo Simil Stanley 1.2L" aria-label="Termo Simil Stanley 1.2L" class="d-block btn btn-secondary btn-small">
<svg class="icon-inline svg-icon-primary icon-w-19"><use xlink:href="#eye" /></svg>
<span class>Ver</span></a>
</div>
</div>
</div>
<script type="application/ld+json" data-component="structured-data.item">
    {
        "@context": "https://schema.org/",
        "@type": "Product",
        "mainEntityOfPage": {
            "@type": "WebPage",
            "@id": "https://tekocreaciones.mitiendanube.com/productos/termo-simil-stanley-1-2l/"
        },
        "name": "Termo Simil Stanley 1.2L",
        "image": "https://acdn.mitiendanube.com/stores/001/779/198/products/3-30a7cb65daf340b44c17181190598464-480-0.png",
        "description": "Termo de 1.2L + yerbera de 350g y 4 stikers de regalo",
                                    "weight": {
                "@type": "QuantitativeValue",
                "unitCode": "KGM",
                "value": "0.9180"
            },
                "offers": {
            "@type": "Offer",
            "url": "https://tekocreaciones.mitiendanube.com/productos/termo-simil-stanley-1-2l/",
            "priceCurrency": "ARS",
            "price": "28000",
                            "availability": "http://schema.org/OutOfStock",
                "inventoryLevel": {
                    "@type": "QuantitativeValue",
                    "value": "0"
                },
                        "seller": {
                "@type": "Organization",
                "name": "Teko Creaciones"
            }
        }
    }
    </script>
</div>
</div>
<div class="js-item-product  col-6 col-md-4 col-lg-3" data-product-type="list" data-product-id="207677144" data-store="product-item-207677144" data-component="product-list-item" data-component-value="207677144" data-grid-classes="col-6 col-md-4 col-lg-3">
<div class="item item-rounded item-product box-rounded p-0">
<div id="quick207677144" class="js-product-container js-quickshop-container position-relative " data-variants="[{&quot;product_id&quot;:207677144,&quot;price_short&quot;:&quot;$22.680,00&quot;,&quot;price_long&quot;:&quot;$22.680,00 ARS&quot;,&quot;price_number&quot;:22680,&quot;price_number_raw&quot;:2268000,&quot;price_with_payment_discount_short&quot;:null,&quot;compare_at_price_short&quot;:&quot;$25.200,00&quot;,&quot;compare_at_price_long&quot;:&quot;$25.200,00 ARS&quot;,&quot;compare_at_price_number&quot;:25200,&quot;stock&quot;:1,&quot;sku&quot;:null,&quot;available&quot;:true,&quot;contact&quot;:false,&quot;option0&quot;:null,&quot;option1&quot;:null,&quot;option2&quot;:null,&quot;id&quot;:867413998,&quot;image&quot;:630877347,&quot;image_url&quot;:&quot;\/\/acdn.mitiendanube.com\/stores\/001\/779\/198\/products\/3-53bcedd0ed0c8ab14517124500333462-1024-1024.png&quot;,&quot;installments_data&quot;:&quot;{\&quot;mercadopago\&quot;:{\&quot;1\&quot;:{\&quot;installment_value\&quot;:22680,\&quot;installment_value_cents\&quot;:2268000,\&quot;interest\&quot;:0,\&quot;total_value\&quot;:22680,\&quot;without_interests\&quot;:true},\&quot;2\&quot;:{\&quot;installment_value\&quot;:13483.26,\&quot;installment_value_cents\&quot;:1348326,\&quot;interest\&quot;:0.189,\&quot;total_value\&quot;:26966.52,\&quot;without_interests\&quot;:false},\&quot;3\&quot;:{\&quot;installment_value\&quot;:9279.9,\&quot;installment_value_cents\&quot;:927990,\&quot;interest\&quot;:0.2275,\&quot;total_value\&quot;:27839.7,\&quot;without_interests\&quot;:false},\&quot;6\&quot;:{\&quot;installment_value\&quot;:5047.812,\&quot;installment_value_cents\&quot;:504781.2,\&quot;interest\&quot;:0.3354,\&quot;total_value\&quot;:30286.872,\&quot;without_interests\&quot;:false},\&quot;9\&quot;:{\&quot;installment_value\&quot;:3620.736,\&quot;installment_value_cents\&quot;:362073.6,\&quot;interest\&quot;:0.4368,\&quot;total_value\&quot;:32586.624,\&quot;without_interests\&quot;:false},\&quot;12\&quot;:{\&quot;installment_value\&quot;:2944.809,\&quot;installment_value_cents\&quot;:294480.9,\&quot;interest\&quot;:0.5581,\&quot;total_value\&quot;:35337.708,\&quot;without_interests\&quot;:false},\&quot;18\&quot;:{\&quot;installment_value\&quot;:2350.152,\&quot;installment_value_cents\&quot;:235015.2,\&quot;interest\&quot;:0.8652,\&quot;total_value\&quot;:42302.736,\&quot;without_interests\&quot;:false},\&quot;24\&quot;:{\&quot;installment_value\&quot;:2077.0155,\&quot;installment_value_cents\&quot;:207701.55,\&quot;interest\&quot;:1.1979,\&quot;total_value\&quot;:49848.372,\&quot;without_interests\&quot;:false}},\&quot;Pago Nube\&quot;:{\&quot;2\&quot;:{\&quot;installment_value\&quot;:11340,\&quot;installment_value_cents\&quot;:1134000,\&quot;interest\&quot;:0,\&quot;total_value\&quot;:22680,\&quot;without_interests\&quot;:true}}}&quot;}]">
<div class=" item-image">
<div style="padding-bottom: 100%;" class="position-relative" data-store="product-item-image-207677144">
<a href="https://tekocreaciones.mitiendanube.com/productos/combo-matero-cuadrado/" title="Combo matero (cuadrado)" aria-label="Combo matero (cuadrado)">
<img alt="Combo matero (cuadrado)" data-expand="-10" src="//acdn.mitiendanube.com/assets/themes/amazonas/static/images/empty-placeholder.png" data-srcset="//acdn.mitiendanube.com/stores/001/779/198/products/3-53bcedd0ed0c8ab14517124500333462-240-0.png 240w, //acdn.mitiendanube.com/stores/001/779/198/products/3-53bcedd0ed0c8ab14517124500333462-320-0.png 320w, //acdn.mitiendanube.com/stores/001/779/198/products/3-53bcedd0ed0c8ab14517124500333462-480-0.png 480w" class="js-item-image lazyautosizes lazyload img-absolute img-absolute-centered fade-in " width="1080" height="1080" />
<div class="placeholder-fade">
</div>
</a>
</div>
<div class=" labels " data-store="product-item-labels">
<div class="js-offer-label label label-accent label-circle" data-store="product-item-offer-label">
<span class="js-offer-percentage">
10</span>% OFF
</div>
</div>
<span class="hidden" data-store="stock-product-207677144-1"></span> </div>
<div class="item-description py-4 px-3" data-store="product-item-info-207677144">
<a href="https://tekocreaciones.mitiendanube.com/productos/combo-matero-cuadrado/" title="Combo matero (cuadrado)" aria-label="Combo matero (cuadrado)" class="item-link">
<div class="js-item-name item-name mb-3" data-store="product-item-name-207677144">Combo matero (cuadrado)</div>
<div class="item-price-container mb-1" data-store="product-item-price-207677144">
<span class="js-compare-price-display price-compare" style="display:inline-block;">
$25.200,00
</span>
<span class="js-price-display item-price" data-product-price="2268000">
$22.680,00
</span>
</div>
</a>
<div class="js-max-installments-container js-max-installments item-installments">
<div class="js-max-installments product-installments installment-no-interest">
<span class="js-installment-amount product-installment-amount">2</span>
<span>
cuotas
sin interés
de
</span>
<span class="js-installment-price product-installment-value">$11.340,00</span>
</div>
</div>
</div>
<div class="item-actions row justify-content-center m-0 mb-3">
<div class="col-8 col-md-6 pr-1">
<form class="js-product-form" method="post" action="/comprar/">
<input type="hidden" name="add_to_cart" value="207677144" />
<input type="submit" class="js-addtocart js-prod-submit-form btn btn-primary btn-small w-100 mb-2 cart" value="Comprar" data-component="product-list-item.add-to-cart" data-component-value="207677144" />
<div class="js-addtocart js-addtocart-placeholder btn btn-primary btn-block btn-transition btn-small w-100 mb-2 disabled" style="display: none;">
<div class="d-inline-block">
<span class="js-addtocart-text">Comprar</span>
<span class="js-addtocart-success transition-container btn-transition-success-small">
<svg class="icon-inline svg-icon-invert btn-transition-success-icon"><use xlink:href="#check-circle" /></svg>
</span>
<div class="js-addtocart-adding transition-container transition-soft btn-transition-progress">
<div class="spinner-ellipsis invert">
<div class="point"></div>
<div class="point"></div>
<div class="point"></div>
<div class="point"></div>
</div>
</div>
</div>
</div> </form>
</div>
<div class="col-4 col-md-6 pl-1">
<a href="https://tekocreaciones.mitiendanube.com/productos/combo-matero-cuadrado/" title="Combo matero (cuadrado)" aria-label="Combo matero (cuadrado)" class="d-block btn btn-secondary btn-small">
<svg class="icon-inline svg-icon-primary icon-w-19"><use xlink:href="#eye" /></svg>
<span class="d-none d-md-inline-block">Ver</span></a>
</div>
</div>
</div>
<script type="application/ld+json" data-component="structured-data.item">
    {
        "@context": "https://schema.org/",
        "@type": "Product",
        "mainEntityOfPage": {
            "@type": "WebPage",
            "@id": "https://tekocreaciones.mitiendanube.com/productos/combo-matero-cuadrado/"
        },
        "name": "Combo matero (cuadrado)",
        "image": "https://acdn.mitiendanube.com/stores/001/779/198/products/3-53bcedd0ed0c8ab14517124500333462-480-0.png",
        "description": "Cada combo incluye:  - 1 set de funda para mate, yerbera y azucarera  - 1 bolso matero convertible. Medidas: cada lado (cerrado) es de 20cm de ancho por 32 c...",
                                    "weight": {
                "@type": "QuantitativeValue",
                "unitCode": "KGM",
                "value": "0.9450"
            },
                "offers": {
            "@type": "Offer",
            "url": "https://tekocreaciones.mitiendanube.com/productos/combo-matero-cuadrado/",
            "priceCurrency": "ARS",
            "price": "22680",
                            "availability": "http://schema.org/InStock",
                "inventoryLevel": {
                    "@type": "QuantitativeValue",
                    "value": "1"
                },
                        "seller": {
                "@type": "Organization",
                "name": "Teko Creaciones"
            }
        }
    }
    </script>
</div>
</div>
<div class="js-item-product  col-6 col-md-4 col-lg-3" data-product-type="list" data-product-id="216749097" data-store="product-item-216749097" data-component="product-list-item" data-component-value="216749097" data-grid-classes="col-6 col-md-4 col-lg-3">
<div class="item item-rounded item-product box-rounded p-0">
<div id="quick216749097" class="js-product-container js-quickshop-container position-relative js-quickshop-has-variants" data-variants="[{&quot;product_id&quot;:216749097,&quot;price_short&quot;:&quot;$20.000,00&quot;,&quot;price_long&quot;:&quot;$20.000,00 ARS&quot;,&quot;price_number&quot;:20000,&quot;price_number_raw&quot;:2000000,&quot;price_with_payment_discount_short&quot;:null,&quot;compare_at_price_short&quot;:null,&quot;compare_at_price_long&quot;:null,&quot;compare_at_price_number&quot;:null,&quot;stock&quot;:0,&quot;sku&quot;:null,&quot;available&quot;:false,&quot;contact&quot;:false,&quot;option0&quot;:&quot;1&quot;,&quot;option1&quot;:null,&quot;option2&quot;:null,&quot;id&quot;:948595298,&quot;image&quot;:668076484,&quot;image_url&quot;:&quot;\/\/acdn.mitiendanube.com\/stores\/001\/779\/198\/products\/termos-y-mas_20240612_155423_0010-d7209f42dbf3cfa32b17182190639574-1024-1024.png&quot;,&quot;installments_data&quot;:&quot;{\&quot;mercadopago\&quot;:{\&quot;1\&quot;:{\&quot;installment_value\&quot;:20000,\&quot;installment_value_cents\&quot;:2000000,\&quot;interest\&quot;:0,\&quot;total_value\&quot;:20000,\&quot;without_interests\&quot;:true},\&quot;2\&quot;:{\&quot;installment_value\&quot;:11890,\&quot;installment_value_cents\&quot;:1189000,\&quot;interest\&quot;:0.189,\&quot;total_value\&quot;:23780,\&quot;without_interests\&quot;:false},\&quot;3\&quot;:{\&quot;installment_value\&quot;:8183.3333333333,\&quot;installment_value_cents\&quot;:818333.33333333,\&quot;interest\&quot;:0.2275,\&quot;total_value\&quot;:24550,\&quot;without_interests\&quot;:false},\&quot;6\&quot;:{\&quot;installment_value\&quot;:4451.3333333333,\&quot;installment_value_cents\&quot;:445133.33333333,\&quot;interest\&quot;:0.3354,\&quot;total_value\&quot;:26708,\&quot;without_interests\&quot;:false},\&quot;9\&quot;:{\&quot;installment_value\&quot;:3192.8888888889,\&quot;installment_value_cents\&quot;:319288.88888889,\&quot;interest\&quot;:0.4368,\&quot;total_value\&quot;:28736,\&quot;without_interests\&quot;:false},\&quot;12\&quot;:{\&quot;installment_value\&quot;:2596.8333333333,\&quot;installment_value_cents\&quot;:259683.33333333,\&quot;interest\&quot;:0.5581,\&quot;total_value\&quot;:31162,\&quot;without_interests\&quot;:false},\&quot;18\&quot;:{\&quot;installment_value\&quot;:2072.4444444444,\&quot;installment_value_cents\&quot;:207244.44444444,\&quot;interest\&quot;:0.8652,\&quot;total_value\&quot;:37304,\&quot;without_interests\&quot;:false},\&quot;24\&quot;:{\&quot;installment_value\&quot;:1831.5833333333,\&quot;installment_value_cents\&quot;:183158.33333333,\&quot;interest\&quot;:1.1979,\&quot;total_value\&quot;:43958,\&quot;without_interests\&quot;:false}},\&quot;Pago Nube\&quot;:{\&quot;2\&quot;:{\&quot;installment_value\&quot;:10000,\&quot;installment_value_cents\&quot;:1000000,\&quot;interest\&quot;:0,\&quot;total_value\&quot;:20000,\&quot;without_interests\&quot;:true}}}&quot;},{&quot;product_id&quot;:216749097,&quot;price_short&quot;:&quot;$20.000,00&quot;,&quot;price_long&quot;:&quot;$20.000,00 ARS&quot;,&quot;price_number&quot;:20000,&quot;price_number_raw&quot;:2000000,&quot;price_with_payment_discount_short&quot;:null,&quot;compare_at_price_short&quot;:null,&quot;compare_at_price_long&quot;:null,&quot;compare_at_price_number&quot;:null,&quot;stock&quot;:0,&quot;sku&quot;:null,&quot;available&quot;:false,&quot;contact&quot;:false,&quot;option0&quot;:&quot;2&quot;,&quot;option1&quot;:null,&quot;option2&quot;:null,&quot;id&quot;:948595303,&quot;image&quot;:668076493,&quot;image_url&quot;:&quot;\/\/acdn.mitiendanube.com\/stores\/001\/779\/198\/products\/termos-y-mas_20240612_155423_0011-f6a8d791bb8c33372817182190645649-1024-1024.png&quot;,&quot;installments_data&quot;:&quot;{\&quot;mercadopago\&quot;:{\&quot;1\&quot;:{\&quot;installment_value\&quot;:20000,\&quot;installment_value_cents\&quot;:2000000,\&quot;interest\&quot;:0,\&quot;total_value\&quot;:20000,\&quot;without_interests\&quot;:true},\&quot;2\&quot;:{\&quot;installment_value\&quot;:11890,\&quot;installment_value_cents\&quot;:1189000,\&quot;interest\&quot;:0.189,\&quot;total_value\&quot;:23780,\&quot;without_interests\&quot;:false},\&quot;3\&quot;:{\&quot;installment_value\&quot;:8183.3333333333,\&quot;installment_value_cents\&quot;:818333.33333333,\&quot;interest\&quot;:0.2275,\&quot;total_value\&quot;:24550,\&quot;without_interests\&quot;:false},\&quot;6\&quot;:{\&quot;installment_value\&quot;:4451.3333333333,\&quot;installment_value_cents\&quot;:445133.33333333,\&quot;interest\&quot;:0.3354,\&quot;total_value\&quot;:26708,\&quot;without_interests\&quot;:false},\&quot;9\&quot;:{\&quot;installment_value\&quot;:3192.8888888889,\&quot;installment_value_cents\&quot;:319288.88888889,\&quot;interest\&quot;:0.4368,\&quot;total_value\&quot;:28736,\&quot;without_interests\&quot;:false},\&quot;12\&quot;:{\&quot;installment_value\&quot;:2596.8333333333,\&quot;installment_value_cents\&quot;:259683.33333333,\&quot;interest\&quot;:0.5581,\&quot;total_value\&quot;:31162,\&quot;without_interests\&quot;:false},\&quot;18\&quot;:{\&quot;installment_value\&quot;:2072.4444444444,\&quot;installment_value_cents\&quot;:207244.44444444,\&quot;interest\&quot;:0.8652,\&quot;total_value\&quot;:37304,\&quot;without_interests\&quot;:false},\&quot;24\&quot;:{\&quot;installment_value\&quot;:1831.5833333333,\&quot;installment_value_cents\&quot;:183158.33333333,\&quot;interest\&quot;:1.1979,\&quot;total_value\&quot;:43958,\&quot;without_interests\&quot;:false}},\&quot;Pago Nube\&quot;:{\&quot;2\&quot;:{\&quot;installment_value\&quot;:10000,\&quot;installment_value_cents\&quot;:1000000,\&quot;interest\&quot;:0,\&quot;total_value\&quot;:20000,\&quot;without_interests\&quot;:true}}}&quot;},{&quot;product_id&quot;:216749097,&quot;price_short&quot;:&quot;$20.000,00&quot;,&quot;price_long&quot;:&quot;$20.000,00 ARS&quot;,&quot;price_number&quot;:20000,&quot;price_number_raw&quot;:2000000,&quot;price_with_payment_discount_short&quot;:null,&quot;compare_at_price_short&quot;:null,&quot;compare_at_price_long&quot;:null,&quot;compare_at_price_number&quot;:null,&quot;stock&quot;:1,&quot;sku&quot;:null,&quot;available&quot;:true,&quot;contact&quot;:false,&quot;option0&quot;:&quot;3&quot;,&quot;option1&quot;:null,&quot;option2&quot;:null,&quot;id&quot;:948595307,&quot;image&quot;:668076481,&quot;image_url&quot;:&quot;\/\/acdn.mitiendanube.com\/stores\/001\/779\/198\/products\/termos-y-mas_20240612_155423_0012-988de2aec2813bbb7717182190638454-1024-1024.png&quot;,&quot;installments_data&quot;:&quot;{\&quot;mercadopago\&quot;:{\&quot;1\&quot;:{\&quot;installment_value\&quot;:20000,\&quot;installment_value_cents\&quot;:2000000,\&quot;interest\&quot;:0,\&quot;total_value\&quot;:20000,\&quot;without_interests\&quot;:true},\&quot;2\&quot;:{\&quot;installment_value\&quot;:11890,\&quot;installment_value_cents\&quot;:1189000,\&quot;interest\&quot;:0.189,\&quot;total_value\&quot;:23780,\&quot;without_interests\&quot;:false},\&quot;3\&quot;:{\&quot;installment_value\&quot;:8183.3333333333,\&quot;installment_value_cents\&quot;:818333.33333333,\&quot;interest\&quot;:0.2275,\&quot;total_value\&quot;:24550,\&quot;without_interests\&quot;:false},\&quot;6\&quot;:{\&quot;installment_value\&quot;:4451.3333333333,\&quot;installment_value_cents\&quot;:445133.33333333,\&quot;interest\&quot;:0.3354,\&quot;total_value\&quot;:26708,\&quot;without_interests\&quot;:false},\&quot;9\&quot;:{\&quot;installment_value\&quot;:3192.8888888889,\&quot;installment_value_cents\&quot;:319288.88888889,\&quot;interest\&quot;:0.4368,\&quot;total_value\&quot;:28736,\&quot;without_interests\&quot;:false},\&quot;12\&quot;:{\&quot;installment_value\&quot;:2596.8333333333,\&quot;installment_value_cents\&quot;:259683.33333333,\&quot;interest\&quot;:0.5581,\&quot;total_value\&quot;:31162,\&quot;without_interests\&quot;:false},\&quot;18\&quot;:{\&quot;installment_value\&quot;:2072.4444444444,\&quot;installment_value_cents\&quot;:207244.44444444,\&quot;interest\&quot;:0.8652,\&quot;total_value\&quot;:37304,\&quot;without_interests\&quot;:false},\&quot;24\&quot;:{\&quot;installment_value\&quot;:1831.5833333333,\&quot;installment_value_cents\&quot;:183158.33333333,\&quot;interest\&quot;:1.1979,\&quot;total_value\&quot;:43958,\&quot;without_interests\&quot;:false}},\&quot;Pago Nube\&quot;:{\&quot;2\&quot;:{\&quot;installment_value\&quot;:10000,\&quot;installment_value_cents\&quot;:1000000,\&quot;interest\&quot;:0,\&quot;total_value\&quot;:20000,\&quot;without_interests\&quot;:true}}}&quot;}]">
<div class=" item-image">
<div style="padding-bottom: 100%;" class="position-relative" data-store="product-item-image-216749097">
<a href="https://tekocreaciones.mitiendanube.com/productos/mate-imperial-con-virola-de-acero/" title="Mate imperial con virola de acero" aria-label="Mate imperial con virola de acero">
<img alt="Mate imperial con virola de acero" data-expand="-10" src="//acdn.mitiendanube.com/assets/themes/amazonas/static/images/empty-placeholder.png" data-srcset="//acdn.mitiendanube.com/stores/001/779/198/products/termos-y-mas_20240612_155423_0008-255697023445cdac4317182190644706-240-0.png 240w, //acdn.mitiendanube.com/stores/001/779/198/products/termos-y-mas_20240612_155423_0008-255697023445cdac4317182190644706-320-0.png 320w, //acdn.mitiendanube.com/stores/001/779/198/products/termos-y-mas_20240612_155423_0008-255697023445cdac4317182190644706-480-0.png 480w" class="js-item-image lazyautosizes lazyload img-absolute img-absolute-centered fade-in " width="1080" height="1080" />
<div class="placeholder-fade">
</div>
</a>
</div>
<div class=" labels " data-store="product-item-labels">
</div>
<span class="hidden" data-store="stock-product-216749097-1"></span> <div class="item-buy">
<div class="js-item-variants item-buy-variants px-1 py-2 p-md-3">
<form class="js-product-form" method="post" action="/comprar/">
<input type="hidden" name="add_to_cart" value="216749097" />
<div class="js-product-variants js-product-quickshop-variants form-row mb-2">
<div class="js-product-variants-group  col-12 ">
<div class="form-group form-group-small mb-2">
<label class="form-label mb-1" for="variation_1">Numero </label>
<select id="variation_1" class="form-select js-variation-option js-refresh-installment-data form-control-small " name="variation[0]">
<option value="1">1</option>
<option value="2">2</option>
<option value="3" selected="selected">3</option>
</select>
<div class="form-select-icon">
<svg class="icon-inline icon-w-14 icon-lg"><use xlink:href="#chevron-down" /></svg>
</div>
</div>
</div>
</div>
<input type="submit" class="js-addtocart js-prod-submit-form btn btn-primary btn-small w-100 mb-2 cart" value="Agregar al carrito" />
<div class="js-addtocart js-addtocart-placeholder btn btn-primary btn-block btn-transition btn-small w-100 mb-2 disabled" style="display: none;">
<div class="d-inline-block">
<span class="js-addtocart-text">Agregar al carrito</span>
<span class="js-addtocart-success transition-container btn-transition-success-small">
<svg class="icon-inline svg-icon-invert btn-transition-success-icon"><use xlink:href="#check-circle" /></svg>
</span>
<div class="js-addtocart-adding transition-container transition-soft btn-transition-progress">
<div class="spinner-ellipsis invert">
<div class="point"></div>
<div class="point"></div>
<div class="point"></div>
<div class="point"></div>
</div>
</div>
</div>
</div> </form>
<a href="#" class="js-item-buy-close">
<svg class="icon-inline icon-lg svg-circle svg-icon-text"><use xlink:href="#times" /></svg>
</a>
</div>
</div>
</div>
<div class="item-description py-4 px-3" data-store="product-item-info-216749097">
<a href="https://tekocreaciones.mitiendanube.com/productos/mate-imperial-con-virola-de-acero/" title="Mate imperial con virola de acero" aria-label="Mate imperial con virola de acero" class="item-link">
<div class="js-item-name item-name mb-3" data-store="product-item-name-216749097">Mate imperial con virola de acero</div>
<div class="item-price-container mb-1" data-store="product-item-price-216749097">
<span class="js-compare-price-display price-compare" style="display:none;">
$0,00
</span>
<span class="js-price-display item-price" data-product-price="2000000">
$20.000,00
</span>
</div>
</a>
<div class="js-max-installments-container js-max-installments item-installments">
<div class="js-max-installments product-installments installment-no-interest">
<span class="js-installment-amount product-installment-amount">2</span>
<span>
cuotas
sin interés
de
</span>
<span class="js-installment-price product-installment-value">$10.000,00</span>
</div>
</div>
</div>
<div class="item-actions row justify-content-center m-0 mb-3">
<div class="col-8 col-md-6 pr-1">
<a href="#" class="js-item-buy-open item-buy-open d-block btn btn-primary btn-small" title="Compra rápida de Mate imperial con virola de acero" aria-label="Compra rápida de Mate imperial con virola de acero" data-component="product-list-item.add-to-cart" data-component-value="216749097">Comprar</a>
</div>
<div class="col-4 col-md-6 pl-1">
<a href="https://tekocreaciones.mitiendanube.com/productos/mate-imperial-con-virola-de-acero/" title="Mate imperial con virola de acero" aria-label="Mate imperial con virola de acero" class="d-block btn btn-secondary btn-small">
<svg class="icon-inline svg-icon-primary icon-w-19"><use xlink:href="#eye" /></svg>
<span class="d-none d-md-inline-block">Ver</span></a>
</div>
</div>
</div>
<script type="application/ld+json" data-component="structured-data.item">
    {
        "@context": "https://schema.org/",
        "@type": "Product",
        "mainEntityOfPage": {
            "@type": "WebPage",
            "@id": "https://tekocreaciones.mitiendanube.com/productos/mate-imperial-con-virola-de-acero/"
        },
        "name": "Mate imperial con virola de acero",
        "image": "https://acdn.mitiendanube.com/stores/001/779/198/products/termos-y-mas_20240612_155423_0008-255697023445cdac4317182190644706-480-0.png",
        "description": "Comprá online Mate imperial con virola de acero por $20.000,00. Hacé tu pedido y pagalo online.",
                                    "weight": {
                "@type": "QuantitativeValue",
                "unitCode": "KGM",
                "value": "0.2600"
            },
                "offers": {
            "@type": "Offer",
            "url": "https://tekocreaciones.mitiendanube.com/productos/mate-imperial-con-virola-de-acero/",
            "priceCurrency": "ARS",
            "price": "20000",
                            "availability": "http://schema.org/InStock",
                "inventoryLevel": {
                    "@type": "QuantitativeValue",
                    "value": "1"
                },
                        "seller": {
                "@type": "Organization",
                "name": "Teko Creaciones"
            }
        }
    }
    </script>
</div>
</div>
</div>
</div>
</section>
<script type="text/javascript">
(function() {
	var referrer = (window.decodeURI) ? window.decodeURI(document.referrer) : document.referrer;
    var url = (window.decodeURI) ? window.decodeURI(document.URL) : document.URL;
	
	setTimeout(function() {
            var tracking_url = '/stats/record_visit/?' +
                      'referrer=' + encodeURIComponent(referrer) +
                      '&url=' + encodeURIComponent(url)
                                                            ;
            new Image().src = tracking_url;
	  }, 500);
})();
</script>
<script type="text/javascript">
    LS.ready.then(function() {
                    window.scriptLoaderService.addScriptOnEvent('https\u003A\/\/www.titanpush.com\/es\/tiendanube\/script\u003Fstore\u003D1779198', 'onload');
                    window.scriptLoaderService.addScriptOnEvent('https\u003A\/\/d12zyq17vm1xwx.cloudfront.net\/tiendanube\/tiendanube_promotion_text.min.js\u003Fstore\u003D1779198', 'onload');
                    window.scriptLoaderService.addScriptOnEvent('https\u003A\/\/services\u002Dwallet\u002Dstorefront.tiendanube.com\/bundle.js\u003Fstore\u003D1779198', 'onfirstinteraction');
        
        LS.socialScripts.forEach(function (scriptSrc) {
            window.scriptLoaderService.addScriptOnEvent(scriptSrc, 'onload');
        });
    });
</script>
</div>
<a href="https://wa.me/543435352957" target="_blank" class="js-btn-fixed-bottom btn-whatsapp" aria-label="Comunicate por WhatsApp">
<svg class="icon-inline"><use xlink:href="#whatsapp" /></svg>
</a>
<footer class="js-hide-footer-while-scrolling display-when-content-ready" data-store="footer">
<div class="container-fluid px-md-5">
<div class="row element-footer">
<div class="col">
<h4 class="h3">Categorías</h4>
<ul class="footer-menu">
<li class="footer-menu-item">
<a class="footer-menu-link" href="https://tekocreaciones.mitiendanube.com/productos/">Productos</a>
</li>
<li class="footer-menu-item">
<a class="footer-menu-link" href="https://tekocreaciones.mitiendanube.com/ventas-por-mayor/">Ventas por mayor</a>
</li>
<li class="footer-menu-item">
<a class="footer-menu-link" href="https://tekocreaciones.mitiendanube.com/como-comprar/">Cómo Comprar</a>
</li>
<li class="footer-menu-item">
<a class="footer-menu-link" href="/contacto/">Contacto</a>
</li>
</ul> </div>
<div class="col-md mb-4">
<h4 class="h3">Contactános</h4>
<ul class="contact-info ">
<li class="contact-item">
<svg class="icon-inline icon-lg icon-w contact-item-icon"><use xlink:href="#whatsapp" /></svg>
<a href="https://wa.me/543435352957" class="contact-link">543435352957</a>
</li>
<li class="contact-item">
<svg class="icon-inline icon-lg icon-w contact-item-icon"><use xlink:href="#phone" /></svg>
<a href="tel:+543435352957" class="contact-link">+543435352957</a>
</li>
<li class="contact-item">
<svg class="icon-inline icon-lg icon-w contact-item-icon"><use xlink:href="#email" /></svg>
<a href="/cdn-cgi/l/email-protection#a1d5c4cacec2d3c4c0c2c8cecfc4d2e1c6ccc0c8cd8fc2cecc" class="contact-link"><span class="__cf_email__" data-cfemail="a7d3c2ccc8c4d5c2c6c4cec8c9c2d4e7c0cac6cecb89c4c8ca">[email&#160;protected]</span></a>
</li>
<li class="contact-item">
<svg class="icon-inline icon-lg icon-w contact-item-icon"><use xlink:href="#map-marker-alt" /></svg>
Jorge Luis Borges 42
</li>
</ul> </div>
<div class="col-md mb-4">
<h4 class="h3">Sigamos conectados</h4>
<a class="social-icon-rounded" href="https://instagram.com/teko_creaciones" target="_blank" aria-label="instagram Teko Creaciones">
<svg class="icon-inline icon-lg"><use xlink:href="#instagram" /></svg>
</a>
</div>
</div>
<div class="divider mb-5"></div>
<div class="row element-footer">
<div class="col-md-9">
<div class="footer-payments-shipping-logos">
<div class="row mb-4">
<div class="col-md-4">
<h4 class="h3">Medios de pago</h4>
</div>
<div class="col-md-8">
<img src="//acdn.mitiendanube.com/assets/themes/amazonas/static/images/empty-placeholder.png" data-src="//d26lpennugtm8s.cloudfront.net/assets/common/img/logos/payment/new_logos_payment/visa@2x.png" class="icon-logo lazyload" alt="visa" width="40" height="25">
<img src="//acdn.mitiendanube.com/assets/themes/amazonas/static/images/empty-placeholder.png" data-src="//d26lpennugtm8s.cloudfront.net/assets/common/img/logos/payment/new_logos_payment/mastercard@2x.png" class="icon-logo lazyload" alt="mastercard" width="40" height="25">
<img src="//acdn.mitiendanube.com/assets/themes/amazonas/static/images/empty-placeholder.png" data-src="//d26lpennugtm8s.cloudfront.net/assets/common/img/logos/payment/new_logos_payment/amex@2x.png" class="icon-logo lazyload" alt="amex" width="40" height="25">
<img src="//acdn.mitiendanube.com/assets/themes/amazonas/static/images/empty-placeholder.png" data-src="//d26lpennugtm8s.cloudfront.net/assets/common/img/logos/payment/new_logos_payment/diners@2x.png" class="icon-logo lazyload" alt="diners" width="40" height="25">
<img src="//acdn.mitiendanube.com/assets/themes/amazonas/static/images/empty-placeholder.png" data-src="//d26lpennugtm8s.cloudfront.net/assets/common/img/logos/payment/new_logos_payment/ar/banelco@2x.png" class="icon-logo lazyload" alt="ar_banelco" width="40" height="25">
<img src="//acdn.mitiendanube.com/assets/themes/amazonas/static/images/empty-placeholder.png" data-src="//d26lpennugtm8s.cloudfront.net/assets/common/img/logos/payment/new_logos_payment/ar/cabal@2x.png" class="icon-logo lazyload" alt="ar_cabal" width="40" height="25">
<img src="//acdn.mitiendanube.com/assets/themes/amazonas/static/images/empty-placeholder.png" data-src="//d26lpennugtm8s.cloudfront.net/assets/common/img/logos/payment/new_logos_payment/ar/tarjeta-naranja@2x.png" class="icon-logo lazyload" alt="ar_tarjeta-naranja" width="40" height="25">
<img src="//acdn.mitiendanube.com/assets/themes/amazonas/static/images/empty-placeholder.png" data-src="//d26lpennugtm8s.cloudfront.net/assets/common/img/logos/payment/new_logos_payment/ar/tarjeta-shopping@2x.png" class="icon-logo lazyload" alt="ar_tarjeta-shopping" width="40" height="25">
<img src="//acdn.mitiendanube.com/assets/themes/amazonas/static/images/empty-placeholder.png" data-src="//d26lpennugtm8s.cloudfront.net/assets/common/img/logos/payment/new_logos_payment/mercadopago@2x.png" class="icon-logo lazyload" alt="mercadopago" width="40" height="25">
<img src="//acdn.mitiendanube.com/assets/themes/amazonas/static/images/empty-placeholder.png" data-src="//d26lpennugtm8s.cloudfront.net/assets/common/img/logos/payment/new_logos_payment/ar/argencard@2x.png" class="icon-logo lazyload" alt="ar_argencard" width="40" height="25">
<img src="//acdn.mitiendanube.com/assets/themes/amazonas/static/images/empty-placeholder.png" data-src="//d26lpennugtm8s.cloudfront.net/assets/common/img/logos/payment/new_logos_payment/ar/cencosud@2x.png" class="icon-logo lazyload" alt="ar_cencosud" width="40" height="25">
<img src="//acdn.mitiendanube.com/assets/themes/amazonas/static/images/empty-placeholder.png" data-src="//d26lpennugtm8s.cloudfront.net/assets/common/img/logos/payment/new_logos_payment/pagofacil@2x.png" class="icon-logo lazyload" alt="pagofacil" width="40" height="25">
<img src="//acdn.mitiendanube.com/assets/themes/amazonas/static/images/empty-placeholder.png" data-src="//d26lpennugtm8s.cloudfront.net/assets/common/img/logos/payment/new_logos_payment/rapipago@2x.png" class="icon-logo lazyload" alt="rapipago" width="40" height="25">
<img src="//acdn.mitiendanube.com/assets/themes/amazonas/static/images/empty-placeholder.png" data-src="//d26lpennugtm8s.cloudfront.net/assets/common/img/logos/payment/new_logos_payment/ar/falabella@2x.png" class="icon-logo lazyload" alt="ar_falabella" width="40" height="25">
<img src="//acdn.mitiendanube.com/assets/themes/amazonas/static/images/empty-placeholder.png" data-src="//d26lpennugtm8s.cloudfront.net/assets/common/img/logos/payment/new_logos_payment/nativa@2x.png" class="icon-logo lazyload" alt="nativa" width="40" height="25">
<img src="//acdn.mitiendanube.com/assets/themes/amazonas/static/images/empty-placeholder.png" data-src="//d26lpennugtm8s.cloudfront.net/assets/common/img/logos/payment/new_logos_payment/ar/cabaldebit@2x.png" class="icon-logo lazyload" alt="ar_cabaldebit" width="40" height="25">
</div>
</div>
<div class="row mb-4">
<div class="col-md-4">
<h4 class="h3">Medios de envío</h4>
</div>
<div class="col-md-8">
<img src="//acdn.mitiendanube.com/assets/themes/amazonas/static/images/empty-placeholder.png" data-src="//d26lpennugtm8s.cloudfront.net/assets/common/img/logos/shipping/api/2682@2x.png" class="icon-logo lazyload" alt="api_2682" width="40" height="25">
</div>
</div>
</div>
</div>
</div>
</div>
<div class="js-footer-legal footer-legal">
<div class="container-fluid px-md-5">
<div class="row">
<div class="col-md-9 text-md-left mb-3 mb-md-0">
<div class="d-inline-block mr-md-2">
Copyright Teko Creaciones - 2024. Todos los derechos reservados.
</div>
<div class="claim-link d-md-inline-block mt-md-0 mt-3">
<span class="d-inline-block mb-1">Defensa de las y los consumidores. Para reclamos</span>
<a class="font-weight-bold" href="https://www.argentina.gob.ar/produccion/defensadelconsumidor/formulario" target="_blank" data-component="consumer-defense">ingresá acá.</a>
<span class="mx-1">/</span>
<a class="font-weight-bold" href="/contacto/?order_cancellation_without_id=true" data-component="order-cancellation">Botón de arrepentimiento</a>
</div>
</div>
<div class="col-md text-left text-md-right">
<div class="powered-by-logo">
<a target="_blank" title="Tiendanube" rel="nofollow" href="https://www.tiendanube.com?utm_source=store&utm_medium=referral&utm_campaign=footerSlogan"><svg title="Tiendanube" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1080 120" id="svg_brand"><path d="M37.2 42.8c4.6 0 8.8 1.3 12.5 3.8v7.9c-3.9-3-7.9-4.4-12.2-4.4-9 0-15.5 6.9-15.5 15.8 0 8.8 6.5 15.8 15.5 15.8 4.6 0 8.9-2.1 12.4-4.4v7.9c-3.9 2.5-8.1 3.7-12.7 3.7-13.8 0-23.1-10.1-23.1-23.1 0-12.9 9.5-23 23.1-23zM80.5 51c-.1 0-.3 0-.5-.1-.4 0-1-.1-1.6-.1-8.3 0-13.2 6.5-13.2 16.1v21h-7.7V43.8H65v7.8c1.9-5.1 7.8-8.5 13.5-8.5.6 0 1 .1 1.4.1.3.1.5.1.5.1l.1 7.7zm1 14.8c0-13.1 9.4-23.1 22-23.1 12.4 0 21.4 10.1 21.4 22.7 0 1-.1 1.6-.1 2.1v.7H89.3c.5 7.7 7.2 13.6 14.8 13.6 6.6 0 10-3.2 12.8-7.5l6.4 3.3c-3.6 6.6-10.3 11.3-19.2 11.3-13.2 0-22.6-9.7-22.6-23.1zm35.4-4c-.7-6.9-6.5-12.3-13.7-12.3s-13.1 6.3-13.8 12.3h27.5zm27.9.3l13.2-1.6v-2.3c0-5.4-3.5-8.5-9.3-8.5-5.3 0-8.7 2.6-10.3 7.8l-7.4-2.1c2.2-7.7 8.9-12.6 17.5-12.6 10.8 0 17 6.1 17 16v29.1h-7.4v-5.8c-3.5 4.4-8.9 6.8-14.8 6.8-8.3 0-13.9-5.4-13.9-12.6.2-7.9 5.2-12.8 15.4-14.2zm.1 19.9c7.6 0 13.2-4.9 13.2-11.7v-3.2l-12 1.5c-5.5.7-8.6 3.4-8.6 7.2 0 3.7 3 6.2 7.4 6.2zm73.3-57.7v63.5h-7.7v-7c-3.2 4.8-9.1 8-15.6 8-12.6 0-22.2-10-22.2-23.1 0-13 9.5-23.1 22.2-23.1 6.5 0 12.3 2.8 15.6 7.6V24.3h7.7zm-22.5 25.6c-8.7 0-15.2 6.9-15.2 15.9s6.4 15.9 15.2 15.9 15.2-6.9 15.2-15.9-6.5-15.9-15.2-15.9zM272 65.8c0 12.7-9.7 23.1-23.1 23.1-13.3 0-23.1-10.3-23.1-23.1s9.7-23.1 23.1-23.1c13.4.1 23.1 10.4 23.1 23.1zm-38.2 0c0 8.8 6.4 15.9 15.2 15.9 8.8 0 15.2-7.1 15.2-15.9s-6.4-15.9-15.2-15.9-15.2 7.1-15.2 15.9zm77.7-23c4.6 0 8.8 1.3 12.5 3.8v7.9c-3.9-3-7.9-4.4-12.2-4.4-9 0-15.5 6.9-15.5 15.8 0 8.8 6.5 15.8 15.5 15.8 4.6 0 8.9-2.1 12.4-4.4v7.9c-3.9 2.5-8.1 3.7-12.7 3.7-13.8 0-23.1-10.1-23.1-23.1 0-12.9 9.6-23 23.1-23zm63.2 23c0 12.7-9.7 23.1-23.1 23.1-13.3 0-23.1-10.3-23.1-23.1s9.7-23.1 23.1-23.1c13.4.1 23.1 10.4 23.1 23.1zm-38.2 0c0 8.8 6.4 15.9 15.2 15.9s15.2-7.1 15.2-15.9-6.4-15.9-15.2-15.9-15.2 7.1-15.2 15.9zm53.7 22.1h-7.8V43.8h7.8v6.4c2.8-4.4 7.4-7.4 14.1-7.4 11.3 0 17.8 7.5 17.8 19.2v25.9h-7.8v-25c0-8-4-12.9-11.6-12.9s-12.4 5.7-12.4 14.8v23.1h-.1zM541.3 10s-.1 0 0 0c-13.1 0-25.6 5.1-34.9 14.2-4.7-2-9.9-3.1-15.2-3.1-21.4 0-38.9 17.4-38.9 38.9s17.4 38.9 38.9 38.9c5.2 0 10.4-1.1 15.1-3.1 9 8.8 21.3 14.2 34.8 14.2 27.6 0 50-22.4 50-50 .1-27.5-22.3-50-49.8-50zm-.1 88.9c-21.4 0-38.9-17.4-38.9-38.9h-11.1c0 9.8 2.8 19 7.7 26.7-2.5.7-5.1 1.1-7.7 1.1-15.3 0-27.8-12.5-27.8-27.8s12.5-27.8 27.8-27.8c6.1 0 11.8 1.9 16.7 5.6C515 43.1 519 51.2 519 60h11.1c0-11.6-5-22.4-13.9-29.8 7-5.8 15.8-9.1 25-9.1 21.4 0 38.9 17.5 38.9 38.9s-17.5 38.9-38.9 38.9zm78.2-11V52.3h-7.5v-8.9h7.5V30.2h10.5v13.2h7.5v8.9h-7.5v35.6h-10.5zm28.9-51c-3.5 0-6.4-2.9-6.4-6.4 0-3.6 2.9-6.5 6.4-6.5 3.7 0 6.5 3 6.5 6.5s-2.8 6.4-6.5 6.4zm-5.2 51V43.4h10.5v44.5h-10.5zm59.8-10.5c-3.7 7-10.6 11.5-20.1 11.5-13.5 0-23.1-9.6-23.1-23.3 0-13.3 9.8-23.3 22.6-23.3 13 0 22.1 10 22.1 23.3 0 .8 0 1.9-.1 3.2h-34.2c.5 6.4 6.2 11.3 12.8 11.3 5.8 0 8.8-2.8 11.3-6.7l8.7 4zm-8.8-16.2c-.7-5.9-5.4-10.3-11.9-10.3-6.3 0-11.2 5.2-11.9 10.3h23.8zm26.5 26.7h-10.5V43.4h10.5v5.9c2.8-4.3 7.4-7 13.6-7 10.9 0 17.2 7.2 17.2 18.8v26.8H741V63.1c0-6.9-3.4-11.1-9.9-11.1-6.3 0-10.4 4.8-10.4 12.4l-.1 23.5zm73.2 0v-6.4c-3.3 4.6-8.9 7.4-15.1 7.4C766.5 89 757 79 757 65.6c0-13.1 9.4-23.3 21.7-23.3 6.2 0 11.8 2.5 15.1 7.2V26.7h10.4v61.2h-10.4zm-12.9-8.5c7.5 0 13.3-6.2 13.3-13.8 0-7.6-5.8-13.8-13.3-13.8s-13.3 6.2-13.3 13.8c-.1 7.7 5.8 13.8 13.3 13.8zm45.3-17.8l12.1-1.5v-1.9c0-4.4-3.1-7.3-7.9-7.3-4.5 0-7.4 2.3-8.8 6.7l-9.6-2.5c2.2-8 9.3-12.9 18.4-12.9 11.6 0 18.1 6.1 18.1 16.6v28.9h-9.8l-.1-5.4c-3 4.3-8.1 6.5-13.9 6.5-8.4 0-14.3-5.4-14.3-12.9 0-7.9 5.2-12.7 15.8-14.3zm1 18.9c6.5 0 11.2-4.2 11.2-10.1v-2.5l-10.1 1.4c-5 .6-7.4 2.9-7.4 6.1s2.5 5.1 6.3 5.1zm40.2 7.4h-10.5V43.4h10.5v5.9c2.8-4.3 7.4-7 13.6-7 10.9 0 17.2 7.2 17.2 18.8v26.8h-10.5V63.1c0-6.9-3.4-11.1-9.9-11.1-6.3 0-10.4 4.8-10.4 12.4v23.5zm38.5-19.2V43.4h10.5v24.7c0 7 3.4 11.2 9.3 11.2s9.3-4.2 9.3-11.2V43.4h10.5v25.3c0 12.8-7.4 20.2-19.8 20.2-12.3.1-19.8-7.4-19.8-20.2zm48 19.2V26.7h10.4v23.1c3.3-4.6 8.9-7.4 15.1-7.4 12.3 0 21.7 10 21.7 23.3 0 13.1-9.4 23.3-21.7 23.3-6.2 0-11.8-2.5-15.1-7.2v6.1h-10.4zm23.3-36.1c-7.5 0-13.3 6.2-13.3 13.8s5.8 13.8 13.3 13.8 13.3-6.2 13.3-13.8c.1-7.6-5.7-13.8-13.3-13.8zm70.6 25.6c-3.7 7-10.6 11.5-20.1 11.5-13.5 0-23.1-9.6-23.1-23.3 0-13.3 9.8-23.3 22.6-23.3 13 0 22.1 10 22.1 23.3 0 .8 0 1.9-.1 3.2H1015c.5 6.4 6.2 11.3 12.8 11.3 5.8 0 8.8-2.8 11.3-6.7l8.7 4zm-8.9-16.2c-.7-5.9-5.4-10.3-11.9-10.3-6.3 0-11.2 5.2-11.9 10.3h23.8z" /></svg></a>
</div>
</div>
</div>
</div>
</div>
</footer>
<script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script type="text/javascript">

            
            

!function(e){var t=function(u,D,f){"use strict";var k,H;if(function(){var e;var t={lazyClass:"lazyload",loadedClass:"lazyloaded",loadingClass:"lazyloading",preloadClass:"lazypreload",errorClass:"lazyerror",autosizesClass:"lazyautosizes",srcAttr:"data-src",srcsetAttr:"data-srcset",sizesAttr:"data-sizes",minSize:40,customMedia:{},init:true,expFactor:1.5,hFac:.8,loadMode:2,loadHidden:true,ricTimeout:0,throttleDelay:125};H=u.lazySizesConfig||u.lazysizesConfig||{};for(e in t){if(!(e in H)){H[e]=t[e]}}}(),!D||!D.getElementsByClassName){return{init:function(){},cfg:H,noSupport:true}}var O=D.documentElement,a=u.HTMLPictureElement,P="addEventListener",$="getAttribute",q=u[P].bind(u),I=u.setTimeout,U=u.requestAnimationFrame||I,l=u.requestIdleCallback,j=/^picture$/i,r=["load","error","lazyincluded","_lazyloaded"],i={},G=Array.prototype.forEach,J=function(e,t){if(!i[t]){i[t]=new RegExp("(\\s|^)"+t+"(\\s|$)")}return i[t].test(e[$]("class")||"")&&i[t]},K=function(e,t){if(!J(e,t)){e.setAttribute("class",(e[$]("class")||"").trim()+" "+t)}},Q=function(e,t){var i;if(i=J(e,t)){e.setAttribute("class",(e[$]("class")||"").replace(i," "))}},V=function(t,i,e){var a=e?P:"removeEventListener";if(e){V(t,i)}r.forEach(function(e){t[a](e,i)})},X=function(e,t,i,a,r){var n=D.createEvent("Event");if(!i){i={}}i.instance=k;n.initEvent(t,!a,!r);n.detail=i;e.dispatchEvent(n);return n},Y=function(e,t){var i;if(!a&&(i=u.picturefill||H.pf)){if(t&&t.src&&!e[$]("srcset")){e.setAttribute("srcset",t.src)}i({reevaluate:true,elements:[e]})}else if(t&&t.src){e.src=t.src}},Z=function(e,t){return(getComputedStyle(e,null)||{})[t]},s=function(e,t,i){i=i||e.offsetWidth;while(i<H.minSize&&t&&!e._lazysizesWidth){i=t.offsetWidth;t=t.parentNode}return i},ee=function(){var i,a;var t=[];var r=[];var n=t;var s=function(){var e=n;n=t.length?r:t;i=true;a=false;while(e.length){e.shift()()}i=false};var e=function(e,t){if(i&&!t){e.apply(this,arguments)}else{n.push(e);if(!a){a=true;(D.hidden?I:U)(s)}}};e._lsFlush=s;return e}(),te=function(i,e){return e?function(){ee(i)}:function(){var e=this;var t=arguments;ee(function(){i.apply(e,t)})}},ie=function(e){var i;var a=0;var r=H.throttleDelay;var n=H.ricTimeout;var t=function(){i=false;a=f.now();e()};var s=l&&n>49?function(){l(t,{timeout:n});if(n!==H.ricTimeout){n=H.ricTimeout}}:te(function(){I(t)},true);return function(e){var t;if(e=e===true){n=33}if(i){return}i=true;t=r-(f.now()-a);if(t<0){t=0}if(e||t<9){s()}else{I(s,t)}}},ae=function(e){var t,i;var a=99;var r=function(){t=null;e()};var n=function(){var e=f.now()-i;if(e<a){I(n,a-e)}else{(l||r)(r)}};return function(){i=f.now();if(!t){t=I(n,a)}}},e=function(){var v,m,c,h,e;var y,z,g,p,C,b,A;var n=/^img$/i;var d=/^iframe$/i;var E="onscroll"in u&&!/(gle|ing)bot/.test(navigator.userAgent);var _=0;var w=0;var N=0;var M=-1;var x=function(e){N--;if(!e||N<0||!e.target){N=0}};var W=function(e){if(A==null){A=Z(D.body,"visibility")=="hidden"}return A||!(Z(e.parentNode,"visibility")=="hidden"&&Z(e,"visibility")=="hidden")};var S=function(e,t){var i;var a=e;var r=W(e);g-=t;b+=t;p-=t;C+=t;while(r&&(a=a.offsetParent)&&a!=D.body&&a!=O){r=(Z(a,"opacity")||1)>0;if(r&&Z(a,"overflow")!="visible"){i=a.getBoundingClientRect();r=C>i.left&&p<i.right&&b>i.top-1&&g<i.bottom+1}}return r};var t=function(){var e,t,i,a,r,n,s,l,o,u,f,c;var d=k.elements;if((h=H.loadMode)&&N<8&&(e=d.length)){t=0;M++;for(;t<e;t++){if(!d[t]||d[t]._lazyRace){continue}if(!E||k.prematureUnveil&&k.prematureUnveil(d[t])){R(d[t]);continue}if(!(l=d[t][$]("data-expand"))||!(n=l*1)){n=w}if(!u){u=!H.expand||H.expand<1?O.clientHeight>500&&O.clientWidth>500?500:370:H.expand;k._defEx=u;f=u*H.expFactor;c=H.hFac;A=null;if(w<f&&N<1&&M>2&&h>2&&!D.hidden){w=f;M=0}else if(h>1&&M>1&&N<6){w=u}else{w=_}}if(o!==n){y=innerWidth+n*c;z=innerHeight+n;s=n*-1;o=n}i=d[t].getBoundingClientRect();if((b=i.bottom)>=s&&(g=i.top)<=z&&(C=i.right)>=s*c&&(p=i.left)<=y&&(b||C||p||g)&&(H.loadHidden||W(d[t]))&&(m&&N<3&&!l&&(h<3||M<4)||S(d[t],n))){R(d[t]);r=true;if(N>9){break}}else if(!r&&m&&!a&&N<4&&M<4&&h>2&&(v[0]||H.preloadAfterLoad)&&(v[0]||!l&&(b||C||p||g||d[t][$](H.sizesAttr)!="auto"))){a=v[0]||d[t]}}if(a&&!r){R(a)}}};var i=ie(t);var B=function(e){var t=e.target;if(t._lazyCache){delete t._lazyCache;return}x(e);K(t,H.loadedClass);Q(t,H.loadingClass);V(t,L);X(t,"lazyloaded")};var a=te(B);var L=function(e){a({target:e.target})};var T=function(t,i){try{t.contentWindow.location.replace(i)}catch(e){t.src=i}};var F=function(e){var t;var i=e[$](H.srcsetAttr);if(t=H.customMedia[e[$]("data-media")||e[$]("media")]){e.setAttribute("media",t)}if(i){e.setAttribute("srcset",i)}};var s=te(function(t,e,i,a,r){var n,s,l,o,u,f;if(!(u=X(t,"lazybeforeunveil",e)).defaultPrevented){if(a){if(i){K(t,H.autosizesClass)}else{t.setAttribute("sizes",a)}}s=t[$](H.srcsetAttr);n=t[$](H.srcAttr);if(r){l=t.parentNode;o=l&&j.test(l.nodeName||"")}f=e.firesLoad||"src"in t&&(s||n||o);u={target:t};K(t,H.loadingClass);if(f){clearTimeout(c);c=I(x,2500);V(t,L,true)}if(o){G.call(l.getElementsByTagName("source"),F)}if(s){t.setAttribute("srcset",s)}else if(n&&!o){if(d.test(t.nodeName)){T(t,n)}else{t.src=n}}if(r&&(s||o)){Y(t,{src:n})}}if(t._lazyRace){delete t._lazyRace}Q(t,H.lazyClass);ee(function(){var e=t.complete&&t.naturalWidth>1;if(!f||e){if(e){K(t,"ls-is-cached")}B(u);t._lazyCache=true;I(function(){if("_lazyCache"in t){delete t._lazyCache}},9)}if(t.loading=="lazy"){N--}},true)});var R=function(e){if(e._lazyRace){return}var t;var i=n.test(e.nodeName);var a=i&&(e[$](H.sizesAttr)||e[$]("sizes"));var r=a=="auto";if((r||!m)&&i&&(e[$]("src")||e.srcset)&&!e.complete&&!J(e,H.errorClass)&&J(e,H.lazyClass)){return}t=X(e,"lazyunveilread").detail;if(r){re.updateElem(e,true,e.offsetWidth)}e._lazyRace=true;N++;s(e,t,r,a,i)};var r=ae(function(){H.loadMode=3;i()});var l=function(){if(H.loadMode==3){H.loadMode=2}r()};var o=function(){if(m){return}if(f.now()-e<999){I(o,999);return}m=true;H.loadMode=3;i();q("scroll",l,true)};return{_:function(){e=f.now();k.elements=D.getElementsByClassName(H.lazyClass);v=D.getElementsByClassName(H.lazyClass+" "+H.preloadClass);q("scroll",i,true);q("resize",i,true);q("pageshow",function(e){if(e.persisted){var t=D.querySelectorAll("."+H.loadingClass);if(t.length&&t.forEach){U(function(){t.forEach(function(e){if(e.complete){R(e)}})})}}});if(u.MutationObserver){new MutationObserver(i).observe(O,{childList:true,subtree:true,attributes:true})}else{O[P]("DOMNodeInserted",i,true);O[P]("DOMAttrModified",i,true);setInterval(i,999)}q("hashchange",i,true);["focus","mouseover","click","load","transitionend","animationend"].forEach(function(e){D[P](e,i,true)});if(/d$|^c/.test(D.readyState)){o()}else{q("load",o);D[P]("DOMContentLoaded",i);I(o,2e4)}if(k.elements.length){t();ee._lsFlush()}else{i()}},checkElems:i,unveil:R,_aLSL:l}}(),re=function(){var i;var n=te(function(e,t,i,a){var r,n,s;e._lazysizesWidth=a;a+="px";e.setAttribute("sizes",a);if(j.test(t.nodeName||"")){r=t.getElementsByTagName("source");for(n=0,s=r.length;n<s;n++){r[n].setAttribute("sizes",a)}}if(!i.detail.dataAttr){Y(e,i.detail)}});var a=function(e,t,i){var a;var r=e.parentNode;if(r){i=s(e,r,i);a=X(e,"lazybeforesizes",{width:i,dataAttr:!!t});if(!a.defaultPrevented){i=a.detail.width;if(i&&i!==e._lazysizesWidth){n(e,r,a,i)}}}};var e=function(){var e;var t=i.length;if(t){e=0;for(;e<t;e++){a(i[e])}}};var t=ae(e);return{_:function(){i=D.getElementsByClassName(H.autosizesClass);q("resize",t)},checkElems:t,updateElem:a}}(),t=function(){if(!t.i&&D.getElementsByClassName){t.i=true;re._();e._()}};return I(function(){H.init&&t()}),k={cfg:H,autoSizer:re,loader:e,init:t,uP:Y,aC:K,rC:Q,hC:J,fire:X,gW:s,rAF:ee}}(e,e.document,Date);e.lazySizes=t,"object"==typeof module&&module.exports&&(module.exports=t)}("undefined"!=typeof window?window:{});

!function(e,t){"object"==typeof exports&&"undefined"!=typeof module?module.exports=t():"function"==typeof define&&define.amd?define(t):(e=e||self).Swiper=t()}(this,(function(){"use strict";function e(e,t){for(var i=0;i<t.length;i++){var s=t[i];s.enumerable=s.enumerable||!1,s.configurable=!0,"value"in s&&(s.writable=!0),Object.defineProperty(e,s.key,s)}}function t(){return(t=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var i=arguments[t];for(var s in i)Object.prototype.hasOwnProperty.call(i,s)&&(e[s]=i[s])}return e}).apply(this,arguments)}function i(e){return null!==e&&"object"==typeof e&&"constructor"in e&&e.constructor===Object}function s(e,t){void 0===e&&(e={}),void 0===t&&(t={}),Object.keys(t).forEach((function(a){void 0===e[a]?e[a]=t[a]:i(t[a])&&i(e[a])&&Object.keys(t[a]).length>0&&s(e[a],t[a])}))}var a={body:{},addEventListener:function(){},removeEventListener:function(){},activeElement:{blur:function(){},nodeName:""},querySelector:function(){return null},querySelectorAll:function(){return[]},getElementById:function(){return null},createEvent:function(){return{initEvent:function(){}}},createElement:function(){return{children:[],childNodes:[],style:{},setAttribute:function(){},getElementsByTagName:function(){return[]}}},createElementNS:function(){return{}},importNode:function(){return null},location:{hash:"",host:"",hostname:"",href:"",origin:"",pathname:"",protocol:"",search:""}};function r(){var e="undefined"!=typeof document?document:{};return s(e,a),e}var n={document:a,navigator:{userAgent:""},location:{hash:"",host:"",hostname:"",href:"",origin:"",pathname:"",protocol:"",search:""},history:{replaceState:function(){},pushState:function(){},go:function(){},back:function(){}},CustomEvent:function(){return this},addEventListener:function(){},removeEventListener:function(){},getComputedStyle:function(){return{getPropertyValue:function(){return""}}},Image:function(){},Date:function(){},screen:{},setTimeout:function(){},clearTimeout:function(){},matchMedia:function(){return{}},requestAnimationFrame:function(e){return"undefined"==typeof setTimeout?(e(),null):setTimeout(e,0)},cancelAnimationFrame:function(e){"undefined"!=typeof setTimeout&&clearTimeout(e)}};function o(){var e="undefined"!=typeof window?window:{};return s(e,n),e}function l(e){return(l=Object.setPrototypeOf?Object.getPrototypeOf:function(e){return e.__proto__||Object.getPrototypeOf(e)})(e)}function d(e,t){return(d=Object.setPrototypeOf||function(e,t){return e.__proto__=t,e})(e,t)}function h(){if("undefined"==typeof Reflect||!Reflect.construct)return!1;if(Reflect.construct.sham)return!1;if("function"==typeof Proxy)return!0;try{return Date.prototype.toString.call(Reflect.construct(Date,[],(function(){}))),!0}catch(e){return!1}}function p(e,t,i){return(p=h()?Reflect.construct:function(e,t,i){var s=[null];s.push.apply(s,t);var a=new(Function.bind.apply(e,s));return i&&d(a,i.prototype),a}).apply(null,arguments)}function u(e){var t="function"==typeof Map?new Map:void 0;return(u=function(e){if(null===e||(i=e,-1===Function.toString.call(i).indexOf("[native code]")))return e;var i;if("function"!=typeof e)throw new TypeError("Super expression must either be null or a function");if(void 0!==t){if(t.has(e))return t.get(e);t.set(e,s)}function s(){return p(e,arguments,l(this).constructor)}return s.prototype=Object.create(e.prototype,{constructor:{value:s,enumerable:!1,writable:!0,configurable:!0}}),d(s,e)})(e)}var c=function(e){var t,i;function s(t){var i,s,a;return i=e.call.apply(e,[this].concat(t))||this,s=function(e){if(void 0===e)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return e}(i),a=s.__proto__,Object.defineProperty(s,"__proto__",{get:function(){return a},set:function(e){a.__proto__=e}}),i}return i=e,(t=s).prototype=Object.create(i.prototype),t.prototype.constructor=t,t.__proto__=i,s}(u(Array));function v(e){void 0===e&&(e=[]);var t=[];return e.forEach((function(e){Array.isArray(e)?t.push.apply(t,v(e)):t.push(e)})),t}function f(e,t){return Array.prototype.filter.call(e,t)}function m(e,t){var i=o(),s=r(),a=[];if(!t&&e instanceof c)return e;if(!e)return new c(a);if("string"==typeof e){var n=e.trim();if(n.indexOf("<")>=0&&n.indexOf(">")>=0){var l="div";0===n.indexOf("<li")&&(l="ul"),0===n.indexOf("<tr")&&(l="tbody"),0!==n.indexOf("<td")&&0!==n.indexOf("<th")||(l="tr"),0===n.indexOf("<tbody")&&(l="table"),0===n.indexOf("<option")&&(l="select");var d=s.createElement(l);d.innerHTML=n;for(var h=0;h<d.childNodes.length;h+=1)a.push(d.childNodes[h])}else a=function(e,t){if("string"!=typeof e)return[e];for(var i=[],s=t.querySelectorAll(e),a=0;a<s.length;a+=1)i.push(s[a]);return i}(e.trim(),t||s)}else if(e.nodeType||e===i||e===s)a.push(e);else if(Array.isArray(e)){if(e instanceof c)return e;a=e}return new c(function(e){for(var t=[],i=0;i<e.length;i+=1)-1===t.indexOf(e[i])&&t.push(e[i]);return t}(a))}m.fn=c.prototype;var g,y,C,w={addClass:function(){for(var e=arguments.length,t=new Array(e),i=0;i<e;i++)t[i]=arguments[i];var s=v(t.map((function(e){return e.split(" ")})));return this.forEach((function(e){var t;(t=e.classList).add.apply(t,s)})),this},removeClass:function(){for(var e=arguments.length,t=new Array(e),i=0;i<e;i++)t[i]=arguments[i];var s=v(t.map((function(e){return e.split(" ")})));return this.forEach((function(e){var t;(t=e.classList).remove.apply(t,s)})),this},hasClass:function(){for(var e=arguments.length,t=new Array(e),i=0;i<e;i++)t[i]=arguments[i];var s=v(t.map((function(e){return e.split(" ")})));return f(this,(function(e){return s.filter((function(t){return e.classList.contains(t)})).length>0})).length>0},toggleClass:function(){for(var e=arguments.length,t=new Array(e),i=0;i<e;i++)t[i]=arguments[i];var s=v(t.map((function(e){return e.split(" ")})));this.forEach((function(e){s.forEach((function(t){e.classList.toggle(t)}))}))},attr:function(e,t){if(1===arguments.length&&"string"==typeof e)return this[0]?this[0].getAttribute(e):void 0;for(var i=0;i<this.length;i+=1)if(2===arguments.length)this[i].setAttribute(e,t);else for(var s in e)this[i][s]=e[s],this[i].setAttribute(s,e[s]);return this},removeAttr:function(e){for(var t=0;t<this.length;t+=1)this[t].removeAttribute(e);return this},transform:function(e){for(var t=0;t<this.length;t+=1)this[t].style.transform=e;return this},transition:function(e){for(var t=0;t<this.length;t+=1)this[t].style.transition="string"!=typeof e?e+"ms":e;return this},on:function(){for(var e=arguments.length,t=new Array(e),i=0;i<e;i++)t[i]=arguments[i];var s=t[0],a=t[1],r=t[2],n=t[3];function o(e){var t=e.target;if(t){var i=e.target.dom7EventData||[];if(i.indexOf(e)<0&&i.unshift(e),m(t).is(a))r.apply(t,i);else for(var s=m(t).parents(),n=0;n<s.length;n+=1)m(s[n]).is(a)&&r.apply(s[n],i)}}function l(e){var t=e&&e.target&&e.target.dom7EventData||[];t.indexOf(e)<0&&t.unshift(e),r.apply(this,t)}"function"==typeof t[1]&&(s=t[0],r=t[1],n=t[2],a=void 0),n||(n=!1);for(var d,h=s.split(" "),p=0;p<this.length;p+=1){var u=this[p];if(a)for(d=0;d<h.length;d+=1){var c=h[d];u.dom7LiveListeners||(u.dom7LiveListeners={}),u.dom7LiveListeners[c]||(u.dom7LiveListeners[c]=[]),u.dom7LiveListeners[c].push({listener:r,proxyListener:o}),u.addEventListener(c,o,n)}else for(d=0;d<h.length;d+=1){var v=h[d];u.dom7Listeners||(u.dom7Listeners={}),u.dom7Listeners[v]||(u.dom7Listeners[v]=[]),u.dom7Listeners[v].push({listener:r,proxyListener:l}),u.addEventListener(v,l,n)}}return this},off:function(){for(var e=arguments.length,t=new Array(e),i=0;i<e;i++)t[i]=arguments[i];var s=t[0],a=t[1],r=t[2],n=t[3];"function"==typeof t[1]&&(s=t[0],r=t[1],n=t[2],a=void 0),n||(n=!1);for(var o=s.split(" "),l=0;l<o.length;l+=1)for(var d=o[l],h=0;h<this.length;h+=1){var p=this[h],u=void 0;if(!a&&p.dom7Listeners?u=p.dom7Listeners[d]:a&&p.dom7LiveListeners&&(u=p.dom7LiveListeners[d]),u&&u.length)for(var c=u.length-1;c>=0;c-=1){var v=u[c];r&&v.listener===r||r&&v.listener&&v.listener.dom7proxy&&v.listener.dom7proxy===r?(p.removeEventListener(d,v.proxyListener,n),u.splice(c,1)):r||(p.removeEventListener(d,v.proxyListener,n),u.splice(c,1))}}return this},trigger:function(){for(var e=o(),t=arguments.length,i=new Array(t),s=0;s<t;s++)i[s]=arguments[s];for(var a=i[0].split(" "),r=i[1],n=0;n<a.length;n+=1)for(var l=a[n],d=0;d<this.length;d+=1){var h=this[d];if(e.CustomEvent){var p=new e.CustomEvent(l,{detail:r,bubbles:!0,cancelable:!0});h.dom7EventData=i.filter((function(e,t){return t>0})),h.dispatchEvent(p),h.dom7EventData=[],delete h.dom7EventData}}return this},transitionEnd:function(e){var t=this;return e&&t.on("transitionend",(function i(s){s.target===this&&(e.call(this,s),t.off("transitionend",i))})),this},outerWidth:function(e){if(this.length>0){if(e){var t=this.styles();return this[0].offsetWidth+parseFloat(t.getPropertyValue("margin-right"))+parseFloat(t.getPropertyValue("margin-left"))}return this[0].offsetWidth}return null},outerHeight:function(e){if(this.length>0){if(e){var t=this.styles();return this[0].offsetHeight+parseFloat(t.getPropertyValue("margin-top"))+parseFloat(t.getPropertyValue("margin-bottom"))}return this[0].offsetHeight}return null},styles:function(){var e=o();return this[0]?e.getComputedStyle(this[0],null):{}},offset:function(){if(this.length>0){var e=o(),t=r(),i=this[0],s=i.getBoundingClientRect(),a=t.body,n=i.clientTop||a.clientTop||0,l=i.clientLeft||a.clientLeft||0,d=i===e?e.scrollY:i.scrollTop,h=i===e?e.scrollX:i.scrollLeft;return{top:s.top+d-n,left:s.left+h-l}}return null},css:function(e,t){var i,s=o();if(1===arguments.length){if("string"!=typeof e){for(i=0;i<this.length;i+=1)for(var a in e)this[i].style[a]=e[a];return this}if(this[0])return s.getComputedStyle(this[0],null).getPropertyValue(e)}if(2===arguments.length&&"string"==typeof e){for(i=0;i<this.length;i+=1)this[i].style[e]=t;return this}return this},each:function(e){return e?(this.forEach((function(t,i){e.apply(t,[t,i])})),this):this},html:function(e){if(void 0===e)return this[0]?this[0].innerHTML:null;for(var t=0;t<this.length;t+=1)this[t].innerHTML=e;return this},text:function(e){if(void 0===e)return this[0]?this[0].textContent.trim():null;for(var t=0;t<this.length;t+=1)this[t].textContent=e;return this},is:function(e){var t,i,s=o(),a=r(),n=this[0];if(!n||void 0===e)return!1;if("string"==typeof e){if(n.matches)return n.matches(e);if(n.webkitMatchesSelector)return n.webkitMatchesSelector(e);if(n.msMatchesSelector)return n.msMatchesSelector(e);for(t=m(e),i=0;i<t.length;i+=1)if(t[i]===n)return!0;return!1}if(e===a)return n===a;if(e===s)return n===s;if(e.nodeType||e instanceof c){for(t=e.nodeType?[e]:e,i=0;i<t.length;i+=1)if(t[i]===n)return!0;return!1}return!1},index:function(){var e,t=this[0];if(t){for(e=0;null!==(t=t.previousSibling);)1===t.nodeType&&(e+=1);return e}},eq:function(e){if(void 0===e)return this;var t=this.length;if(e>t-1)return m([]);if(e<0){var i=t+e;return m(i<0?[]:[this[i]])}return m([this[e]])},append:function(){for(var e,t=r(),i=0;i<arguments.length;i+=1){e=i<0||arguments.length<=i?void 0:arguments[i];for(var s=0;s<this.length;s+=1)if("string"==typeof e){var a=t.createElement("div");for(a.innerHTML=e;a.firstChild;)this[s].appendChild(a.firstChild)}else if(e instanceof c)for(var n=0;n<e.length;n+=1)this[s].appendChild(e[n]);else this[s].appendChild(e)}return this},prepend:function(e){var t,i,s=r();for(t=0;t<this.length;t+=1)if("string"==typeof e){var a=s.createElement("div");for(a.innerHTML=e,i=a.childNodes.length-1;i>=0;i-=1)this[t].insertBefore(a.childNodes[i],this[t].childNodes[0])}else if(e instanceof c)for(i=0;i<e.length;i+=1)this[t].insertBefore(e[i],this[t].childNodes[0]);else this[t].insertBefore(e,this[t].childNodes[0]);return this},next:function(e){return this.length>0?e?this[0].nextElementSibling&&m(this[0].nextElementSibling).is(e)?m([this[0].nextElementSibling]):m([]):this[0].nextElementSibling?m([this[0].nextElementSibling]):m([]):m([])},nextAll:function(e){var t=[],i=this[0];if(!i)return m([]);for(;i.nextElementSibling;){var s=i.nextElementSibling;e?m(s).is(e)&&t.push(s):t.push(s),i=s}return m(t)},prev:function(e){if(this.length>0){var t=this[0];return e?t.previousElementSibling&&m(t.previousElementSibling).is(e)?m([t.previousElementSibling]):m([]):t.previousElementSibling?m([t.previousElementSibling]):m([])}return m([])},prevAll:function(e){var t=[],i=this[0];if(!i)return m([]);for(;i.previousElementSibling;){var s=i.previousElementSibling;e?m(s).is(e)&&t.push(s):t.push(s),i=s}return m(t)},parent:function(e){for(var t=[],i=0;i<this.length;i+=1)null!==this[i].parentNode&&(e?m(this[i].parentNode).is(e)&&t.push(this[i].parentNode):t.push(this[i].parentNode));return m(t)},parents:function(e){for(var t=[],i=0;i<this.length;i+=1)for(var s=this[i].parentNode;s;)e?m(s).is(e)&&t.push(s):t.push(s),s=s.parentNode;return m(t)},closest:function(e){var t=this;return void 0===e?m([]):(t.is(e)||(t=t.parents(e).eq(0)),t)},find:function(e){for(var t=[],i=0;i<this.length;i+=1)for(var s=this[i].querySelectorAll(e),a=0;a<s.length;a+=1)t.push(s[a]);return m(t)},children:function(e){for(var t=[],i=0;i<this.length;i+=1)for(var s=this[i].children,a=0;a<s.length;a+=1)e&&!m(s[a]).is(e)||t.push(s[a]);return m(t)},filter:function(e){return m(f(this,e))},remove:function(){for(var e=0;e<this.length;e+=1)this[e].parentNode&&this[e].parentNode.removeChild(this[e]);return this}};function b(e,t){return void 0===t&&(t=0),setTimeout(e,t)}function T(){return Date.now()}function S(e){return"object"==typeof e&&null!==e&&e.constructor&&e.constructor===Object}function x(){for(var e=Object(arguments.length<=0?void 0:arguments[0]),t=1;t<arguments.length;t+=1){var i=t<0||arguments.length<=t?void 0:arguments[t];if(null!=i)for(var s=Object.keys(Object(i)),a=0,r=s.length;a<r;a+=1){var n=s[a],o=Object.getOwnPropertyDescriptor(i,n);void 0!==o&&o.enumerable&&(S(e[n])&&S(i[n])?x(e[n],i[n]):!S(e[n])&&S(i[n])?(e[n]={},x(e[n],i[n])):e[n]=i[n])}}return e}function E(e,t){Object.keys(t).forEach((function(i){S(t[i])&&Object.keys(t[i]).forEach((function(s){"function"==typeof t[i][s]&&(t[i][s]=t[i][s].bind(e))})),e[i]=t[i]}))}function M(){return g||(g=function(){var e=o(),t=r();return{touch:!!("ontouchstart"in e||e.DocumentTouch&&t instanceof e.DocumentTouch),pointerEvents:!!e.PointerEvent&&"maxTouchPoints"in e.navigator&&e.navigator.maxTouchPoints>=0,observer:"MutationObserver"in e||"WebkitMutationObserver"in e,passiveListener:function(){var t=!1;try{var i=Object.defineProperty({},"passive",{get:function(){t=!0}});e.addEventListener("testPassiveListener",null,i)}catch(e){}return t}(),gestures:"ongesturestart"in e}}()),g}function P(e){return void 0===e&&(e={}),y||(y=function(e){var t=(void 0===e?{}:e).userAgent,i=M(),s=o(),a=s.navigator.platform,r=t||s.navigator.userAgent,n={ios:!1,android:!1},l=s.screen.width,d=s.screen.height,h=r.match(/(Android);?[\s\/]+([\d.]+)?/),p=r.match(/(iPad).*OS\s([\d_]+)/),u=r.match(/(iPod)(.*OS\s([\d_]+))?/),c=!p&&r.match(/(iPhone\sOS|iOS)\s([\d_]+)/),v="Win32"===a,f="MacIntel"===a;return!p&&f&&i.touch&&["1024x1366","1366x1024","834x1194","1194x834","834x1112","1112x834","768x1024","1024x768"].indexOf(l+"x"+d)>=0&&((p=r.match(/(Version)\/([\d.]+)/))||(p=[0,1,"13_0_0"]),f=!1),h&&!v&&(n.os="android",n.android=!0),(p||c||u)&&(n.os="ios",n.ios=!0),n}(e)),y}function k(){return C||(C=function(){var e,t=o();return{isEdge:!!t.navigator.userAgent.match(/Edge/g),isSafari:(e=t.navigator.userAgent.toLowerCase(),e.indexOf("safari")>=0&&e.indexOf("chrome")<0&&e.indexOf("android")<0),isWebView:/(iPhone|iPod|iPad).*AppleWebKit(?!.*Safari)/i.test(t.navigator.userAgent)}}()),C}Object.keys(w).forEach((function(e){m.fn[e]=w[e]}));var L={name:"resize",create:function(){var e=this;x(e,{resize:{resizeHandler:function(){e&&!e.destroyed&&e.initialized&&(e.emit("beforeResize"),e.emit("resize"))},orientationChangeHandler:function(){e&&!e.destroyed&&e.initialized&&e.emit("orientationchange")}}})},on:{init:function(e){var t=o();t.addEventListener("resize",e.resize.resizeHandler),t.addEventListener("orientationchange",e.resize.orientationChangeHandler)},destroy:function(e){var t=o();t.removeEventListener("resize",e.resize.resizeHandler),t.removeEventListener("orientationchange",e.resize.orientationChangeHandler)}}},z={attach:function(e,t){void 0===t&&(t={});var i=o(),s=this,a=new(i.MutationObserver||i.WebkitMutationObserver)((function(e){if(1!==e.length){var t=function(){s.emit("observerUpdate",e[0])};i.requestAnimationFrame?i.requestAnimationFrame(t):i.setTimeout(t,0)}else s.emit("observerUpdate",e[0])}));a.observe(e,{attributes:void 0===t.attributes||t.attributes,childList:void 0===t.childList||t.childList,characterData:void 0===t.characterData||t.characterData}),s.observer.observers.push(a)},init:function(){if(this.support.observer&&this.params.observer){if(this.params.observeParents)for(var e=this.$el.parents(),t=0;t<e.length;t+=1)this.observer.attach(e[t]);this.observer.attach(this.$el[0],{childList:this.params.observeSlideChildren}),this.observer.attach(this.$wrapperEl[0],{attributes:!1})}},destroy:function(){this.observer.observers.forEach((function(e){e.disconnect()})),this.observer.observers=[]}},O={name:"observer",params:{observer:!1,observeParents:!1,observeSlideChildren:!1},create:function(){E(this,{observer:t(t({},z),{},{observers:[]})})},on:{init:function(e){e.observer.init()},destroy:function(e){e.observer.destroy()}}};function I(e){var t=r(),i=o(),s=this.touchEventsData,a=this.params,n=this.touches;if(!this.animating||!a.preventInteractionOnTransition){var l=e;l.originalEvent&&(l=l.originalEvent);var d=m(l.target);if(("wrapper"!==a.touchEventsTarget||d.closest(this.wrapperEl).length)&&(s.isTouchEvent="touchstart"===l.type,(s.isTouchEvent||!("which"in l)||3!==l.which)&&!(!s.isTouchEvent&&"button"in l&&l.button>0||s.isTouched&&s.isMoved)))if(a.noSwiping&&d.closest(a.noSwipingSelector?a.noSwipingSelector:"."+a.noSwipingClass)[0])this.allowClick=!0;else if(!a.swipeHandler||d.closest(a.swipeHandler)[0]){n.currentX="touchstart"===l.type?l.targetTouches[0].pageX:l.pageX,n.currentY="touchstart"===l.type?l.targetTouches[0].pageY:l.pageY;var h=n.currentX,p=n.currentY,u=a.edgeSwipeDetection||a.iOSEdgeSwipeDetection,c=a.edgeSwipeThreshold||a.iOSEdgeSwipeThreshold;if(!u||!(h<=c||h>=i.screen.width-c)){if(x(s,{isTouched:!0,isMoved:!1,allowTouchCallbacks:!0,isScrolling:void 0,startMoving:void 0}),n.startX=h,n.startY=p,s.touchStartTime=T(),this.allowClick=!0,this.updateSize(),this.swipeDirection=void 0,a.threshold>0&&(s.allowThresholdMove=!1),"touchstart"!==l.type){var v=!0;d.is(s.formElements)&&(v=!1),t.activeElement&&m(t.activeElement).is(s.formElements)&&t.activeElement!==d[0]&&t.activeElement.blur();var f=v&&this.allowTouchMove&&a.touchStartPreventDefault;(a.touchStartForcePreventDefault||f)&&l.preventDefault()}this.emit("touchStart",l)}}}}function A(e){var t=r(),i=this.touchEventsData,s=this.params,a=this.touches,n=this.rtlTranslate,o=e;if(o.originalEvent&&(o=o.originalEvent),i.isTouched){if(!i.isTouchEvent||"touchmove"===o.type){var l="touchmove"===o.type&&o.targetTouches&&(o.targetTouches[0]||o.changedTouches[0]),d="touchmove"===o.type?l.pageX:o.pageX,h="touchmove"===o.type?l.pageY:o.pageY;if(o.preventedByNestedSwiper)return a.startX=d,void(a.startY=h);if(!this.allowTouchMove)return this.allowClick=!1,void(i.isTouched&&(x(a,{startX:d,startY:h,currentX:d,currentY:h}),i.touchStartTime=T()));if(i.isTouchEvent&&s.touchReleaseOnEdges&&!s.loop)if(this.isVertical()){if(h<a.startY&&this.translate<=this.maxTranslate()||h>a.startY&&this.translate>=this.minTranslate())return i.isTouched=!1,void(i.isMoved=!1)}else if(d<a.startX&&this.translate<=this.maxTranslate()||d>a.startX&&this.translate>=this.minTranslate())return;if(i.isTouchEvent&&t.activeElement&&o.target===t.activeElement&&m(o.target).is(i.formElements))return i.isMoved=!0,void(this.allowClick=!1);if(i.allowTouchCallbacks&&this.emit("touchMove",o),!(o.targetTouches&&o.targetTouches.length>1)){a.currentX=d,a.currentY=h;var p=a.currentX-a.startX,u=a.currentY-a.startY;if(!(this.params.threshold&&Math.sqrt(Math.pow(p,2)+Math.pow(u,2))<this.params.threshold)){var c;if(void 0===i.isScrolling)this.isHorizontal()&&a.currentY===a.startY||this.isVertical()&&a.currentX===a.startX?i.isScrolling=!1:p*p+u*u>=25&&(c=180*Math.atan2(Math.abs(u),Math.abs(p))/Math.PI,i.isScrolling=this.isHorizontal()?c>s.touchAngle:90-c>s.touchAngle);if(i.isScrolling&&this.emit("touchMoveOpposite",o),void 0===i.startMoving&&(a.currentX===a.startX&&a.currentY===a.startY||(i.startMoving=!0)),i.isScrolling)i.isTouched=!1;else if(i.startMoving){this.allowClick=!1,!s.cssMode&&o.cancelable&&o.preventDefault(),s.touchMoveStopPropagation&&!s.nested&&o.stopPropagation(),i.isMoved||(s.loop&&this.loopFix(),i.startTranslate=this.getTranslate(),this.setTransition(0),this.animating&&this.$wrapperEl.trigger("webkitTransitionEnd transitionend"),i.allowMomentumBounce=!1,!s.grabCursor||!0!==this.allowSlideNext&&!0!==this.allowSlidePrev||this.setGrabCursor(!0),this.emit("sliderFirstMove",o)),this.emit("sliderMove",o),i.isMoved=!0;var v=this.isHorizontal()?p:u;a.diff=v,v*=s.touchRatio,n&&(v=-v),this.swipeDirection=v>0?"prev":"next",i.currentTranslate=v+i.startTranslate;var f=!0,g=s.resistanceRatio;if(s.touchReleaseOnEdges&&(g=0),v>0&&i.currentTranslate>this.minTranslate()?(f=!1,s.resistance&&(i.currentTranslate=this.minTranslate()-1+Math.pow(-this.minTranslate()+i.startTranslate+v,g))):v<0&&i.currentTranslate<this.maxTranslate()&&(f=!1,s.resistance&&(i.currentTranslate=this.maxTranslate()+1-Math.pow(this.maxTranslate()-i.startTranslate-v,g))),f&&(o.preventedByNestedSwiper=!0),!this.allowSlideNext&&"next"===this.swipeDirection&&i.currentTranslate<i.startTranslate&&(i.currentTranslate=i.startTranslate),!this.allowSlidePrev&&"prev"===this.swipeDirection&&i.currentTranslate>i.startTranslate&&(i.currentTranslate=i.startTranslate),s.threshold>0){if(!(Math.abs(v)>s.threshold||i.allowThresholdMove))return void(i.currentTranslate=i.startTranslate);if(!i.allowThresholdMove)return i.allowThresholdMove=!0,a.startX=a.currentX,a.startY=a.currentY,i.currentTranslate=i.startTranslate,void(a.diff=this.isHorizontal()?a.currentX-a.startX:a.currentY-a.startY)}s.followFinger&&!s.cssMode&&((s.freeMode||s.watchSlidesProgress||s.watchSlidesVisibility)&&(this.updateActiveIndex(),this.updateSlidesClasses()),s.freeMode&&(0===i.velocities.length&&i.velocities.push({position:a[this.isHorizontal()?"startX":"startY"],time:i.touchStartTime}),i.velocities.push({position:a[this.isHorizontal()?"currentX":"currentY"],time:T()})),this.updateProgress(i.currentTranslate),this.setTranslate(i.currentTranslate))}}}}}else i.startMoving&&i.isScrolling&&this.emit("touchMoveOpposite",o)}function B(e){var t=this,i=t.touchEventsData,s=t.params,a=t.touches,r=t.rtlTranslate,n=t.$wrapperEl,o=t.slidesGrid,l=t.snapGrid,d=e;if(d.originalEvent&&(d=d.originalEvent),i.allowTouchCallbacks&&t.emit("touchEnd",d),i.allowTouchCallbacks=!1,!i.isTouched)return i.isMoved&&s.grabCursor&&t.setGrabCursor(!1),i.isMoved=!1,void(i.startMoving=!1);s.grabCursor&&i.isMoved&&i.isTouched&&(!0===t.allowSlideNext||!0===t.allowSlidePrev)&&t.setGrabCursor(!1);var h,p=T(),u=p-i.touchStartTime;if(t.allowClick&&(t.updateClickedSlide(d),t.emit("tap click",d),u<300&&p-i.lastClickTime<300&&t.emit("doubleTap doubleClick",d)),i.lastClickTime=T(),b((function(){t.destroyed||(t.allowClick=!0)})),!i.isTouched||!i.isMoved||!t.swipeDirection||0===a.diff||i.currentTranslate===i.startTranslate)return i.isTouched=!1,i.isMoved=!1,void(i.startMoving=!1);if(i.isTouched=!1,i.isMoved=!1,i.startMoving=!1,h=s.followFinger?r?t.translate:-t.translate:-i.currentTranslate,!s.cssMode)if(s.freeMode){if(h<-t.minTranslate())return void t.slideTo(t.activeIndex);if(h>-t.maxTranslate())return void(t.slides.length<l.length?t.slideTo(l.length-1):t.slideTo(t.slides.length-1));if(s.freeModeMomentum){if(i.velocities.length>1){var c=i.velocities.pop(),v=i.velocities.pop(),f=c.position-v.position,m=c.time-v.time;t.velocity=f/m,t.velocity/=2,Math.abs(t.velocity)<s.freeModeMinimumVelocity&&(t.velocity=0),(m>150||T()-c.time>300)&&(t.velocity=0)}else t.velocity=0;t.velocity*=s.freeModeMomentumVelocityRatio,i.velocities.length=0;var g=1e3*s.freeModeMomentumRatio,y=t.velocity*g,C=t.translate+y;r&&(C=-C);var w,S,x=!1,E=20*Math.abs(t.velocity)*s.freeModeMomentumBounceRatio;if(C<t.maxTranslate())s.freeModeMomentumBounce?(C+t.maxTranslate()<-E&&(C=t.maxTranslate()-E),w=t.maxTranslate(),x=!0,i.allowMomentumBounce=!0):C=t.maxTranslate(),s.loop&&s.centeredSlides&&(S=!0);else if(C>t.minTranslate())s.freeModeMomentumBounce?(C-t.minTranslate()>E&&(C=t.minTranslate()+E),w=t.minTranslate(),x=!0,i.allowMomentumBounce=!0):C=t.minTranslate(),s.loop&&s.centeredSlides&&(S=!0);else if(s.freeModeSticky){for(var M,P=0;P<l.length;P+=1)if(l[P]>-C){M=P;break}C=-(C=Math.abs(l[M]-C)<Math.abs(l[M-1]-C)||"next"===t.swipeDirection?l[M]:l[M-1])}if(S&&t.once("transitionEnd",(function(){t.loopFix()})),0!==t.velocity){if(g=r?Math.abs((-C-t.translate)/t.velocity):Math.abs((C-t.translate)/t.velocity),s.freeModeSticky){var k=Math.abs((r?-C:C)-t.translate),L=t.slidesSizesGrid[t.activeIndex];g=k<L?s.speed:k<2*L?1.5*s.speed:2.5*s.speed}}else if(s.freeModeSticky)return void t.slideToClosest();s.freeModeMomentumBounce&&x?(t.updateProgress(w),t.setTransition(g),t.setTranslate(C),t.transitionStart(!0,t.swipeDirection),t.animating=!0,n.transitionEnd((function(){t&&!t.destroyed&&i.allowMomentumBounce&&(t.emit("momentumBounce"),t.setTransition(s.speed),setTimeout((function(){t.setTranslate(w),n.transitionEnd((function(){t&&!t.destroyed&&t.transitionEnd()}))}),0))}))):t.velocity?(t.updateProgress(C),t.setTransition(g),t.setTranslate(C),t.transitionStart(!0,t.swipeDirection),t.animating||(t.animating=!0,n.transitionEnd((function(){t&&!t.destroyed&&t.transitionEnd()})))):t.updateProgress(C),t.updateActiveIndex(),t.updateSlidesClasses()}else if(s.freeModeSticky)return void t.slideToClosest();(!s.freeModeMomentum||u>=s.longSwipesMs)&&(t.updateProgress(),t.updateActiveIndex(),t.updateSlidesClasses())}else{for(var z=0,O=t.slidesSizesGrid[0],I=0;I<o.length;I+=I<s.slidesPerGroupSkip?1:s.slidesPerGroup){var A=I<s.slidesPerGroupSkip-1?1:s.slidesPerGroup;void 0!==o[I+A]?h>=o[I]&&h<o[I+A]&&(z=I,O=o[I+A]-o[I]):h>=o[I]&&(z=I,O=o[o.length-1]-o[o.length-2])}var B=(h-o[z])/O,D=z<s.slidesPerGroupSkip-1?1:s.slidesPerGroup;if(u>s.longSwipesMs){if(!s.longSwipes)return void t.slideTo(t.activeIndex);"next"===t.swipeDirection&&(B>=s.longSwipesRatio?t.slideTo(z+D):t.slideTo(z)),"prev"===t.swipeDirection&&(B>1-s.longSwipesRatio?t.slideTo(z+D):t.slideTo(z))}else{if(!s.shortSwipes)return void t.slideTo(t.activeIndex);t.navigation&&(d.target===t.navigation.nextEl||d.target===t.navigation.prevEl)?d.target===t.navigation.nextEl?t.slideTo(z+D):t.slideTo(z):("next"===t.swipeDirection&&t.slideTo(z+D),"prev"===t.swipeDirection&&t.slideTo(z))}}}function D(){var e=this.params,t=this.el;if(!t||0!==t.offsetWidth){e.breakpoints&&this.setBreakpoint();var i=this.allowSlideNext,s=this.allowSlidePrev,a=this.snapGrid;this.allowSlideNext=!0,this.allowSlidePrev=!0,this.updateSize(),this.updateSlides(),this.updateSlidesClasses(),("auto"===e.slidesPerView||e.slidesPerView>1)&&this.isEnd&&!this.isBeginning&&!this.params.centeredSlides?this.slideTo(this.slides.length-1,0,!1,!0):this.slideTo(this.activeIndex,0,!1,!0),this.autoplay&&this.autoplay.running&&this.autoplay.paused&&this.autoplay.run(),this.allowSlidePrev=s,this.allowSlideNext=i,this.params.watchOverflow&&a!==this.snapGrid&&this.checkOverflow()}}function G(e){this.allowClick||(this.params.preventClicks&&e.preventDefault(),this.params.preventClicksPropagation&&this.animating&&(e.stopPropagation(),e.stopImmediatePropagation()))}function N(){var e=this.wrapperEl,t=this.rtlTranslate;this.previousTranslate=this.translate,this.isHorizontal()?this.translate=t?e.scrollWidth-e.offsetWidth-e.scrollLeft:-e.scrollLeft:this.translate=-e.scrollTop,-0===this.translate&&(this.translate=0),this.updateActiveIndex(),this.updateSlidesClasses();var i=this.maxTranslate()-this.minTranslate();(0===i?0:(this.translate-this.minTranslate())/i)!==this.progress&&this.updateProgress(t?-this.translate:this.translate),this.emit("setTranslate",this.translate,!1)}var $=!1;function F(){}var V={init:!0,direction:"horizontal",touchEventsTarget:"container",initialSlide:0,speed:300,cssMode:!1,updateOnWindowResize:!0,width:null,height:null,preventInteractionOnTransition:!1,userAgent:null,url:null,edgeSwipeDetection:!1,edgeSwipeThreshold:20,freeMode:!1,freeModeMomentum:!0,freeModeMomentumRatio:1,freeModeMomentumBounce:!0,freeModeMomentumBounceRatio:1,freeModeMomentumVelocityRatio:1,freeModeSticky:!1,freeModeMinimumVelocity:.02,autoHeight:!1,setWrapperSize:!1,virtualTranslate:!1,effect:"slide",breakpoints:void 0,spaceBetween:0,slidesPerView:1,slidesPerColumn:1,slidesPerColumnFill:"column",slidesPerGroup:1,slidesPerGroupSkip:0,centeredSlides:!1,centeredSlidesBounds:!1,slidesOffsetBefore:0,slidesOffsetAfter:0,normalizeSlideIndex:!0,centerInsufficientSlides:!1,watchOverflow:!1,roundLengths:!1,touchRatio:1,touchAngle:45,simulateTouch:!0,shortSwipes:!0,longSwipes:!0,longSwipesRatio:.5,longSwipesMs:300,followFinger:!0,allowTouchMove:!0,threshold:0,touchMoveStopPropagation:!1,touchStartPreventDefault:!0,touchStartForcePreventDefault:!1,touchReleaseOnEdges:!1,uniqueNavElements:!0,resistance:!0,resistanceRatio:.85,watchSlidesProgress:!1,watchSlidesVisibility:!1,grabCursor:!1,preventClicks:!0,preventClicksPropagation:!0,slideToClickedSlide:!1,preloadImages:!0,updateOnImagesReady:!0,loop:!1,loopAdditionalSlides:0,loopedSlides:null,loopFillGroupWithBlank:!1,loopPreventsSlide:!0,allowSlidePrev:!0,allowSlideNext:!0,swipeHandler:null,noSwiping:!0,noSwipingClass:"swiper-no-swiping",noSwipingSelector:null,passiveListeners:!0,containerModifierClass:"swiper-container-",slideClass:"swiper-slide",slideBlankClass:"swiper-slide-invisible-blank",slideActiveClass:"swiper-slide-active",slideDuplicateActiveClass:"swiper-slide-duplicate-active",slideVisibleClass:"swiper-slide-visible",slideDuplicateClass:"swiper-slide-duplicate",slideNextClass:"swiper-slide-next",slideDuplicateNextClass:"swiper-slide-duplicate-next",slidePrevClass:"swiper-slide-prev",slideDuplicatePrevClass:"swiper-slide-duplicate-prev",wrapperClass:"swiper-wrapper",runCallbacksOnInit:!0,_emitClasses:!1},H={modular:{useParams:function(e){var t=this;t.modules&&Object.keys(t.modules).forEach((function(i){var s=t.modules[i];s.params&&x(e,s.params)}))},useModules:function(e){void 0===e&&(e={});var t=this;t.modules&&Object.keys(t.modules).forEach((function(i){var s=t.modules[i],a=e[i]||{};s.on&&t.on&&Object.keys(s.on).forEach((function(e){t.on(e,s.on[e])})),s.create&&s.create.bind(t)(a)}))}},eventsEmitter:{on:function(e,t,i){var s=this;if("function"!=typeof t)return s;var a=i?"unshift":"push";return e.split(" ").forEach((function(e){s.eventsListeners[e]||(s.eventsListeners[e]=[]),s.eventsListeners[e][a](t)})),s},once:function(e,t,i){var s=this;if("function"!=typeof t)return s;function a(){s.off(e,a),a.__emitterProxy&&delete a.__emitterProxy;for(var i=arguments.length,r=new Array(i),n=0;n<i;n++)r[n]=arguments[n];t.apply(s,r)}return a.__emitterProxy=t,s.on(e,a,i)},onAny:function(e,t){if("function"!=typeof e)return this;var i=t?"unshift":"push";return this.eventsAnyListeners.indexOf(e)<0&&this.eventsAnyListeners[i](e),this},offAny:function(e){if(!this.eventsAnyListeners)return this;var t=this.eventsAnyListeners.indexOf(e);return t>=0&&this.eventsAnyListeners.splice(t,1),this},off:function(e,t){var i=this;return i.eventsListeners?(e.split(" ").forEach((function(e){void 0===t?i.eventsListeners[e]=[]:i.eventsListeners[e]&&i.eventsListeners[e].forEach((function(s,a){(s===t||s.__emitterProxy&&s.__emitterProxy===t)&&i.eventsListeners[e].splice(a,1)}))})),i):i},emit:function(){var e,t,i,s=this;if(!s.eventsListeners)return s;for(var a=arguments.length,r=new Array(a),n=0;n<a;n++)r[n]=arguments[n];"string"==typeof r[0]||Array.isArray(r[0])?(e=r[0],t=r.slice(1,r.length),i=s):(e=r[0].events,t=r[0].data,i=r[0].context||s),t.unshift(i);var o=Array.isArray(e)?e:e.split(" ");return o.forEach((function(e){if(s.eventsAnyListeners&&s.eventsAnyListeners.length&&s.eventsAnyListeners.forEach((function(s){s.apply(i,[e].concat(t))})),s.eventsListeners&&s.eventsListeners[e]){var a=[];s.eventsListeners[e].forEach((function(e){a.push(e)})),a.forEach((function(e){e.apply(i,t)}))}})),s}},update:{updateSize:function(){var e,t,i=this.$el;e=void 0!==this.params.width&&null!==this.params.width?this.params.width:i[0].clientWidth,t=void 0!==this.params.height&&null!==this.params.width?this.params.height:i[0].clientHeight,0===e&&this.isHorizontal()||0===t&&this.isVertical()||(e=e-parseInt(i.css("padding-left")||0,10)-parseInt(i.css("padding-right")||0,10),t=t-parseInt(i.css("padding-top")||0,10)-parseInt(i.css("padding-bottom")||0,10),Number.isNaN(e)&&(e=0),Number.isNaN(t)&&(t=0),x(this,{width:e,height:t,size:this.isHorizontal()?e:t}))},updateSlides:function(){var e=o(),t=this.params,i=this.$wrapperEl,s=this.size,a=this.rtlTranslate,r=this.wrongRTL,n=this.virtual&&t.virtual.enabled,l=n?this.virtual.slides.length:this.slides.length,d=i.children("."+this.params.slideClass),h=n?this.virtual.slides.length:d.length,p=[],u=[],c=[];function v(e,i){return!t.cssMode||i!==d.length-1}var f=t.slidesOffsetBefore;"function"==typeof f&&(f=t.slidesOffsetBefore.call(this));var m=t.slidesOffsetAfter;"function"==typeof m&&(m=t.slidesOffsetAfter.call(this));var g=this.snapGrid.length,y=this.snapGrid.length,C=t.spaceBetween,w=-f,b=0,T=0;if(void 0!==s){var S,E;"string"==typeof C&&C.indexOf("%")>=0&&(C=parseFloat(C.replace("%",""))/100*s),this.virtualSize=-C,a?d.css({marginLeft:"",marginTop:""}):d.css({marginRight:"",marginBottom:""}),t.slidesPerColumn>1&&(S=Math.floor(h/t.slidesPerColumn)===h/this.params.slidesPerColumn?h:Math.ceil(h/t.slidesPerColumn)*t.slidesPerColumn,"auto"!==t.slidesPerView&&"row"===t.slidesPerColumnFill&&(S=Math.max(S,t.slidesPerView*t.slidesPerColumn)));for(var M,P=t.slidesPerColumn,k=S/P,L=Math.floor(h/t.slidesPerColumn),z=0;z<h;z+=1){E=0;var O=d.eq(z);if(t.slidesPerColumn>1){var I=void 0,A=void 0,B=void 0;if("row"===t.slidesPerColumnFill&&t.slidesPerGroup>1){var D=Math.floor(z/(t.slidesPerGroup*t.slidesPerColumn)),G=z-t.slidesPerColumn*t.slidesPerGroup*D,N=0===D?t.slidesPerGroup:Math.min(Math.ceil((h-D*P*t.slidesPerGroup)/P),t.slidesPerGroup);I=(A=G-(B=Math.floor(G/N))*N+D*t.slidesPerGroup)+B*S/P,O.css({"-webkit-box-ordinal-group":I,"-moz-box-ordinal-group":I,"-ms-flex-order":I,"-webkit-order":I,order:I})}else"column"===t.slidesPerColumnFill?(B=z-(A=Math.floor(z/P))*P,(A>L||A===L&&B===P-1)&&(B+=1)>=P&&(B=0,A+=1)):A=z-(B=Math.floor(z/k))*k;O.css("margin-"+(this.isHorizontal()?"top":"left"),0!==B&&t.spaceBetween&&t.spaceBetween+"px")}if("none"!==O.css("display")){if("auto"===t.slidesPerView){var $=e.getComputedStyle(O[0],null),F=O[0].style.transform,V=O[0].style.webkitTransform;if(F&&(O[0].style.transform="none"),V&&(O[0].style.webkitTransform="none"),t.roundLengths)E=this.isHorizontal()?O.outerWidth(!0):O.outerHeight(!0);else if(this.isHorizontal()){var H=parseFloat($.getPropertyValue("width")||0),j=parseFloat($.getPropertyValue("padding-left")||0),_=parseFloat($.getPropertyValue("padding-right")||0),W=parseFloat($.getPropertyValue("margin-left")||0),R=parseFloat($.getPropertyValue("margin-right")||0),q=$.getPropertyValue("box-sizing");E=q&&"border-box"===q?H+W+R:H+j+_+W+R}else{var X=parseFloat($.getPropertyValue("height")||0),Y=parseFloat($.getPropertyValue("padding-top")||0),U=parseFloat($.getPropertyValue("padding-bottom")||0),K=parseFloat($.getPropertyValue("margin-top")||0),J=parseFloat($.getPropertyValue("margin-bottom")||0),Q=$.getPropertyValue("box-sizing");E=Q&&"border-box"===Q?X+K+J:X+Y+U+K+J}F&&(O[0].style.transform=F),V&&(O[0].style.webkitTransform=V),t.roundLengths&&(E=Math.floor(E))}else E=(s-(t.slidesPerView-1)*C)/t.slidesPerView,t.roundLengths&&(E=Math.floor(E)),d[z]&&(this.isHorizontal()?d[z].style.width=E+"px":d[z].style.height=E+"px");d[z]&&(d[z].swiperSlideSize=E),c.push(E),t.centeredSlides?(w=w+E/2+b/2+C,0===b&&0!==z&&(w=w-s/2-C),0===z&&(w=w-s/2-C),Math.abs(w)<.001&&(w=0),t.roundLengths&&(w=Math.floor(w)),T%t.slidesPerGroup==0&&p.push(w),u.push(w)):(t.roundLengths&&(w=Math.floor(w)),(T-Math.min(this.params.slidesPerGroupSkip,T))%this.params.slidesPerGroup==0&&p.push(w),u.push(w),w=w+E+C),this.virtualSize+=E+C,b=E,T+=1}}if(this.virtualSize=Math.max(this.virtualSize,s)+m,a&&r&&("slide"===t.effect||"coverflow"===t.effect)&&i.css({width:this.virtualSize+t.spaceBetween+"px"}),t.setWrapperSize&&(this.isHorizontal()?i.css({width:this.virtualSize+t.spaceBetween+"px"}):i.css({height:this.virtualSize+t.spaceBetween+"px"})),t.slidesPerColumn>1&&(this.virtualSize=(E+t.spaceBetween)*S,this.virtualSize=Math.ceil(this.virtualSize/t.slidesPerColumn)-t.spaceBetween,this.isHorizontal()?i.css({width:this.virtualSize+t.spaceBetween+"px"}):i.css({height:this.virtualSize+t.spaceBetween+"px"}),t.centeredSlides)){M=[];for(var Z=0;Z<p.length;Z+=1){var ee=p[Z];t.roundLengths&&(ee=Math.floor(ee)),p[Z]<this.virtualSize+p[0]&&M.push(ee)}p=M}if(!t.centeredSlides){M=[];for(var te=0;te<p.length;te+=1){var ie=p[te];t.roundLengths&&(ie=Math.floor(ie)),p[te]<=this.virtualSize-s&&M.push(ie)}p=M,Math.floor(this.virtualSize-s)-Math.floor(p[p.length-1])>1&&p.push(this.virtualSize-s)}if(0===p.length&&(p=[0]),0!==t.spaceBetween&&(this.isHorizontal()?a?d.filter(v).css({marginLeft:C+"px"}):d.filter(v).css({marginRight:C+"px"}):d.filter(v).css({marginBottom:C+"px"})),t.centeredSlides&&t.centeredSlidesBounds){var se=0;c.forEach((function(e){se+=e+(t.spaceBetween?t.spaceBetween:0)}));var ae=(se-=t.spaceBetween)-s;p=p.map((function(e){return e<0?-f:e>ae?ae+m:e}))}if(t.centerInsufficientSlides){var re=0;if(c.forEach((function(e){re+=e+(t.spaceBetween?t.spaceBetween:0)})),(re-=t.spaceBetween)<s){var ne=(s-re)/2;p.forEach((function(e,t){p[t]=e-ne})),u.forEach((function(e,t){u[t]=e+ne}))}}x(this,{slides:d,snapGrid:p,slidesGrid:u,slidesSizesGrid:c}),h!==l&&this.emit("slidesLengthChange"),p.length!==g&&(this.params.watchOverflow&&this.checkOverflow(),this.emit("snapGridLengthChange")),u.length!==y&&this.emit("slidesGridLengthChange"),(t.watchSlidesProgress||t.watchSlidesVisibility)&&this.updateSlidesOffset()}},updateAutoHeight:function(e){var t,i=[],s=0;if("number"==typeof e?this.setTransition(e):!0===e&&this.setTransition(this.params.speed),"auto"!==this.params.slidesPerView&&this.params.slidesPerView>1)if(this.params.centeredSlides)this.visibleSlides.each((function(e){i.push(e)}));else for(t=0;t<Math.ceil(this.params.slidesPerView);t+=1){var a=this.activeIndex+t;if(a>this.slides.length)break;i.push(this.slides.eq(a)[0])}else i.push(this.slides.eq(this.activeIndex)[0]);for(t=0;t<i.length;t+=1)if(void 0!==i[t]){var r=i[t].offsetHeight;s=r>s?r:s}s&&this.$wrapperEl.css("height",s+"px")},updateSlidesOffset:function(){for(var e=this.slides,t=0;t<e.length;t+=1)e[t].swiperSlideOffset=this.isHorizontal()?e[t].offsetLeft:e[t].offsetTop},updateSlidesProgress:function(e){void 0===e&&(e=this&&this.translate||0);var t=this.params,i=this.slides,s=this.rtlTranslate;if(0!==i.length){void 0===i[0].swiperSlideOffset&&this.updateSlidesOffset();var a=-e;s&&(a=e),i.removeClass(t.slideVisibleClass),this.visibleSlidesIndexes=[],this.visibleSlides=[];for(var r=0;r<i.length;r+=1){var n=i[r],o=(a+(t.centeredSlides?this.minTranslate():0)-n.swiperSlideOffset)/(n.swiperSlideSize+t.spaceBetween);if(t.watchSlidesVisibility||t.centeredSlides&&t.autoHeight){var l=-(a-n.swiperSlideOffset),d=l+this.slidesSizesGrid[r];(l>=0&&l<this.size-1||d>1&&d<=this.size||l<=0&&d>=this.size)&&(this.visibleSlides.push(n),this.visibleSlidesIndexes.push(r),i.eq(r).addClass(t.slideVisibleClass))}n.progress=s?-o:o}this.visibleSlides=m(this.visibleSlides)}},updateProgress:function(e){if(void 0===e){var t=this.rtlTranslate?-1:1;e=this&&this.translate&&this.translate*t||0}var i=this.params,s=this.maxTranslate()-this.minTranslate(),a=this.progress,r=this.isBeginning,n=this.isEnd,o=r,l=n;0===s?(a=0,r=!0,n=!0):(r=(a=(e-this.minTranslate())/s)<=0,n=a>=1),x(this,{progress:a,isBeginning:r,isEnd:n}),(i.watchSlidesProgress||i.watchSlidesVisibility||i.centeredSlides&&i.autoHeight)&&this.updateSlidesProgress(e),r&&!o&&this.emit("reachBeginning toEdge"),n&&!l&&this.emit("reachEnd toEdge"),(o&&!r||l&&!n)&&this.emit("fromEdge"),this.emit("progress",a)},updateSlidesClasses:function(){var e,t=this.slides,i=this.params,s=this.$wrapperEl,a=this.activeIndex,r=this.realIndex,n=this.virtual&&i.virtual.enabled;t.removeClass(i.slideActiveClass+" "+i.slideNextClass+" "+i.slidePrevClass+" "+i.slideDuplicateActiveClass+" "+i.slideDuplicateNextClass+" "+i.slideDuplicatePrevClass),(e=n?this.$wrapperEl.find("."+i.slideClass+'[data-swiper-slide-index="'+a+'"]'):t.eq(a)).addClass(i.slideActiveClass),i.loop&&(e.hasClass(i.slideDuplicateClass)?s.children("."+i.slideClass+":not(."+i.slideDuplicateClass+')[data-swiper-slide-index="'+r+'"]').addClass(i.slideDuplicateActiveClass):s.children("."+i.slideClass+"."+i.slideDuplicateClass+'[data-swiper-slide-index="'+r+'"]').addClass(i.slideDuplicateActiveClass));var o=e.nextAll("."+i.slideClass).eq(0).addClass(i.slideNextClass);i.loop&&0===o.length&&(o=t.eq(0)).addClass(i.slideNextClass);var l=e.prevAll("."+i.slideClass).eq(0).addClass(i.slidePrevClass);i.loop&&0===l.length&&(l=t.eq(-1)).addClass(i.slidePrevClass),i.loop&&(o.hasClass(i.slideDuplicateClass)?s.children("."+i.slideClass+":not(."+i.slideDuplicateClass+')[data-swiper-slide-index="'+o.attr("data-swiper-slide-index")+'"]').addClass(i.slideDuplicateNextClass):s.children("."+i.slideClass+"."+i.slideDuplicateClass+'[data-swiper-slide-index="'+o.attr("data-swiper-slide-index")+'"]').addClass(i.slideDuplicateNextClass),l.hasClass(i.slideDuplicateClass)?s.children("."+i.slideClass+":not(."+i.slideDuplicateClass+')[data-swiper-slide-index="'+l.attr("data-swiper-slide-index")+'"]').addClass(i.slideDuplicatePrevClass):s.children("."+i.slideClass+"."+i.slideDuplicateClass+'[data-swiper-slide-index="'+l.attr("data-swiper-slide-index")+'"]').addClass(i.slideDuplicatePrevClass)),this.emitSlidesClasses()},updateActiveIndex:function(e){var t,i=this.rtlTranslate?this.translate:-this.translate,s=this.slidesGrid,a=this.snapGrid,r=this.params,n=this.activeIndex,o=this.realIndex,l=this.snapIndex,d=e;if(void 0===d){for(var h=0;h<s.length;h+=1)void 0!==s[h+1]?i>=s[h]&&i<s[h+1]-(s[h+1]-s[h])/2?d=h:i>=s[h]&&i<s[h+1]&&(d=h+1):i>=s[h]&&(d=h);r.normalizeSlideIndex&&(d<0||void 0===d)&&(d=0)}if(a.indexOf(i)>=0)t=a.indexOf(i);else{var p=Math.min(r.slidesPerGroupSkip,d);t=p+Math.floor((d-p)/r.slidesPerGroup)}if(t>=a.length&&(t=a.length-1),d!==n){var u=parseInt(this.slides.eq(d).attr("data-swiper-slide-index")||d,10);x(this,{snapIndex:t,realIndex:u,previousIndex:n,activeIndex:d}),this.emit("activeIndexChange"),this.emit("snapIndexChange"),o!==u&&this.emit("realIndexChange"),(this.initialized||this.params.runCallbacksOnInit)&&this.emit("slideChange")}else t!==l&&(this.snapIndex=t,this.emit("snapIndexChange"))},updateClickedSlide:function(e){var t=this.params,i=m(e.target).closest("."+t.slideClass)[0],s=!1;if(i)for(var a=0;a<this.slides.length;a+=1)this.slides[a]===i&&(s=!0);if(!i||!s)return this.clickedSlide=void 0,void(this.clickedIndex=void 0);this.clickedSlide=i,this.virtual&&this.params.virtual.enabled?this.clickedIndex=parseInt(m(i).attr("data-swiper-slide-index"),10):this.clickedIndex=m(i).index(),t.slideToClickedSlide&&void 0!==this.clickedIndex&&this.clickedIndex!==this.activeIndex&&this.slideToClickedSlide()}},translate:{getTranslate:function(e){void 0===e&&(e=this.isHorizontal()?"x":"y");var t=this.params,i=this.rtlTranslate,s=this.translate,a=this.$wrapperEl;if(t.virtualTranslate)return i?-s:s;if(t.cssMode)return s;var r=function(e,t){void 0===t&&(t="x");var i,s,a,r=o(),n=r.getComputedStyle(e,null);return r.WebKitCSSMatrix?((s=n.transform||n.webkitTransform).split(",").length>6&&(s=s.split(", ").map((function(e){return e.replace(",",".")})).join(", ")),a=new r.WebKitCSSMatrix("none"===s?"":s)):i=(a=n.MozTransform||n.OTransform||n.MsTransform||n.msTransform||n.transform||n.getPropertyValue("transform").replace("translate(","matrix(1, 0, 0, 1,")).toString().split(","),"x"===t&&(s=r.WebKitCSSMatrix?a.m41:16===i.length?parseFloat(i[12]):parseFloat(i[4])),"y"===t&&(s=r.WebKitCSSMatrix?a.m42:16===i.length?parseFloat(i[13]):parseFloat(i[5])),s||0}(a[0],e);return i&&(r=-r),r||0},setTranslate:function(e,t){var i=this.rtlTranslate,s=this.params,a=this.$wrapperEl,r=this.wrapperEl,n=this.progress,o=0,l=0;this.isHorizontal()?o=i?-e:e:l=e,s.roundLengths&&(o=Math.floor(o),l=Math.floor(l)),s.cssMode?r[this.isHorizontal()?"scrollLeft":"scrollTop"]=this.isHorizontal()?-o:-l:s.virtualTranslate||a.transform("translate3d("+o+"px, "+l+"px, 0px)"),this.previousTranslate=this.translate,this.translate=this.isHorizontal()?o:l;var d=this.maxTranslate()-this.minTranslate();(0===d?0:(e-this.minTranslate())/d)!==n&&this.updateProgress(e),this.emit("setTranslate",this.translate,t)},minTranslate:function(){return-this.snapGrid[0]},maxTranslate:function(){return-this.snapGrid[this.snapGrid.length-1]},translateTo:function(e,t,i,s,a){void 0===e&&(e=0),void 0===t&&(t=this.params.speed),void 0===i&&(i=!0),void 0===s&&(s=!0);var r=this,n=r.params,o=r.wrapperEl;if(r.animating&&n.preventInteractionOnTransition)return!1;var l,d=r.minTranslate(),h=r.maxTranslate();if(l=s&&e>d?d:s&&e<h?h:e,r.updateProgress(l),n.cssMode){var p,u=r.isHorizontal();if(0===t)o[u?"scrollLeft":"scrollTop"]=-l;else if(o.scrollTo)o.scrollTo(((p={})[u?"left":"top"]=-l,p.behavior="smooth",p));else o[u?"scrollLeft":"scrollTop"]=-l;return!0}return 0===t?(r.setTransition(0),r.setTranslate(l),i&&(r.emit("beforeTransitionStart",t,a),r.emit("transitionEnd"))):(r.setTransition(t),r.setTranslate(l),i&&(r.emit("beforeTransitionStart",t,a),r.emit("transitionStart")),r.animating||(r.animating=!0,r.onTranslateToWrapperTransitionEnd||(r.onTranslateToWrapperTransitionEnd=function(e){r&&!r.destroyed&&e.target===this&&(r.$wrapperEl[0].removeEventListener("transitionend",r.onTranslateToWrapperTransitionEnd),r.$wrapperEl[0].removeEventListener("webkitTransitionEnd",r.onTranslateToWrapperTransitionEnd),r.onTranslateToWrapperTransitionEnd=null,delete r.onTranslateToWrapperTransitionEnd,i&&r.emit("transitionEnd"))}),r.$wrapperEl[0].addEventListener("transitionend",r.onTranslateToWrapperTransitionEnd),r.$wrapperEl[0].addEventListener("webkitTransitionEnd",r.onTranslateToWrapperTransitionEnd))),!0}},transition:{setTransition:function(e,t){this.params.cssMode||this.$wrapperEl.transition(e),this.emit("setTransition",e,t)},transitionStart:function(e,t){void 0===e&&(e=!0);var i=this.activeIndex,s=this.params,a=this.previousIndex;if(!s.cssMode){s.autoHeight&&this.updateAutoHeight();var r=t;if(r||(r=i>a?"next":i<a?"prev":"reset"),this.emit("transitionStart"),e&&i!==a){if("reset"===r)return void this.emit("slideResetTransitionStart");this.emit("slideChangeTransitionStart"),"next"===r?this.emit("slideNextTransitionStart"):this.emit("slidePrevTransitionStart")}}},transitionEnd:function(e,t){void 0===e&&(e=!0);var i=this.activeIndex,s=this.previousIndex,a=this.params;if(this.animating=!1,!a.cssMode){this.setTransition(0);var r=t;if(r||(r=i>s?"next":i<s?"prev":"reset"),this.emit("transitionEnd"),e&&i!==s){if("reset"===r)return void this.emit("slideResetTransitionEnd");this.emit("slideChangeTransitionEnd"),"next"===r?this.emit("slideNextTransitionEnd"):this.emit("slidePrevTransitionEnd")}}}},slide:{slideTo:function(e,t,i,s){void 0===e&&(e=0),void 0===t&&(t=this.params.speed),void 0===i&&(i=!0);var a=this,r=e;r<0&&(r=0);var n=a.params,o=a.snapGrid,l=a.slidesGrid,d=a.previousIndex,h=a.activeIndex,p=a.rtlTranslate,u=a.wrapperEl;if(a.animating&&n.preventInteractionOnTransition)return!1;var c=Math.min(a.params.slidesPerGroupSkip,r),v=c+Math.floor((r-c)/a.params.slidesPerGroup);v>=o.length&&(v=o.length-1),(h||n.initialSlide||0)===(d||0)&&i&&a.emit("beforeSlideChangeStart");var f,m=-o[v];if(a.updateProgress(m),n.normalizeSlideIndex)for(var g=0;g<l.length;g+=1)-Math.floor(100*m)>=Math.floor(100*l[g])&&(r=g);if(a.initialized&&r!==h){if(!a.allowSlideNext&&m<a.translate&&m<a.minTranslate())return!1;if(!a.allowSlidePrev&&m>a.translate&&m>a.maxTranslate()&&(h||0)!==r)return!1}if(f=r>h?"next":r<h?"prev":"reset",p&&-m===a.translate||!p&&m===a.translate)return a.updateActiveIndex(r),n.autoHeight&&a.updateAutoHeight(),a.updateSlidesClasses(),"slide"!==n.effect&&a.setTranslate(m),"reset"!==f&&(a.transitionStart(i,f),a.transitionEnd(i,f)),!1;if(n.cssMode){var y,C=a.isHorizontal(),w=-m;if(p&&(w=u.scrollWidth-u.offsetWidth-w),0===t)u[C?"scrollLeft":"scrollTop"]=w;else if(u.scrollTo)u.scrollTo(((y={})[C?"left":"top"]=w,y.behavior="smooth",y));else u[C?"scrollLeft":"scrollTop"]=w;return!0}return 0===t?(a.setTransition(0),a.setTranslate(m),a.updateActiveIndex(r),a.updateSlidesClasses(),a.emit("beforeTransitionStart",t,s),a.transitionStart(i,f),a.transitionEnd(i,f)):(a.setTransition(t),a.setTranslate(m),a.updateActiveIndex(r),a.updateSlidesClasses(),a.emit("beforeTransitionStart",t,s),a.transitionStart(i,f),a.animating||(a.animating=!0,a.onSlideToWrapperTransitionEnd||(a.onSlideToWrapperTransitionEnd=function(e){a&&!a.destroyed&&e.target===this&&(a.$wrapperEl[0].removeEventListener("transitionend",a.onSlideToWrapperTransitionEnd),a.$wrapperEl[0].removeEventListener("webkitTransitionEnd",a.onSlideToWrapperTransitionEnd),a.onSlideToWrapperTransitionEnd=null,delete a.onSlideToWrapperTransitionEnd,a.transitionEnd(i,f))}),a.$wrapperEl[0].addEventListener("transitionend",a.onSlideToWrapperTransitionEnd),a.$wrapperEl[0].addEventListener("webkitTransitionEnd",a.onSlideToWrapperTransitionEnd))),!0},slideToLoop:function(e,t,i,s){void 0===e&&(e=0),void 0===t&&(t=this.params.speed),void 0===i&&(i=!0);var a=e;return this.params.loop&&(a+=this.loopedSlides),this.slideTo(a,t,i,s)},slideNext:function(e,t,i){void 0===e&&(e=this.params.speed),void 0===t&&(t=!0);var s=this.params,a=this.animating,r=this.activeIndex<s.slidesPerGroupSkip?1:s.slidesPerGroup;if(s.loop){if(a&&s.loopPreventsSlide)return!1;this.loopFix(),this._clientLeft=this.$wrapperEl[0].clientLeft}return this.slideTo(this.activeIndex+r,e,t,i)},slidePrev:function(e,t,i){void 0===e&&(e=this.params.speed),void 0===t&&(t=!0);var s=this.params,a=this.animating,r=this.snapGrid,n=this.slidesGrid,o=this.rtlTranslate;if(s.loop){if(a&&s.loopPreventsSlide)return!1;this.loopFix(),this._clientLeft=this.$wrapperEl[0].clientLeft}function l(e){return e<0?-Math.floor(Math.abs(e)):Math.floor(e)}var d,h=l(o?this.translate:-this.translate),p=r.map((function(e){return l(e)})),u=(r[p.indexOf(h)],r[p.indexOf(h)-1]);return void 0===u&&s.cssMode&&r.forEach((function(e){!u&&h>=e&&(u=e)})),void 0!==u&&(d=n.indexOf(u))<0&&(d=this.activeIndex-1),this.slideTo(d,e,t,i)},slideReset:function(e,t,i){return void 0===e&&(e=this.params.speed),void 0===t&&(t=!0),this.slideTo(this.activeIndex,e,t,i)},slideToClosest:function(e,t,i,s){void 0===e&&(e=this.params.speed),void 0===t&&(t=!0),void 0===s&&(s=.5);var a=this.activeIndex,r=Math.min(this.params.slidesPerGroupSkip,a),n=r+Math.floor((a-r)/this.params.slidesPerGroup),o=this.rtlTranslate?this.translate:-this.translate;if(o>=this.snapGrid[n]){var l=this.snapGrid[n];o-l>(this.snapGrid[n+1]-l)*s&&(a+=this.params.slidesPerGroup)}else{var d=this.snapGrid[n-1];o-d<=(this.snapGrid[n]-d)*s&&(a-=this.params.slidesPerGroup)}return a=Math.max(a,0),a=Math.min(a,this.slidesGrid.length-1),this.slideTo(a,e,t,i)},slideToClickedSlide:function(){var e,t=this,i=t.params,s=t.$wrapperEl,a="auto"===i.slidesPerView?t.slidesPerViewDynamic():i.slidesPerView,r=t.clickedIndex;if(i.loop){if(t.animating)return;e=parseInt(m(t.clickedSlide).attr("data-swiper-slide-index"),10),i.centeredSlides?r<t.loopedSlides-a/2||r>t.slides.length-t.loopedSlides+a/2?(t.loopFix(),r=s.children("."+i.slideClass+'[data-swiper-slide-index="'+e+'"]:not(.'+i.slideDuplicateClass+")").eq(0).index(),b((function(){t.slideTo(r)}))):t.slideTo(r):r>t.slides.length-a?(t.loopFix(),r=s.children("."+i.slideClass+'[data-swiper-slide-index="'+e+'"]:not(.'+i.slideDuplicateClass+")").eq(0).index(),b((function(){t.slideTo(r)}))):t.slideTo(r)}else t.slideTo(r)}},loop:{loopCreate:function(){var e=this,t=r(),i=e.params,s=e.$wrapperEl;s.children("."+i.slideClass+"."+i.slideDuplicateClass).remove();var a=s.children("."+i.slideClass);if(i.loopFillGroupWithBlank){var n=i.slidesPerGroup-a.length%i.slidesPerGroup;if(n!==i.slidesPerGroup){for(var o=0;o<n;o+=1){var l=m(t.createElement("div")).addClass(i.slideClass+" "+i.slideBlankClass);s.append(l)}a=s.children("."+i.slideClass)}}"auto"!==i.slidesPerView||i.loopedSlides||(i.loopedSlides=a.length),e.loopedSlides=Math.ceil(parseFloat(i.loopedSlides||i.slidesPerView,10)),e.loopedSlides+=i.loopAdditionalSlides,e.loopedSlides>a.length&&(e.loopedSlides=a.length);var d=[],h=[];a.each((function(t,i){var s=m(t);i<e.loopedSlides&&h.push(t),i<a.length&&i>=a.length-e.loopedSlides&&d.push(t),s.attr("data-swiper-slide-index",i)}));for(var p=0;p<h.length;p+=1)s.append(m(h[p].cloneNode(!0)).addClass(i.slideDuplicateClass));for(var u=d.length-1;u>=0;u-=1)s.prepend(m(d[u].cloneNode(!0)).addClass(i.slideDuplicateClass))},loopFix:function(){this.emit("beforeLoopFix");var e,t=this.activeIndex,i=this.slides,s=this.loopedSlides,a=this.allowSlidePrev,r=this.allowSlideNext,n=this.snapGrid,o=this.rtlTranslate;this.allowSlidePrev=!0,this.allowSlideNext=!0;var l=-n[t]-this.getTranslate();if(t<s)e=i.length-3*s+t,e+=s,this.slideTo(e,0,!1,!0)&&0!==l&&this.setTranslate((o?-this.translate:this.translate)-l);else if(t>=i.length-s){e=-i.length+t+s,e+=s,this.slideTo(e,0,!1,!0)&&0!==l&&this.setTranslate((o?-this.translate:this.translate)-l)}this.allowSlidePrev=a,this.allowSlideNext=r,this.emit("loopFix")},loopDestroy:function(){var e=this.$wrapperEl,t=this.params,i=this.slides;e.children("."+t.slideClass+"."+t.slideDuplicateClass+",."+t.slideClass+"."+t.slideBlankClass).remove(),i.removeAttr("data-swiper-slide-index")}},grabCursor:{setGrabCursor:function(e){if(!(this.support.touch||!this.params.simulateTouch||this.params.watchOverflow&&this.isLocked||this.params.cssMode)){var t=this.el;t.style.cursor="move",t.style.cursor=e?"-webkit-grabbing":"-webkit-grab",t.style.cursor=e?"-moz-grabbin":"-moz-grab",t.style.cursor=e?"grabbing":"grab"}},unsetGrabCursor:function(){this.support.touch||this.params.watchOverflow&&this.isLocked||this.params.cssMode||(this.el.style.cursor="")}},manipulation:{appendSlide:function(e){var t=this.$wrapperEl,i=this.params;if(i.loop&&this.loopDestroy(),"object"==typeof e&&"length"in e)for(var s=0;s<e.length;s+=1)e[s]&&t.append(e[s]);else t.append(e);i.loop&&this.loopCreate(),i.observer&&this.support.observer||this.update()},prependSlide:function(e){var t=this.params,i=this.$wrapperEl,s=this.activeIndex;t.loop&&this.loopDestroy();var a=s+1;if("object"==typeof e&&"length"in e){for(var r=0;r<e.length;r+=1)e[r]&&i.prepend(e[r]);a=s+e.length}else i.prepend(e);t.loop&&this.loopCreate(),t.observer&&this.support.observer||this.update(),this.slideTo(a,0,!1)},addSlide:function(e,t){var i=this.$wrapperEl,s=this.params,a=this.activeIndex;s.loop&&(a-=this.loopedSlides,this.loopDestroy(),this.slides=i.children("."+s.slideClass));var r=this.slides.length;if(e<=0)this.prependSlide(t);else if(e>=r)this.appendSlide(t);else{for(var n=a>e?a+1:a,o=[],l=r-1;l>=e;l-=1){var d=this.slides.eq(l);d.remove(),o.unshift(d)}if("object"==typeof t&&"length"in t){for(var h=0;h<t.length;h+=1)t[h]&&i.append(t[h]);n=a>e?a+t.length:a}else i.append(t);for(var p=0;p<o.length;p+=1)i.append(o[p]);s.loop&&this.loopCreate(),s.observer&&this.support.observer||this.update(),s.loop?this.slideTo(n+this.loopedSlides,0,!1):this.slideTo(n,0,!1)}},removeSlide:function(e){var t=this.params,i=this.$wrapperEl,s=this.activeIndex;t.loop&&(s-=this.loopedSlides,this.loopDestroy(),this.slides=i.children("."+t.slideClass));var a,r=s;if("object"==typeof e&&"length"in e){for(var n=0;n<e.length;n+=1)a=e[n],this.slides[a]&&this.slides.eq(a).remove(),a<r&&(r-=1);r=Math.max(r,0)}else a=e,this.slides[a]&&this.slides.eq(a).remove(),a<r&&(r-=1),r=Math.max(r,0);t.loop&&this.loopCreate(),t.observer&&this.support.observer||this.update(),t.loop?this.slideTo(r+this.loopedSlides,0,!1):this.slideTo(r,0,!1)},removeAllSlides:function(){for(var e=[],t=0;t<this.slides.length;t+=1)e.push(t);this.removeSlide(e)}},events:{attachEvents:function(){var e=r(),t=this.params,i=this.touchEvents,s=this.el,a=this.wrapperEl,n=this.device,o=this.support;this.onTouchStart=I.bind(this),this.onTouchMove=A.bind(this),this.onTouchEnd=B.bind(this),t.cssMode&&(this.onScroll=N.bind(this)),this.onClick=G.bind(this);var l=!!t.nested;if(!o.touch&&o.pointerEvents)s.addEventListener(i.start,this.onTouchStart,!1),e.addEventListener(i.move,this.onTouchMove,l),e.addEventListener(i.end,this.onTouchEnd,!1);else{if(o.touch){var d=!("touchstart"!==i.start||!o.passiveListener||!t.passiveListeners)&&{passive:!0,capture:!1};s.addEventListener(i.start,this.onTouchStart,d),s.addEventListener(i.move,this.onTouchMove,o.passiveListener?{passive:!1,capture:l}:l),s.addEventListener(i.end,this.onTouchEnd,d),i.cancel&&s.addEventListener(i.cancel,this.onTouchEnd,d),$||(e.addEventListener("touchstart",F),$=!0)}(t.simulateTouch&&!n.ios&&!n.android||t.simulateTouch&&!o.touch&&n.ios)&&(s.addEventListener("mousedown",this.onTouchStart,!1),e.addEventListener("mousemove",this.onTouchMove,l),e.addEventListener("mouseup",this.onTouchEnd,!1))}(t.preventClicks||t.preventClicksPropagation)&&s.addEventListener("click",this.onClick,!0),t.cssMode&&a.addEventListener("scroll",this.onScroll),t.updateOnWindowResize?this.on(n.ios||n.android?"resize orientationchange observerUpdate":"resize observerUpdate",D,!0):this.on("observerUpdate",D,!0)},detachEvents:function(){var e=r(),t=this.params,i=this.touchEvents,s=this.el,a=this.wrapperEl,n=this.device,o=this.support,l=!!t.nested;if(!o.touch&&o.pointerEvents)s.removeEventListener(i.start,this.onTouchStart,!1),e.removeEventListener(i.move,this.onTouchMove,l),e.removeEventListener(i.end,this.onTouchEnd,!1);else{if(o.touch){var d=!("onTouchStart"!==i.start||!o.passiveListener||!t.passiveListeners)&&{passive:!0,capture:!1};s.removeEventListener(i.start,this.onTouchStart,d),s.removeEventListener(i.move,this.onTouchMove,l),s.removeEventListener(i.end,this.onTouchEnd,d),i.cancel&&s.removeEventListener(i.cancel,this.onTouchEnd,d)}(t.simulateTouch&&!n.ios&&!n.android||t.simulateTouch&&!o.touch&&n.ios)&&(s.removeEventListener("mousedown",this.onTouchStart,!1),e.removeEventListener("mousemove",this.onTouchMove,l),e.removeEventListener("mouseup",this.onTouchEnd,!1))}(t.preventClicks||t.preventClicksPropagation)&&s.removeEventListener("click",this.onClick,!0),t.cssMode&&a.removeEventListener("scroll",this.onScroll),this.off(n.ios||n.android?"resize orientationchange observerUpdate":"resize observerUpdate",D)}},breakpoints:{setBreakpoint:function(){var e=this.activeIndex,t=this.initialized,i=this.loopedSlides,s=void 0===i?0:i,a=this.params,r=this.$el,n=a.breakpoints;if(n&&(!n||0!==Object.keys(n).length)){var o=this.getBreakpoint(n);if(o&&this.currentBreakpoint!==o){var l=o in n?n[o]:void 0;l&&["slidesPerView","spaceBetween","slidesPerGroup","slidesPerGroupSkip","slidesPerColumn"].forEach((function(e){var t=l[e];void 0!==t&&(l[e]="slidesPerView"!==e||"AUTO"!==t&&"auto"!==t?"slidesPerView"===e?parseFloat(t):parseInt(t,10):"auto")}));var d=l||this.originalParams,h=a.slidesPerColumn>1,p=d.slidesPerColumn>1;h&&!p?(r.removeClass(a.containerModifierClass+"multirow "+a.containerModifierClass+"multirow-column"),this.emitContainerClasses()):!h&&p&&(r.addClass(a.containerModifierClass+"multirow"),"column"===d.slidesPerColumnFill&&r.addClass(a.containerModifierClass+"multirow-column"),this.emitContainerClasses());var u=d.direction&&d.direction!==a.direction,c=a.loop&&(d.slidesPerView!==a.slidesPerView||u);u&&t&&this.changeDirection(),x(this.params,d),x(this,{allowTouchMove:this.params.allowTouchMove,allowSlideNext:this.params.allowSlideNext,allowSlidePrev:this.params.allowSlidePrev}),this.currentBreakpoint=o,this.emit("_beforeBreakpoint",d),c&&t&&(this.loopDestroy(),this.loopCreate(),this.updateSlides(),this.slideTo(e-s+this.loopedSlides,0,!1)),this.emit("breakpoint",d)}}},getBreakpoint:function(e){var t=o();if(e){var i=!1,s=Object.keys(e).map((function(e){if("string"==typeof e&&0===e.indexOf("@")){var i=parseFloat(e.substr(1));return{value:t.innerHeight*i,point:e}}return{value:e,point:e}}));s.sort((function(e,t){return parseInt(e.value,10)-parseInt(t.value,10)}));for(var a=0;a<s.length;a+=1){var r=s[a],n=r.point;r.value<=t.innerWidth&&(i=n)}return i||"max"}}},checkOverflow:{checkOverflow:function(){var e=this.params,t=this.isLocked,i=this.slides.length>0&&e.slidesOffsetBefore+e.spaceBetween*(this.slides.length-1)+this.slides[0].offsetWidth*this.slides.length;e.slidesOffsetBefore&&e.slidesOffsetAfter&&i?this.isLocked=i<=this.size:this.isLocked=1===this.snapGrid.length,this.allowSlideNext=!this.isLocked,this.allowSlidePrev=!this.isLocked,t!==this.isLocked&&this.emit(this.isLocked?"lock":"unlock"),t&&t!==this.isLocked&&(this.isEnd=!1,this.navigation&&this.navigation.update())}},classes:{addClasses:function(){var e=this.classNames,t=this.params,i=this.rtl,s=this.$el,a=this.device,r=[];r.push("initialized"),r.push(t.direction),t.freeMode&&r.push("free-mode"),t.autoHeight&&r.push("autoheight"),i&&r.push("rtl"),t.slidesPerColumn>1&&(r.push("multirow"),"column"===t.slidesPerColumnFill&&r.push("multirow-column")),a.android&&r.push("android"),a.ios&&r.push("ios"),t.cssMode&&r.push("css-mode"),r.forEach((function(i){e.push(t.containerModifierClass+i)})),s.addClass(e.join(" ")),this.emitContainerClasses()},removeClasses:function(){var e=this.$el,t=this.classNames;e.removeClass(t.join(" ")),this.emitContainerClasses()}},images:{loadImage:function(e,t,i,s,a,r){var n,l=o();function d(){r&&r()}m(e).parent("picture")[0]||e.complete&&a?d():t?((n=new l.Image).onload=d,n.onerror=d,s&&(n.sizes=s),i&&(n.srcset=i),t&&(n.src=t)):d()},preloadImages:function(){var e=this;function t(){null!=e&&e&&!e.destroyed&&(void 0!==e.imagesLoaded&&(e.imagesLoaded+=1),e.imagesLoaded===e.imagesToLoad.length&&(e.params.updateOnImagesReady&&e.update(),e.emit("imagesReady")))}e.imagesToLoad=e.$el.find("img");for(var i=0;i<e.imagesToLoad.length;i+=1){var s=e.imagesToLoad[i];e.loadImage(s,s.currentSrc||s.getAttribute("src"),s.srcset||s.getAttribute("srcset"),s.sizes||s.getAttribute("sizes"),!0,t)}}}},j={},_=function(){function t(){for(var e,i,s=arguments.length,a=new Array(s),r=0;r<s;r++)a[r]=arguments[r];1===a.length&&a[0].constructor&&a[0].constructor===Object?i=a[0]:(e=a[0],i=a[1]),i||(i={}),i=x({},i),e&&!i.el&&(i.el=e);var n=this;n.support=M(),n.device=P({userAgent:i.userAgent}),n.browser=k(),n.eventsListeners={},n.eventsAnyListeners=[],void 0===n.modules&&(n.modules={}),Object.keys(n.modules).forEach((function(e){var t=n.modules[e];if(t.params){var s=Object.keys(t.params)[0],a=t.params[s];if("object"!=typeof a||null===a)return;if(!(s in i)||!("enabled"in a))return;!0===i[s]&&(i[s]={enabled:!0}),"object"!=typeof i[s]||"enabled"in i[s]||(i[s].enabled=!0),i[s]||(i[s]={enabled:!1})}}));var o=x({},V);n.useParams(o),n.params=x({},o,j,i),n.originalParams=x({},n.params),n.passedParams=x({},i),n.params&&n.params.on&&Object.keys(n.params.on).forEach((function(e){n.on(e,n.params.on[e])})),n.params&&n.params.onAny&&n.onAny(n.params.onAny),n.$=m;var l=m(n.params.el);if(e=l[0]){if(l.length>1){var d=[];return l.each((function(e){var s=x({},i,{el:e});d.push(new t(s))})),d}var h,p,u;return e.swiper=n,e&&e.shadowRoot&&e.shadowRoot.querySelector?(h=m(e.shadowRoot.querySelector("."+n.params.wrapperClass))).children=function(e){return l.children(e)}:h=l.children("."+n.params.wrapperClass),x(n,{$el:l,el:e,$wrapperEl:h,wrapperEl:h[0],classNames:[],slides:m(),slidesGrid:[],snapGrid:[],slidesSizesGrid:[],isHorizontal:function(){return"horizontal"===n.params.direction},isVertical:function(){return"vertical"===n.params.direction},rtl:"rtl"===e.dir.toLowerCase()||"rtl"===l.css("direction"),rtlTranslate:"horizontal"===n.params.direction&&("rtl"===e.dir.toLowerCase()||"rtl"===l.css("direction")),wrongRTL:"-webkit-box"===h.css("display"),activeIndex:0,realIndex:0,isBeginning:!0,isEnd:!1,translate:0,previousTranslate:0,progress:0,velocity:0,animating:!1,allowSlideNext:n.params.allowSlideNext,allowSlidePrev:n.params.allowSlidePrev,touchEvents:(p=["touchstart","touchmove","touchend","touchcancel"],u=["mousedown","mousemove","mouseup"],n.support.pointerEvents&&(u=["pointerdown","pointermove","pointerup"]),n.touchEventsTouch={start:p[0],move:p[1],end:p[2],cancel:p[3]},n.touchEventsDesktop={start:u[0],move:u[1],end:u[2]},n.support.touch||!n.params.simulateTouch?n.touchEventsTouch:n.touchEventsDesktop),touchEventsData:{isTouched:void 0,isMoved:void 0,allowTouchCallbacks:void 0,touchStartTime:void 0,isScrolling:void 0,currentTranslate:void 0,startTranslate:void 0,allowThresholdMove:void 0,formElements:"input, select, option, textarea, button, video, label",lastClickTime:T(),clickTimeout:void 0,velocities:[],allowMomentumBounce:void 0,isTouchEvent:void 0,startMoving:void 0},allowClick:!0,allowTouchMove:n.params.allowTouchMove,touches:{startX:0,startY:0,currentX:0,currentY:0,diff:0},imagesToLoad:[],imagesLoaded:0}),n.useModules(),n.emit("_swiper"),n.params.init&&n.init(),n}}var i,s,a,r=t.prototype;return r.emitContainerClasses=function(){var e=this;if(e.params._emitClasses&&e.el){var t=e.el.className.split(" ").filter((function(t){return 0===t.indexOf("swiper-container")||0===t.indexOf(e.params.containerModifierClass)}));e.emit("_containerClasses",t.join(" "))}},r.emitSlidesClasses=function(){var e=this;e.params._emitClasses&&e.el&&e.slides.each((function(t){var i=t.className.split(" ").filter((function(t){return 0===t.indexOf("swiper-slide")||0===t.indexOf(e.params.slideClass)}));e.emit("_slideClass",t,i.join(" "))}))},r.slidesPerViewDynamic=function(){var e=this.params,t=this.slides,i=this.slidesGrid,s=this.size,a=this.activeIndex,r=1;if(e.centeredSlides){for(var n,o=t[a].swiperSlideSize,l=a+1;l<t.length;l+=1)t[l]&&!n&&(r+=1,(o+=t[l].swiperSlideSize)>s&&(n=!0));for(var d=a-1;d>=0;d-=1)t[d]&&!n&&(r+=1,(o+=t[d].swiperSlideSize)>s&&(n=!0))}else for(var h=a+1;h<t.length;h+=1)i[h]-i[a]<s&&(r+=1);return r},r.update=function(){var e=this;if(e&&!e.destroyed){var t=e.snapGrid,i=e.params;i.breakpoints&&e.setBreakpoint(),e.updateSize(),e.updateSlides(),e.updateProgress(),e.updateSlidesClasses(),e.params.freeMode?(s(),e.params.autoHeight&&e.updateAutoHeight()):(("auto"===e.params.slidesPerView||e.params.slidesPerView>1)&&e.isEnd&&!e.params.centeredSlides?e.slideTo(e.slides.length-1,0,!1,!0):e.slideTo(e.activeIndex,0,!1,!0))||s(),i.watchOverflow&&t!==e.snapGrid&&e.checkOverflow(),e.emit("update")}function s(){var t=e.rtlTranslate?-1*e.translate:e.translate,i=Math.min(Math.max(t,e.maxTranslate()),e.minTranslate());e.setTranslate(i),e.updateActiveIndex(),e.updateSlidesClasses()}},r.changeDirection=function(e,t){void 0===t&&(t=!0);var i=this.params.direction;return e||(e="horizontal"===i?"vertical":"horizontal"),e===i||"horizontal"!==e&&"vertical"!==e||(this.$el.removeClass(""+this.params.containerModifierClass+i).addClass(""+this.params.containerModifierClass+e),this.emitContainerClasses(),this.params.direction=e,this.slides.each((function(t){"vertical"===e?t.style.width="":t.style.height=""})),this.emit("changeDirection"),t&&this.update()),this},r.init=function(){this.initialized||(this.emit("beforeInit"),this.params.breakpoints&&this.setBreakpoint(),this.addClasses(),this.params.loop&&this.loopCreate(),this.updateSize(),this.updateSlides(),this.params.watchOverflow&&this.checkOverflow(),this.params.grabCursor&&this.setGrabCursor(),this.params.preloadImages&&this.preloadImages(),this.params.loop?this.slideTo(this.params.initialSlide+this.loopedSlides,0,this.params.runCallbacksOnInit):this.slideTo(this.params.initialSlide,0,this.params.runCallbacksOnInit),this.attachEvents(),this.initialized=!0,this.emit("init"),this.emit("afterInit"))},r.destroy=function(e,t){void 0===e&&(e=!0),void 0===t&&(t=!0);var i,s=this,a=s.params,r=s.$el,n=s.$wrapperEl,o=s.slides;return void 0===s.params||s.destroyed||(s.emit("beforeDestroy"),s.initialized=!1,s.detachEvents(),a.loop&&s.loopDestroy(),t&&(s.removeClasses(),r.removeAttr("style"),n.removeAttr("style"),o&&o.length&&o.removeClass([a.slideVisibleClass,a.slideActiveClass,a.slideNextClass,a.slidePrevClass].join(" ")).removeAttr("style").removeAttr("data-swiper-slide-index")),s.emit("destroy"),Object.keys(s.eventsListeners).forEach((function(e){s.off(e)})),!1!==e&&(s.$el[0].swiper=null,i=s,Object.keys(i).forEach((function(e){try{i[e]=null}catch(e){}try{delete i[e]}catch(e){}}))),s.destroyed=!0),null},t.extendDefaults=function(e){x(j,e)},t.installModule=function(e){t.prototype.modules||(t.prototype.modules={});var i=e.name||Object.keys(t.prototype.modules).length+"_"+T();t.prototype.modules[i]=e},t.use=function(e){return Array.isArray(e)?(e.forEach((function(e){return t.installModule(e)})),t):(t.installModule(e),t)},i=t,a=[{key:"extendedDefaults",get:function(){return j}},{key:"defaults",get:function(){return V}}],(s=null)&&e(i.prototype,s),a&&e(i,a),t}();Object.keys(H).forEach((function(e){Object.keys(H[e]).forEach((function(t){_.prototype[t]=H[e][t]}))})),_.use([L,O]);var W={update:function(){var e=this.params.navigation;if(!this.params.loop){var t=this.navigation,i=t.$nextEl,s=t.$prevEl;s&&s.length>0&&(this.isBeginning?s.addClass(e.disabledClass):s.removeClass(e.disabledClass),s[this.params.watchOverflow&&this.isLocked?"addClass":"removeClass"](e.lockClass)),i&&i.length>0&&(this.isEnd?i.addClass(e.disabledClass):i.removeClass(e.disabledClass),i[this.params.watchOverflow&&this.isLocked?"addClass":"removeClass"](e.lockClass))}},onPrevClick:function(e){e.preventDefault(),this.isBeginning&&!this.params.loop||this.slidePrev()},onNextClick:function(e){e.preventDefault(),this.isEnd&&!this.params.loop||this.slideNext()},init:function(){var e,t,i=this.params.navigation;(i.nextEl||i.prevEl)&&(i.nextEl&&(e=m(i.nextEl),this.params.uniqueNavElements&&"string"==typeof i.nextEl&&e.length>1&&1===this.$el.find(i.nextEl).length&&(e=this.$el.find(i.nextEl))),i.prevEl&&(t=m(i.prevEl),this.params.uniqueNavElements&&"string"==typeof i.prevEl&&t.length>1&&1===this.$el.find(i.prevEl).length&&(t=this.$el.find(i.prevEl))),e&&e.length>0&&e.on("click",this.navigation.onNextClick),t&&t.length>0&&t.on("click",this.navigation.onPrevClick),x(this.navigation,{$nextEl:e,nextEl:e&&e[0],$prevEl:t,prevEl:t&&t[0]}))},destroy:function(){var e=this.navigation,t=e.$nextEl,i=e.$prevEl;t&&t.length&&(t.off("click",this.navigation.onNextClick),t.removeClass(this.params.navigation.disabledClass)),i&&i.length&&(i.off("click",this.navigation.onPrevClick),i.removeClass(this.params.navigation.disabledClass))}},R={update:function(){var e=this.rtl,t=this.params.pagination;if(t.el&&this.pagination.el&&this.pagination.$el&&0!==this.pagination.$el.length){var i,s=this.virtual&&this.params.virtual.enabled?this.virtual.slides.length:this.slides.length,a=this.pagination.$el,r=this.params.loop?Math.ceil((s-2*this.loopedSlides)/this.params.slidesPerGroup):this.snapGrid.length;if(this.params.loop?((i=Math.ceil((this.activeIndex-this.loopedSlides)/this.params.slidesPerGroup))>s-1-2*this.loopedSlides&&(i-=s-2*this.loopedSlides),i>r-1&&(i-=r),i<0&&"bullets"!==this.params.paginationType&&(i=r+i)):i=void 0!==this.snapIndex?this.snapIndex:this.activeIndex||0,"bullets"===t.type&&this.pagination.bullets&&this.pagination.bullets.length>0){var n,o,l,d=this.pagination.bullets;if(t.dynamicBullets&&(this.pagination.bulletSize=d.eq(0)[this.isHorizontal()?"outerWidth":"outerHeight"](!0),a.css(this.isHorizontal()?"width":"height",this.pagination.bulletSize*(t.dynamicMainBullets+4)+"px"),t.dynamicMainBullets>1&&void 0!==this.previousIndex&&(this.pagination.dynamicBulletIndex+=i-this.previousIndex,this.pagination.dynamicBulletIndex>t.dynamicMainBullets-1?this.pagination.dynamicBulletIndex=t.dynamicMainBullets-1:this.pagination.dynamicBulletIndex<0&&(this.pagination.dynamicBulletIndex=0)),n=i-this.pagination.dynamicBulletIndex,l=((o=n+(Math.min(d.length,t.dynamicMainBullets)-1))+n)/2),d.removeClass(t.bulletActiveClass+" "+t.bulletActiveClass+"-next "+t.bulletActiveClass+"-next-next "+t.bulletActiveClass+"-prev "+t.bulletActiveClass+"-prev-prev "+t.bulletActiveClass+"-main"),a.length>1)d.each((function(e){var s=m(e),a=s.index();a===i&&s.addClass(t.bulletActiveClass),t.dynamicBullets&&(a>=n&&a<=o&&s.addClass(t.bulletActiveClass+"-main"),a===n&&s.prev().addClass(t.bulletActiveClass+"-prev").prev().addClass(t.bulletActiveClass+"-prev-prev"),a===o&&s.next().addClass(t.bulletActiveClass+"-next").next().addClass(t.bulletActiveClass+"-next-next"))}));else{var h=d.eq(i),p=h.index();if(h.addClass(t.bulletActiveClass),t.dynamicBullets){for(var u=d.eq(n),c=d.eq(o),v=n;v<=o;v+=1)d.eq(v).addClass(t.bulletActiveClass+"-main");if(this.params.loop)if(p>=d.length-t.dynamicMainBullets){for(var f=t.dynamicMainBullets;f>=0;f-=1)d.eq(d.length-f).addClass(t.bulletActiveClass+"-main");d.eq(d.length-t.dynamicMainBullets-1).addClass(t.bulletActiveClass+"-prev")}else u.prev().addClass(t.bulletActiveClass+"-prev").prev().addClass(t.bulletActiveClass+"-prev-prev"),c.next().addClass(t.bulletActiveClass+"-next").next().addClass(t.bulletActiveClass+"-next-next");else u.prev().addClass(t.bulletActiveClass+"-prev").prev().addClass(t.bulletActiveClass+"-prev-prev"),c.next().addClass(t.bulletActiveClass+"-next").next().addClass(t.bulletActiveClass+"-next-next")}}if(t.dynamicBullets){var g=Math.min(d.length,t.dynamicMainBullets+4),y=(this.pagination.bulletSize*g-this.pagination.bulletSize)/2-l*this.pagination.bulletSize,C=e?"right":"left";d.css(this.isHorizontal()?C:"top",y+"px")}}if("fraction"===t.type&&(a.find("."+t.currentClass).text(t.formatFractionCurrent(i+1)),a.find("."+t.totalClass).text(t.formatFractionTotal(r))),"progressbar"===t.type){var w;w=t.progressbarOpposite?this.isHorizontal()?"vertical":"horizontal":this.isHorizontal()?"horizontal":"vertical";var b=(i+1)/r,T=1,S=1;"horizontal"===w?T=b:S=b,a.find("."+t.progressbarFillClass).transform("translate3d(0,0,0) scaleX("+T+") scaleY("+S+")").transition(this.params.speed)}"custom"===t.type&&t.renderCustom?(a.html(t.renderCustom(this,i+1,r)),this.emit("paginationRender",a[0])):this.emit("paginationUpdate",a[0]),a[this.params.watchOverflow&&this.isLocked?"addClass":"removeClass"](t.lockClass)}},render:function(){var e=this.params.pagination;if(e.el&&this.pagination.el&&this.pagination.$el&&0!==this.pagination.$el.length){var t=this.virtual&&this.params.virtual.enabled?this.virtual.slides.length:this.slides.length,i=this.pagination.$el,s="";if("bullets"===e.type){for(var a=this.params.loop?Math.ceil((t-2*this.loopedSlides)/this.params.slidesPerGroup):this.snapGrid.length,r=0;r<a;r+=1)e.renderBullet?s+=e.renderBullet.call(this,r,e.bulletClass):s+="<"+e.bulletElement+' class="'+e.bulletClass+'"></'+e.bulletElement+">";i.html(s),this.pagination.bullets=i.find("."+e.bulletClass)}"fraction"===e.type&&(s=e.renderFraction?e.renderFraction.call(this,e.currentClass,e.totalClass):'<span class="'+e.currentClass+'"></span> / <span class="'+e.totalClass+'"></span>',i.html(s)),"progressbar"===e.type&&(s=e.renderProgressbar?e.renderProgressbar.call(this,e.progressbarFillClass):'<span class="'+e.progressbarFillClass+'"></span>',i.html(s)),"custom"!==e.type&&this.emit("paginationRender",this.pagination.$el[0])}},init:function(){var e=this,t=e.params.pagination;if(t.el){var i=m(t.el);0!==i.length&&(e.params.uniqueNavElements&&"string"==typeof t.el&&i.length>1&&(i=e.$el.find(t.el)),"bullets"===t.type&&t.clickable&&i.addClass(t.clickableClass),i.addClass(t.modifierClass+t.type),"bullets"===t.type&&t.dynamicBullets&&(i.addClass(""+t.modifierClass+t.type+"-dynamic"),e.pagination.dynamicBulletIndex=0,t.dynamicMainBullets<1&&(t.dynamicMainBullets=1)),"progressbar"===t.type&&t.progressbarOpposite&&i.addClass(t.progressbarOppositeClass),t.clickable&&i.on("click","."+t.bulletClass,(function(t){t.preventDefault();var i=m(this).index()*e.params.slidesPerGroup;e.params.loop&&(i+=e.loopedSlides),e.slideTo(i)})),x(e.pagination,{$el:i,el:i[0]}))}},destroy:function(){var e=this.params.pagination;if(e.el&&this.pagination.el&&this.pagination.$el&&0!==this.pagination.$el.length){var t=this.pagination.$el;t.removeClass(e.hiddenClass),t.removeClass(e.modifierClass+e.type),this.pagination.bullets&&this.pagination.bullets.removeClass(e.bulletActiveClass),e.clickable&&t.off("click","."+e.bulletClass)}}},q={loadInSlide:function(e,t){void 0===t&&(t=!0);var i=this,s=i.params.lazy;if(void 0!==e&&0!==i.slides.length){var a=i.virtual&&i.params.virtual.enabled?i.$wrapperEl.children("."+i.params.slideClass+'[data-swiper-slide-index="'+e+'"]'):i.slides.eq(e),r=a.find("."+s.elementClass+":not(."+s.loadedClass+"):not(."+s.loadingClass+")");!a.hasClass(s.elementClass)||a.hasClass(s.loadedClass)||a.hasClass(s.loadingClass)||r.push(a[0]),0!==r.length&&r.each((function(e){var r=m(e);r.addClass(s.loadingClass);var n=r.attr("data-background"),o=r.attr("data-src"),l=r.attr("data-srcset"),d=r.attr("data-sizes"),h=r.parent("picture");i.loadImage(r[0],o||n,l,d,!1,(function(){if(null!=i&&i&&(!i||i.params)&&!i.destroyed){if(n?(r.css("background-image",'url("'+n+'")'),r.removeAttr("data-background")):(l&&(r.attr("srcset",l),r.removeAttr("data-srcset")),d&&(r.attr("sizes",d),r.removeAttr("data-sizes")),h.length&&h.children("source").each((function(e){var t=m(e);t.attr("data-srcset")&&(t.attr("srcset",t.attr("data-srcset")),t.removeAttr("data-srcset"))})),o&&(r.attr("src",o),r.removeAttr("data-src"))),r.addClass(s.loadedClass).removeClass(s.loadingClass),a.find("."+s.preloaderClass).remove(),i.params.loop&&t){var e=a.attr("data-swiper-slide-index");if(a.hasClass(i.params.slideDuplicateClass)){var p=i.$wrapperEl.children('[data-swiper-slide-index="'+e+'"]:not(.'+i.params.slideDuplicateClass+")");i.lazy.loadInSlide(p.index(),!1)}else{var u=i.$wrapperEl.children("."+i.params.slideDuplicateClass+'[data-swiper-slide-index="'+e+'"]');i.lazy.loadInSlide(u.index(),!1)}}i.emit("lazyImageReady",a[0],r[0]),i.params.autoHeight&&i.updateAutoHeight()}})),i.emit("lazyImageLoad",a[0],r[0])}))}},load:function(){var e=this,t=e.$wrapperEl,i=e.params,s=e.slides,a=e.activeIndex,r=e.virtual&&i.virtual.enabled,n=i.lazy,o=i.slidesPerView;function l(e){if(r){if(t.children("."+i.slideClass+'[data-swiper-slide-index="'+e+'"]').length)return!0}else if(s[e])return!0;return!1}function d(e){return r?m(e).attr("data-swiper-slide-index"):m(e).index()}if("auto"===o&&(o=0),e.lazy.initialImageLoaded||(e.lazy.initialImageLoaded=!0),e.params.watchSlidesVisibility)t.children("."+i.slideVisibleClass).each((function(t){var i=r?m(t).attr("data-swiper-slide-index"):m(t).index();e.lazy.loadInSlide(i)}));else if(o>1)for(var h=a;h<a+o;h+=1)l(h)&&e.lazy.loadInSlide(h);else e.lazy.loadInSlide(a);if(n.loadPrevNext)if(o>1||n.loadPrevNextAmount&&n.loadPrevNextAmount>1){for(var p=n.loadPrevNextAmount,u=o,c=Math.min(a+u+Math.max(p,u),s.length),v=Math.max(a-Math.max(u,p),0),f=a+o;f<c;f+=1)l(f)&&e.lazy.loadInSlide(f);for(var g=v;g<a;g+=1)l(g)&&e.lazy.loadInSlide(g)}else{var y=t.children("."+i.slideNextClass);y.length>0&&e.lazy.loadInSlide(d(y));var C=t.children("."+i.slidePrevClass);C.length>0&&e.lazy.loadInSlide(d(C))}}},X={run:function(){var e=this,t=e.slides.eq(e.activeIndex),i=e.params.autoplay.delay;t.attr("data-swiper-autoplay")&&(i=t.attr("data-swiper-autoplay")||e.params.autoplay.delay),clearTimeout(e.autoplay.timeout),e.autoplay.timeout=b((function(){e.params.autoplay.reverseDirection?e.params.loop?(e.loopFix(),e.slidePrev(e.params.speed,!0,!0),e.emit("autoplay")):e.isBeginning?e.params.autoplay.stopOnLastSlide?e.autoplay.stop():(e.slideTo(e.slides.length-1,e.params.speed,!0,!0),e.emit("autoplay")):(e.slidePrev(e.params.speed,!0,!0),e.emit("autoplay")):e.params.loop?(e.loopFix(),e.slideNext(e.params.speed,!0,!0),e.emit("autoplay")):e.isEnd?e.params.autoplay.stopOnLastSlide?e.autoplay.stop():(e.slideTo(0,e.params.speed,!0,!0),e.emit("autoplay")):(e.slideNext(e.params.speed,!0,!0),e.emit("autoplay")),e.params.cssMode&&e.autoplay.running&&e.autoplay.run()}),i)},start:function(){return void 0===this.autoplay.timeout&&(!this.autoplay.running&&(this.autoplay.running=!0,this.emit("autoplayStart"),this.autoplay.run(),!0))},stop:function(){return!!this.autoplay.running&&(void 0!==this.autoplay.timeout&&(this.autoplay.timeout&&(clearTimeout(this.autoplay.timeout),this.autoplay.timeout=void 0),this.autoplay.running=!1,this.emit("autoplayStop"),!0))},pause:function(e){this.autoplay.running&&(this.autoplay.paused||(this.autoplay.timeout&&clearTimeout(this.autoplay.timeout),this.autoplay.paused=!0,0!==e&&this.params.autoplay.waitForTransition?(this.$wrapperEl[0].addEventListener("transitionend",this.autoplay.onTransitionEnd),this.$wrapperEl[0].addEventListener("webkitTransitionEnd",this.autoplay.onTransitionEnd)):(this.autoplay.paused=!1,this.autoplay.run())))},onVisibilityChange:function(){var e=r();"hidden"===e.visibilityState&&this.autoplay.running&&this.autoplay.pause(),"visible"===e.visibilityState&&this.autoplay.paused&&(this.autoplay.run(),this.autoplay.paused=!1)},onTransitionEnd:function(e){this&&!this.destroyed&&this.$wrapperEl&&e.target===this.$wrapperEl[0]&&(this.$wrapperEl[0].removeEventListener("transitionend",this.autoplay.onTransitionEnd),this.$wrapperEl[0].removeEventListener("webkitTransitionEnd",this.autoplay.onTransitionEnd),this.autoplay.paused=!1,this.autoplay.running?this.autoplay.run():this.autoplay.stop())}},Y={setTranslate:function(){for(var e=this.slides,t=0;t<e.length;t+=1){var i=this.slides.eq(t),s=-i[0].swiperSlideOffset;this.params.virtualTranslate||(s-=this.translate);var a=0;this.isHorizontal()||(a=s,s=0);var r=this.params.fadeEffect.crossFade?Math.max(1-Math.abs(i[0].progress),0):1+Math.min(Math.max(i[0].progress,-1),0);i.css({opacity:r}).transform("translate3d("+s+"px, "+a+"px, 0px)")}},setTransition:function(e){var t=this,i=t.slides,s=t.$wrapperEl;if(i.transition(e),t.params.virtualTranslate&&0!==e){var a=!1;i.transitionEnd((function(){if(!a&&t&&!t.destroyed){a=!0,t.animating=!1;for(var e=["webkitTransitionEnd","transitionend"],i=0;i<e.length;i+=1)s.trigger(e[i])}}))}}},U=[{name:"navigation",params:{navigation:{nextEl:null,prevEl:null,hideOnClick:!1,disabledClass:"swiper-button-disabled",hiddenClass:"swiper-button-hidden",lockClass:"swiper-button-lock"}},create:function(){E(this,{navigation:t({},W)})},on:{init:function(e){e.navigation.init(),e.navigation.update()},toEdge:function(e){e.navigation.update()},fromEdge:function(e){e.navigation.update()},destroy:function(e){e.navigation.destroy()},click:function(e,t){var i,s=e.navigation,a=s.$nextEl,r=s.$prevEl;!e.params.navigation.hideOnClick||m(t.target).is(r)||m(t.target).is(a)||(a?i=a.hasClass(e.params.navigation.hiddenClass):r&&(i=r.hasClass(e.params.navigation.hiddenClass)),!0===i?e.emit("navigationShow"):e.emit("navigationHide"),a&&a.toggleClass(e.params.navigation.hiddenClass),r&&r.toggleClass(e.params.navigation.hiddenClass))}}},{name:"pagination",params:{pagination:{el:null,bulletElement:"span",clickable:!1,hideOnClick:!1,renderBullet:null,renderProgressbar:null,renderFraction:null,renderCustom:null,progressbarOpposite:!1,type:"bullets",dynamicBullets:!1,dynamicMainBullets:1,formatFractionCurrent:function(e){return e},formatFractionTotal:function(e){return e},bulletClass:"swiper-pagination-bullet",bulletActiveClass:"swiper-pagination-bullet-active",modifierClass:"swiper-pagination-",currentClass:"swiper-pagination-current",totalClass:"swiper-pagination-total",hiddenClass:"swiper-pagination-hidden",progressbarFillClass:"swiper-pagination-progressbar-fill",progressbarOppositeClass:"swiper-pagination-progressbar-opposite",clickableClass:"swiper-pagination-clickable",lockClass:"swiper-pagination-lock"}},create:function(){E(this,{pagination:t({dynamicBulletIndex:0},R)})},on:{init:function(e){e.pagination.init(),e.pagination.render(),e.pagination.update()},activeIndexChange:function(e){(e.params.loop||void 0===e.snapIndex)&&e.pagination.update()},snapIndexChange:function(e){e.params.loop||e.pagination.update()},slidesLengthChange:function(e){e.params.loop&&(e.pagination.render(),e.pagination.update())},snapGridLengthChange:function(e){e.params.loop||(e.pagination.render(),e.pagination.update())},destroy:function(e){e.pagination.destroy()},click:function(e,t){e.params.pagination.el&&e.params.pagination.hideOnClick&&e.pagination.$el.length>0&&!m(t.target).hasClass(e.params.pagination.bulletClass)&&(!0===e.pagination.$el.hasClass(e.params.pagination.hiddenClass)?e.emit("paginationShow"):e.emit("paginationHide"),e.pagination.$el.toggleClass(e.params.pagination.hiddenClass))}}},{name:"lazy",params:{lazy:{enabled:!1,loadPrevNext:!1,loadPrevNextAmount:1,loadOnTransitionStart:!1,elementClass:"swiper-lazy",loadingClass:"swiper-lazy-loading",loadedClass:"swiper-lazy-loaded",preloaderClass:"swiper-lazy-preloader"}},create:function(){E(this,{lazy:t({initialImageLoaded:!1},q)})},on:{beforeInit:function(e){e.params.lazy.enabled&&e.params.preloadImages&&(e.params.preloadImages=!1)},init:function(e){e.params.lazy.enabled&&!e.params.loop&&0===e.params.initialSlide&&e.lazy.load()},scroll:function(e){e.params.freeMode&&!e.params.freeModeSticky&&e.lazy.load()},resize:function(e){e.params.lazy.enabled&&e.lazy.load()},scrollbarDragMove:function(e){e.params.lazy.enabled&&e.lazy.load()},transitionStart:function(e){e.params.lazy.enabled&&(e.params.lazy.loadOnTransitionStart||!e.params.lazy.loadOnTransitionStart&&!e.lazy.initialImageLoaded)&&e.lazy.load()},transitionEnd:function(e){e.params.lazy.enabled&&!e.params.lazy.loadOnTransitionStart&&e.lazy.load()},slideChange:function(e){e.params.lazy.enabled&&e.params.cssMode&&e.lazy.load()}}},{name:"autoplay",params:{autoplay:{enabled:!1,delay:3e3,waitForTransition:!0,disableOnInteraction:!0,stopOnLastSlide:!1,reverseDirection:!1}},create:function(){E(this,{autoplay:t(t({},X),{},{running:!1,paused:!1})})},on:{init:function(e){e.params.autoplay.enabled&&(e.autoplay.start(),r().addEventListener("visibilitychange",e.autoplay.onVisibilityChange))},beforeTransitionStart:function(e,t,i){e.autoplay.running&&(i||!e.params.autoplay.disableOnInteraction?e.autoplay.pause(t):e.autoplay.stop())},sliderFirstMove:function(e){e.autoplay.running&&(e.params.autoplay.disableOnInteraction?e.autoplay.stop():e.autoplay.pause())},touchEnd:function(e){e.params.cssMode&&e.autoplay.paused&&!e.params.autoplay.disableOnInteraction&&e.autoplay.run()},destroy:function(e){e.autoplay.running&&e.autoplay.stop(),r().removeEventListener("visibilitychange",e.autoplay.onVisibilityChange)}}},{name:"effect-fade",params:{fadeEffect:{crossFade:!1}},create:function(){E(this,{fadeEffect:t({},Y)})},on:{beforeInit:function(e){if("fade"===e.params.effect){e.classNames.push(e.params.containerModifierClass+"fade");var t={slidesPerView:1,slidesPerColumn:1,slidesPerGroup:1,watchSlidesProgress:!0,spaceBetween:0,virtualTranslate:!0};x(e.params,t),x(e.originalParams,t)}},setTranslate:function(e){"fade"===e.params.effect&&e.fadeEffect.setTranslate()},setTransition:function(e,t){"fade"===e.params.effect&&e.fadeEffect.setTransition(t)}}}];return _.use(U),_}));

function createSwiper(selector, swiperParams, callback = null) {
    /**
     * Use timer to create new task instead of executing in the current one
     * in order to split total blocking time
     */
    setTimeout(function() {
        const swiperInstance = new Swiper(selector, swiperParams);
        if (callback) {
            callback(swiperInstance);
        }
    }, 0);
}

            
            LS.ready.then(function(){

                
                



                
                                    

// Move to our_content
window.urls = {
    "shippingUrl": "\/envio\/"
}


document.addEventListener('lazybeforeunveil', function(e){
    if ((e.target.parentElement) && (e.target.nextElementSibling)) {
        var parent = e.target.parentElement;
        var sibling = e.target.nextElementSibling;
        if (sibling.classList.contains('js-lazy-loading-preloader')) {
            sibling.style.display = 'none';
            parent.style.display = 'block';
        }
    }
});


window.lazySizesConfig = window.lazySizesConfig || {};
lazySizesConfig.hFac = 0.4;


DOMContentLoaded.addEventOrExecute(() => {

	
    
    jQueryNuvem(".js-notification-close, .js-tooltip-close").on( "click", function(e) {
        e.preventDefault();
        jQueryNuvem(e.currentTarget).closest(".js-notification, .js-tooltip").hide();
        jQueryNuvem(".js-quick-login-badge").hide();
    });

    
    var $notification_status_page = jQueryNuvem(".js-notification-status-page");
    var $quick_login_notification = jQueryNuvem(".js-notification-quick-login");
    var $fixed_bottom_button = jQueryNuvem(".js-btn-fixed-bottom");
    
	    
    if ($notification_status_page.length > 0){
        if (LS.shouldShowOrderStatusNotification($notification_status_page.data('url'))){
            $notification_status_page.show();
        };
        jQueryNuvem(".js-notification-status-page-close").on( "click", function(e) {
            e.preventDefault();
            LS.dontShowOrderStatusNotificationAgain($notification_status_page.data('url'));
        });
    }

    
    jQueryNuvem(".js-cart-notification-close").on("click", function(){
        jQueryNuvem(".js-alert-added-to-cart").removeClass("notification-visible").addClass("notification-hidden");
        setTimeout(function(){
            jQueryNuvem('.js-cart-notification-item-img').attr('src', '');
            jQueryNuvem(".js-alert-added-to-cart").hide();
        },2000);
    });

    
    
    
    
    jQueryNuvem(".js-dismiss-quicklogin").on( "click", function(e) {
        LS.dontShowQuickLoginNotification();
    });


    setTimeout(function(){
        jQueryNuvem(".js-quick-login-success").fadeOut();
    },8000);

    
        
        const footerLegal = jQueryNuvem(".js-footer-legal");

        let footerOffset = 20;

        if (window.innerWidth > 768) {
            footerOffset = 60;
        }

                    footerLegal.css("paddingBottom", footerOffset + "px");
        
        
        restoreNotifications = function(){

            // Whatsapp button position
            if (window.innerWidth < 768) {
                $fixed_bottom_button.css("marginBottom", "10px");
            }

            footerLegal.css("paddingBottom", footerOffset + "px");
        };

        if (!window.cookieNotificationService.isAcknowledged()) {
            jQueryNuvem(".js-notification-cookie-banner").show();

                            
            const cookieBannerHeight = jQueryNuvem(".js-notification-cookie-banner").outerHeight();
            footerLegal.css("paddingBottom", cookieBannerHeight + footerOffset + "px");

                        if (window.innerWidth < 768) {
                $fixed_bottom_button.css("marginBottom", "120px");
            }
        }

        jQueryNuvem(".js-acknowledge-cookies").on( "click", function(e) {
            window.cookieNotificationService.acknowledge();

            footerLegal.removeAttr("style");
            restoreNotifications();
        });

    
    
    
    if (window.innerWidth < 768) {

        
        cleanURLHash = function(){
            const uri = window.location.toString();
            const clean_uri = uri.substring(0, uri.indexOf("#"));
            window.history.replaceState({}, document.title, clean_uri);
        };

        
        goBackBrowser = function(){
            cleanURLHash();
            history.back();
        };

        
        if(window.location.href.indexOf("modal-fullscreen") > -1) {
            cleanURLHash();
        }

        
        jQueryNuvem(document).on("click", ".js-fullscreen-modal-open", function(e) {
            e.preventDefault();
            var modal_url_hash = jQueryNuvem(this).data("modalUrl");
            window.location.hash = modal_url_hash;
        });

        
        jQueryNuvem(document).on("click", ".js-fullscreen-modal-close", function(e) {
            e.preventDefault();
            goBackBrowser();
        });

        
        window.onhashchange = function() {
            if(window.location.href.indexOf("modal-fullscreen") <= -1) {

                
                if(jQueryNuvem(".js-fullscreen-modal").hasClass("modal-show")){

                    
                    if(jQueryNuvem(".js-modal.modal-show").length == 1){
                        jQueryNuvem("body").removeClass("overflow-none");
                    }
                    var $opened_modal = jQueryNuvem(".js-fullscreen-modal.modal-show");
                    var $opened_modal_overlay = $opened_modal.prev();

                    $opened_modal.removeClass("modal-show");
                    setTimeout(() => $opened_modal.hide(), 500);
                    $opened_modal_overlay.fadeOut(500);

                }
            }
        }

    }

    jQueryNuvem(document).on("click", ".js-modal-open", function(e) {
        e.preventDefault(); 
        var modal_id = jQueryNuvem(this).data('toggle');
        var $overlay_id = jQueryNuvem('.js-modal-overlay[data-modal-id="' + modal_id + '"]');
        if (jQueryNuvem(modal_id).hasClass("modal-show")) {
            let modal = jQueryNuvem(modal_id).removeClass("modal-show");
            setTimeout(() => modal.hide(), 500);
        } else {
                        
            if(!jQueryNuvem(".js-modal.modal-show").length){
                jQueryNuvem("body").addClass("overflow-none");
            }
            $overlay_id.fadeIn(400);
            jQueryNuvem(modal_id).detach().appendTo("body");
            $overlay_id.detach().insertBefore(modal_id);
            jQueryNuvem(modal_id).show().addClass("modal-show");
        }             
    });

    jQueryNuvem(document).on("click", ".js-modal-close", function(e) {
        e.preventDefault();  

        
        if(jQueryNuvem(".js-modal.modal-show").length == 1){
            jQueryNuvem("body").removeClass("overflow-none");
        }
        var $modal = jQueryNuvem(this).closest(".js-modal");
        var modal_id = $modal.attr('id');
        var $overlay_id = jQueryNuvem('.js-modal-overlay[data-modal-id="#' + modal_id + '"]');
        $modal.removeClass("modal-show");
        setTimeout(() => $modal.hide(), 500);
        $overlay_id.fadeOut(500);
        
        
        if ((window.innerWidth < 768) && (jQueryNuvem(this).hasClass(".js-fullscreen-modal-close"))) {
            goBackBrowser();
        }
    });

    jQueryNuvem(document).on("click", ".js-modal-overlay", function(e) {
        e.preventDefault();

        
        if(jQueryNuvem(".js-modal.modal-show").length == 1){
            jQueryNuvem("body").removeClass("overflow-none");
        }

        var modal_id = jQueryNuvem(this).data('modalId');
        let modal = jQueryNuvem(modal_id).removeClass("modal-show");
        setTimeout(() => modal.hide(), 500);
        jQueryNuvem(this).fadeOut(500);
    });

    
        jQueryNuvem(document).on("click", ".js-card-collapse-toggle", function(e) {
        e.preventDefault();
        jQueryNuvem(this).toggleClass('active');
        jQueryNuvem(this).closest(".js-card-collapse").toggleClass('active');
    });

        jQueryNuvem(document).on("click", ".js-accordion-toggle", function(e) {
        e.preventDefault();
        if(jQueryNuvem(this).hasClass("js-accordion-show-only")){
            jQueryNuvem(this).hide();
        }else{
            jQueryNuvem(this).find(".js-accordion-toggle-inactive").toggle();
            jQueryNuvem(this).find(".js-accordion-toggle-active").toggle();
        }
        jQueryNuvem(this).prev(".js-accordion-container").slideToggle();
    });

	
    
        
        
        function applyOffset(selector){

            // Get nav height on load
            if (window.innerWidth > 768) {
                var head_height = jQueryNuvem(".js-head-main").height();
                jQueryNuvem(selector).css("paddingTop", head_height.toString() + 'px');
            }else{

                                var head_height = 0;
            }

            // Apply offset nav height on load
            
            window.addEventListener("resize", function() {

                // Get nav height on resize
                var head_height = jQueryNuvem(".js-head-main").height();

                // Apply offset on resize
                if (window.innerWidth > 768) {
                    jQueryNuvem(selector).css("paddingTop", head_height.toString() + 'px');
                }else{

                                        jQueryNuvem(selector).css("paddingTop", "0px");
                }
            });
        }


    
        applyOffset(".js-head-offset");

        
        window.addEventListener("scroll", function() {

            var scrolledPosition = window.pageYOffset;

            var header = jQueryNuvem(".js-head-main");
            var navbarHeight = header.outerHeight();
            var topbarHeight = jQueryNuvem(".js-topbar").outerHeight();

            if (scrolledPosition > navbarHeight) {
                header.addClass('compress').css('top', -topbarHeight + 'px' );
                if (window.innerWidth < 768) {
                    $category_controls.css('top', (navbarHeight - topbarHeight - 2).toString() + 'px' );
                }
            } else {
                header.removeClass('compress').css("top", "0px");
                if (window.innerWidth < 768) {
                    $category_controls.css('top', navbarHeight.toString() + 'px' );
                }
            }
        });

            
          


    
        jQueryNuvem(".js-utilities-item").on("mouseenter", function (e) {
            e.preventDefault();
            jQueryNuvem(e.currentTarget).toggleClass("active");
        }).on("mouseleave", function(e) {
            e.preventDefault();
            jQueryNuvem(e.currentTarget).toggleClass("active");
        });


    
        var $top_nav = jQueryNuvem(".js-mobile-nav");
        var $page_main_content = jQueryNuvem(".js-main-content");
        var $search_backdrop = jQueryNuvem(".js-search-backdrop");

        $top_nav.addClass("move-down").removeClass("move-up");


        
        jQueryNuvem(".js-toggle-page-accordion").on("click", function (e) {
            e.preventDefault();
            jQueryNuvem(e.currentTarget).toggleClass("active").closest(".js-nav-list-toggle-accordion").next(".js-pages-accordion").slideToggle(300);
        });

        var win_height = window.innerHeight;
        var head_height = jQueryNuvem(".js-head-main").height();

        jQueryNuvem(".js-desktop-dropdown").css('maxHeight', (win_height - head_height - 50).toString() + 'px');

        jQueryNuvem(".js-item-desktop").on("mouseenter", function (e) {
            jQueryNuvem(e.currentTarget).addClass("active");
        }).on("mouseleave", function(e) {
            jQueryNuvem(e.currentTarget).removeClass("active");
        });

        jQueryNuvem(".js-item-desktop").on("mouseenter", function (e) {
            jQueryNuvem('.js-nav-desktop-list').children(".selected").removeClass("selected");
            jQueryNuvem(e.currentTarget).addClass("selected");
        }).on("mouseleave", function(e) {
            const self = jQueryNuvem(this);
            setTimeout(function(){
                self.removeClass("selected");
            },500);
        });

        
        jQueryNuvem(".js-desktop-dropdown").on("mouseleave", function (e) {
            const self = jQueryNuvem(this);
            self.css("pointer-events" , "none");
            setTimeout(function(){
                self.css("pointer-events" , "initial");
            },1000);
        });

        
        jQueryNuvem(".js-toggle-search").on("click", function (e) {
            e.preventDefault;
            jQueryNuvem(".js-search-input").trigger('focus');
        });


    
        LS.search(jQueryNuvem(".js-search-input"), function (html, count) {
            $search_suggests = jQueryNuvem(this).closest(".js-search-container").next(".js-search-suggest");
            if (count > 0) {
                $search_suggests.html(html).show();
            } else {
                $search_suggests.hide();
            }
            if (jQueryNuvem(this).val().length == 0) {
                $search_suggests.hide();
            }
        }, {
            snipplet: 'header/header-search-results.tpl'
        });

        if (window.innerWidth > 768) {

            
            jQueryNuvem("body").on("click", function () {
                jQueryNuvem(".js-search-suggest").hide();
            });

            
            jQueryNuvem(document).on("click", ".js-search-suggest a", function () {
                jQueryNuvem(".js-search-suggest").show();
            });
        }

        jQueryNuvem(".js-search-suggest").on("click", ".js-search-suggest-all-link", function (e) {
            e.preventDefault();
            $this_closest_form = jQueryNuvem(this).closest(".js-search-suggest").prev(".js-search-form");
            $this_closest_form.submit();
        });


	
	
    


	
	
		
        var width = window.innerWidth;
        if (width < 767) {
            createSwiper('.js-informative-banners', {
                slidesPerView: 1.2,
                watchOverflow: true,
                centerInsufficientSlides: true,
                pagination: {
                    el: '.js-informative-banners-pagination',
                    clickable: true,
                },
                breakpoints: {
                    640: {
                        slidesPerView: 3,
                    }
                }
            });
        }

    
	
    
	
	
        
    
    var $category_controls = jQueryNuvem(".js-category-controls");
    var mobile_nav_height = jQueryNuvem(".js-head-main").innerHeight();

	
    
    
        
        jQueryNuvem(document).on("click", ".js-item-buy-open", function(e) {
            e.preventDefault();
            jQueryNuvem(this).toggleClass("btn-primary btn-secondary");
            jQueryNuvem(this).closest(".js-quickshop-container").find(".js-item-variants").fadeToggle(300);

            var elementTop = jQueryNuvem(this).closest(".js-product-container").offset().top;
            var viewportTop = window.pageYOffset;

            if(elementTop < viewportTop){
                document.documentElement.scroll({
                    top: jQueryNuvem(this).closest(".js-product-container").offset().top - 180,
                    behavior: 'smooth'
                });
            }

        });

        jQueryNuvem(document).on("click", ".js-item-buy-close", function(e) {
            e.preventDefault();
            jQueryNuvem(this).closest(".js-item-variants").fadeToggle(300);
            jQueryNuvem(this).closest(".js-quickshop-container").find(".js-item-buy-open").toggleClass("btn-primary btn-secondary");
        });

    
    
    
        LS.registerOnChangeVariant(function(variant){
                        var current_image = jQueryNuvem('.js-item-product[data-product-id="'+variant.product_id+'"] .js-item-image');
            current_image.attr('srcset', variant.image_url);

                    });

    
    
	
	
	function get_max_installments_without_interests(number_of_installment, installment_data, max_installments_without_interests) {
	    if (parseInt(number_of_installment) > parseInt(max_installments_without_interests[0])) {
	        if (installment_data.without_interests) {
	            return [number_of_installment, installment_data.installment_value.toFixed(2)];
	        }
	    }
	    return max_installments_without_interests;
	}

	
	function get_max_installments_with_interests(number_of_installment, installment_data, max_installments_with_interests) {
	    if (parseInt(number_of_installment) > parseInt(max_installments_with_interests[0])) {
	        if (installment_data.without_interests == false) {
	            return [number_of_installment, installment_data.installment_value.toFixed(2)];
	        }
	    }
	    return max_installments_with_interests;
	}

	
	function refreshInstallmentv2(price){
        jQueryNuvem(".js-modal-installment-price" ).each(function( el ) {
	        const installment = Number(jQueryNuvem(el).data('installment'));
	        jQueryNuvem(el).text(LS.currency.display_short + (price/installment).toLocaleString('de-DE', {maximumFractionDigits: 2, minimumFractionDigits: 2}));
	    });
	}

    
    function refreshPaymentDiscount(price){
        jQueryNuvem(".js-price-with-discount" ).each(function( el ) {
            const payment_discount = jQueryNuvem(el).data('paymentDiscount');
            jQueryNuvem(el).text(LS.formatToCurrency(price - ((price * payment_discount) / 100)))
        });
    }

        
	
	
	function changeVariant(variant) {
        jQueryNuvem(".js-product-detail .js-shipping-calculator-response").hide();
        jQueryNuvem("#shipping-variant-id").val(variant.id);

	    var parent = jQueryNuvem("body");
	    if (variant.element) {
	        parent = jQueryNuvem(variant.element);
	    }

	    var sku = parent.find('#sku');
	    if(sku.length) {
	        sku.text(variant.sku).show();
	    }

	    
        
	    var installment_helper = function($element, amount, price){
	        $element.find('.js-installment-amount').text(amount);
	        $element.find('.js-installment-price').attr("data-value", price);
	        $element.find('.js-installment-price').text(LS.currency.display_short + parseFloat(price).toLocaleString('de-DE', { minimumFractionDigits: 2 }));
	        if(variant.price_short && Math.abs(variant.price_number - price * amount) < 1) {
	            $element.find('.js-installment-total-price').text((variant.price_short).toLocaleString('de-DE', { minimumFractionDigits: 2 }));
	        } else {
	            $element.find('.js-installment-total-price').text(LS.currency.display_short + (price * amount).toLocaleString('de-DE', { minimumFractionDigits: 2 }));
	        }
	    };

	    if (variant.installments_data) {
	        var variant_installments = JSON.parse(variant.installments_data);
	        var max_installments_without_interests = [0,0];
	        var max_installments_with_interests = [0,0];

	        	        jQueryNuvem('.js-payment-provider-installments-row').hide();

	        for (let payment_method in variant_installments) {

	            	            var paymentMethodId = '#installment_' + payment_method.replace(" ", "_") + '_1';
	            var minimumInstallmentValue = jQueryNuvem(paymentMethodId).closest('.js-info-payment-method').attr("data-minimum-installment-value");

                let installments = variant_installments[payment_method];
	            for (let number_of_installment in installments) {
                    let installment_data = installments[number_of_installment];
	                max_installments_without_interests = get_max_installments_without_interests(number_of_installment, installment_data, max_installments_without_interests);
	                max_installments_with_interests = get_max_installments_with_interests(number_of_installment, installment_data, max_installments_with_interests);
	                var installment_container_selector = '#installment_' + payment_method.replace(" ", "_") + '_' + number_of_installment;

	                	                if(minimumInstallmentValue <= installment_data.installment_value) {
	                    jQueryNuvem(installment_container_selector).show();
	                }

	                if(!parent.hasClass("js-quickshop-container")){
	                    installment_helper(jQueryNuvem(installment_container_selector), number_of_installment, installment_data.installment_value.toFixed(2));
	                }
	            }
	        }
	        var $installments_container = jQueryNuvem(variant.element + ' .js-max-installments-container .js-max-installments');
	        var $installments_modal_link = jQueryNuvem(variant.element + ' #btn-installments');
	        var $payments_module = jQueryNuvem(variant.element + ' .js-product-payments-container');
	        var $installmens_card_icon = jQueryNuvem(variant.element + ' .js-installments-credit-card-icon');

	        	        var installments_to_use = max_installments_without_interests[0] > 1 ? max_installments_without_interests : max_installments_with_interests;

	        if(installments_to_use[0] <= 1 ) {
	        	            $installments_container.hide();
	            $installments_modal_link.hide();
	            $payments_module.hide();
	            $installmens_card_icon.hide();
	        } else {
	            $installments_container.show();
	            $installments_modal_link.show();
	            $payments_module.show();
	            $installmens_card_icon.show();
	            installment_helper($installments_container, installments_to_use[0], installments_to_use[1]);
	        }
	    }

	    if(!parent.hasClass("js-quickshop-container")){
            jQueryNuvem('#installments-modal .js-installments-one-payment').text(variant.price_short).attr("data-value", variant.price_number);
		}

	    if (variant.price_short){
	        parent.find('.js-price-display').text(variant.price_short).show();
	        parent.find('.js-price-display').attr("content", variant.price_number).data('productPrice', variant.price_number_raw);
            
            parent.find('.js-payment-discount-price-product').text(variant.price_with_payment_discount_short);
            parent.find('.js-payment-discount-price-product-container').show();
	    } else {
	        parent.find('.js-price-display, .js-payment-discount-price-product-container').hide();
	    }

	    if ((variant.compare_at_price_short) && !(parent.find(".js-price-display").css("display") == "none")) {
	        parent.find('.js-compare-price-display').text(variant.compare_at_price_short).show();

            if(variant.compare_at_price_number > variant.price_number){
                const saved_compare_price_money = variant.compare_at_price_number - variant.price_number;
                parent.find('.js-offer-saved-money').text(LS.formatToCurrency(saved_compare_price_money));
                parent.find(".js-saved-money-message").show();
            }else {
                parent.find(".js-saved-money-message").hide();
            }
	    } else {
	        parent.find('.js-compare-price-display, .js-saved-money-message').hide();
	    }

	    var button = parent.find('.js-addtocart');
	    button.removeClass('cart').removeClass('contact').removeClass('nostock');
	    var $product_shipping_calculator = parent.find("#product-shipping-container");

        
	    	    if (!variant.available){
	        button.val('Sin stock');
	        button.addClass('nostock');
	        button.attr('disabled', 'disabled');
	        $product_shipping_calculator.hide();
	    } else if (variant.contact) {
	        button.val('Consultar precio');
	        button.addClass('contact');
	        button.removeAttr('disabled');
	        $product_shipping_calculator.hide();
	    } else {
	        button.val('Agregar al carrito');
	        button.addClass('cart');
	        button.removeAttr('disabled');
	        $product_shipping_calculator.show();
	    }

	    
        

        
        LS.updateShippingProduct();

        zipcode_on_changevariant = jQueryNuvem("#product-shipping-container .js-shipping-input").val();
        jQueryNuvem("#product-shipping-container .js-shipping-calculator-current-zip").text(zipcode_on_changevariant);

        	}

	
    jQueryNuvem(document).on("change", ".js-variation-option", function(e) {
        var $parent = jQueryNuvem(this).closest(".js-product-variants");
        var $variants_group = jQueryNuvem(this).closest(".js-product-variants-group");
        var quick_id = jQueryNuvem(this).closest(".js-quickshop-container").attr("id");
        if($parent.hasClass("js-product-quickshop-variants")){
                            LS.changeVariant(changeVariant, '#' + quick_id);
            
                    } else {
            LS.changeVariant(changeVariant, '#single-product');
        }

        
        var $this_product_container = jQueryNuvem(this).closest(".js-product-container");
        var $this_compare_price = $this_product_container.find(".js-compare-price-display");
        var $this_price = $this_product_container.find(".js-price-display");
        var $installment_container = $this_product_container.find(".js-product-payments-container");
        var $installment_text = $this_product_container.find(".js-max-installments-container");
        var $this_add_to_cart =  $this_product_container.find(".js-prod-submit-form");

        // Get the current product discount percentage value
        var current_percentage_value = $this_product_container.find(".js-offer-percentage");

        // Get the current product price and promotional price
        var compare_price_value = $this_compare_price.html();
        var price_value = $this_price.html();

        // Calculate new discount percentage based on difference between filtered old and new prices
        const percentageDifference = window.moneyDifferenceCalculator.percentageDifferenceFromString(compare_price_value, price_value);
        if(percentageDifference){
            $this_product_container.find(".js-offer-percentage").text(percentageDifference);
            $this_product_container.find(".js-offer-label").css("display" , "table");
        }

        if ($this_compare_price.css("display") == "none" || !percentageDifference) {
            $this_product_container.find(".js-offer-label").hide();
        }
        if ($this_add_to_cart.hasClass("nostock")) {
            $this_product_container.find(".js-stock-label").show();
        }
        else {
            $this_product_container.find(".js-stock-label").hide();
	    }
	    if ($this_price.css('display') == 'none'){
	        $installment_container.hide();
	        $installment_text.hide();
	    }else{
	        $installment_text.show();
	    }
	});

	
	
    jQueryNuvem(".js-product-form").on("submit", function (e) {
	    var button = jQueryNuvem(e.currentTarget).find('[type="submit"]');
	    button.attr('disabled', 'disabled');
	    if ((button.hasClass('contact')) || (button.hasClass('catalog'))) {
	        e.preventDefault();
	        var product_id = jQueryNuvem(e.currentTarget).find("input[name='add_to_cart']").val();
	        window.location = "\/contacto\/?product=" + product_id;
	    } else if (button.hasClass('cart')) {
	        button.val('Agregando...');
	    }
	});

	
    
    jQueryNuvem('.js-quantity .js-quantity-up').on('click', function(e) {
        $quantity_input = jQueryNuvem(e.currentTarget).closest(".js-quantity").find(".js-quantity-input");
        $quantity_input.val( parseInt($quantity_input.val(), 10) + 1);
    });

    jQueryNuvem('.js-quantity .js-quantity-down').on('click', function(e) {
        $quantity_input = jQueryNuvem(e.currentTarget).closest(".js-quantity").find(".js-quantity-input");
        quantity_input_val = $quantity_input.val();
        if (quantity_input_val>1) {
            $quantity_input.val( parseInt($quantity_input.val(), 10) - 1);
        }
    });


	
        
    
    
    var head_height = jQueryNuvem(".js-head-main").outerHeight();

    if (window.innerWidth > 768) {
                    jQueryNuvem("#cart-sticky-summary").css("top" , (head_height + 10).toString() + 'px');
            }


    
   function getQuickShopImgSrc(element){
        const image = jQueryNuvem(element).closest('.js-quickshop-container').find('img');
        return String(image.attr('srcset')); 
    }

    jQueryNuvem(document).on("click", ".js-addtocart:not(.js-addtocart-placeholder)", function (e) {

        
        var $productContainer = jQueryNuvem(this).closest('.js-product-container');
        var $productVariants = $productContainer.find(".js-variation-option");
        var $productButton = $productContainer.find("input[type='submit'].js-addtocart");
        var $productButtonPlaceholder = $productContainer.find(".js-addtocart-placeholder");
        var $productButtonText = $productButtonPlaceholder.find(".js-addtocart-text");
        var $productButtonAdding = $productButtonPlaceholder.find(".js-addtocart-adding");
        var $productButtonSuccess = $productButtonPlaceholder.find(".js-addtocart-success");

        
        var isQuickShop = $productContainer.hasClass('js-quickshop-container');

         
        if (!isQuickShop) {
            if(jQueryNuvem(".js-product-slide-img.js-active-variant").length) {
                var imageSrc = $productContainer.find('.js-product-slide-img.js-active-variant').data('srcset').split(' ')[0];
            } else {
                var imageSrc = $productContainer.find('.js-product-slide-img').data('srcset').split(' ')[0];
            }
            var quantity = $productContainer.find('.js-quantity-input').val();
            var name = $productContainer.find('.js-product-name').text();
            var price = $productContainer.find('.js-price-display').text();
            var addedToCartCopy = "Agregar al carrito";
        } else {
            var imageSrc = getQuickShopImgSrc(this);
            var quantity = 1;
            var name = $productContainer.find('.js-item-name').text();
            var price = $productContainer.find('.js-price-display').text().trim();
            var addedToCartCopy = "Comprar";
            if ($productContainer.hasClass("js-quickshop-has-variants")) {
                var addedToCartCopy = "Agregar al carrito";
            }else{
                var addedToCartCopy = "Comprar";
            }
        }

        if (!jQueryNuvem(this).hasClass('contact')) {

                            e.preventDefault();
            
            
            $productButton.hide();
            $productButtonPlaceholder.css('display' , 'inline-block');
            $productButtonText.fadeOut();
            $productButtonAdding.addClass("active");

            
                var callback_add_to_cart = function(){

                    
                    jQueryNuvem(".js-cart-widget-amount").addClass("swing");

                    setTimeout(function(){
                        jQueryNuvem(".js-cart-widget-amount").removeClass("swing");
                    },6000);

                    
                    jQueryNuvem('.js-cart-notification-item-img').attr('srcset', imageSrc);
                    jQueryNuvem('.js-cart-notification-item-name').text(name);
                    jQueryNuvem('.js-cart-notification-item-quantity').text(quantity);
                    jQueryNuvem('.js-cart-notification-item-price').text(price);

                    if($productVariants.length){
                        var output = [];

                        $productVariants.each( function(el){
                            var variants = jQueryNuvem(el);
                            output.push(variants.val());
                        });
                        jQueryNuvem(".js-cart-notification-item-variant-container").show();
                        jQueryNuvem(".js-cart-notification-item-variant").text(output.join(', '))
                    }else{
                        jQueryNuvem(".js-cart-notification-item-variant-container").hide();
                    }

                    
                    var cartItemsAmount = jQueryNuvem(".js-cart-widget-amount").text();

                    if(cartItemsAmount > 1){
                        jQueryNuvem(".js-cart-counts-plural").show();
                        jQueryNuvem(".js-cart-counts-singular").hide();
                    }else{
                        jQueryNuvem(".js-cart-counts-singular").show();
                        jQueryNuvem(".js-cart-counts-plural").hide();
                    }

                    
                    $productButtonAdding.removeClass("active");
                    $productButtonSuccess.addClass("active");
                    setTimeout(function(){
                        $productButtonSuccess.removeClass("active");
                        $productButtonText.fadeIn();
                    },2000);
                    setTimeout(function(){
                        $productButtonPlaceholder.removeAttr("style").hide();
                        $productButton.show();
                    },3000);

                    $productContainer.find(".js-added-to-cart-product-message").slideDown();

                    
                    setTimeout(function(){
                        jQueryNuvem(".js-alert-added-to-cart").show().addClass("notification-visible").removeClass("notification-hidden");
                    },500);

                    if (!cookieService.get('first_product_added_successfully')) {
                        cookieService.set('first_product_added_successfully', 1, 7 );
                    } else{
                        setTimeout(function(){
                            jQueryNuvem(".js-alert-added-to-cart").removeClass("notification-visible").addClass("notification-hidden");
                            setTimeout(function(){
                                jQueryNuvem('.js-cart-notification-item-img').attr('src', '');
                                jQueryNuvem(".js-alert-added-to-cart").hide();
                            },2000);
                        },8000);
                    }


                    
                    
                    if (jQueryNuvem("#product-shipping-container .js-shipping-input").val()) {
                        zipcode_on_addtocart = jQueryNuvem("#product-shipping-container .js-shipping-input").val();
                        jQueryNuvem("#cart-shipping-container .js-shipping-input").val(zipcode_on_addtocart);
                        jQueryNuvem(".js-shipping-calculator-current-zip").text(zipcode_on_addtocart);
                    } else if (cookieService.get('calculator_zipcode')){
                        var zipcode_from_cookie = cookieService.get('calculator_zipcode');
                        jQueryNuvem('.js-shipping-input').val(zipcode_from_cookie);
                        jQueryNuvem(".js-shipping-calculator-current-zip").text(zipcode_from_cookie);
                    }

                    
                    jQueryNuvem(".js-fs-add-this-product").hide();
                    jQueryNuvem(".js-fs-add-one-more").show();

                }
                var callback_error = function(){
                    
                    $productButtonAdding.removeClass("active");
                    $productButtonText.fadeIn();
                    $productButtonPlaceholder.removeAttr("style").hide();
                    $productButton.show();
                }
                $prod_form = jQueryNuvem(this).closest("form");
                LS.addToCartEnhanced(
                    $prod_form,
                    addedToCartCopy,
                    'Agregando...',
                    '¡Uy! No tenemos más stock de este producto para agregarlo al carrito.',
                    false,
                        callback_add_to_cart,
                        callback_error
                );
                    }
    });


    
    jQueryNuvem(document).on("keypress", ".js-cart-quantity-input", function (e) {
        if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
            return false;
        }
    });

    jQueryNuvem(document).on("focusout", ".js-cart-quantity-input", function (e) {
        var itemID = jQueryNuvem(this).attr("data-item-id");
        var itemVAL = jQueryNuvem(this).val();
        if (itemVAL == 0) {
            var r = confirm("¿Seguro que quieres borrar este artículo?");
            if (r == true) {
                LS.removeItem(itemID, true);
            } else {
                jQueryNuvem(this).val(1);
            }
        } else {
            LS.changeQuantity(itemID, itemVAL, true);
        }
    });

    
    jQueryNuvem(".js-trigger-empty-cart-alert").on("click", function (e) {
        e.preventDefault();
        let emptyCartAlert = jQueryNuvem(".js-mobile-nav-empty-cart-alert").fadeIn(100);
        setTimeout(() => emptyCartAlert.fadeOut(500), 1500);
    });

    
    
    jQueryNuvem('form[action="\/comprar\/"]').on("submit", function() {
        cookieService.remove('first_product_added_successfully');
    });


	
    
            if (jQueryNuvem('.js-selected-shipping-method').length) {
            var shipping_cost = jQueryNuvem('.js-selected-shipping-method').data("cost");
            var $shippingCost = jQueryNuvem("#shipping-cost");
            $shippingCost.text(shipping_cost);
            $shippingCost.removeClass('opacity-40');
        }
    
	
    selectShippingOption = function(elem, save_option) {
        jQueryNuvem(".js-shipping-method, .js-branch-method").removeClass('js-selected-shipping-method');
        jQueryNuvem(elem).addClass('js-selected-shipping-method');

        
            var shipping_cost = jQueryNuvem(elem).data("cost");
            var shipping_price_clean = jQueryNuvem(elem).data("price");

            if(shipping_price_clean = 0.00){
                var shipping_cost = ''
            }

            // Updates shipping (ship and pickup) cost on cart
            var $shippingCost = jQueryNuvem("#shipping-cost");
            $shippingCost.text(shipping_cost);
            $shippingCost.removeClass('opacity-40');

        
        if (save_option) {
            LS.saveCalculatedShipping(true);
        }
        if (jQueryNuvem(elem).hasClass("js-shipping-method-hidden")) {
                        if (jQueryNuvem(elem).hasClass("js-pickup-option")) {
                jQueryNuvem(".js-other-pickup-options, .js-show-other-pickup-options .js-shipping-see-less").show();
                jQueryNuvem(".js-show-other-pickup-options .js-shipping-see-more").hide();
            } else {
                jQueryNuvem(".js-other-shipping-options, .js-show-more-shipping-options .js-shipping-see-less").show();
                jQueryNuvem(".js-show-more-shipping-options .js-shipping-see-more").hide()
            }
        }
    };

    
    if (cookieService.get('calculator_zipcode')) {

        
        var zipcode_from_cookie = cookieService.get('calculator_zipcode');

        
            
            jQueryNuvem('#product-shipping-container .js-shipping-input').val(zipcode_from_cookie);

        
        jQueryNuvem(".js-shipping-calculator-current-zip").text(zipcode_from_cookie);

        
        jQueryNuvem(".js-shipping-calculator-head").addClass("with-zip").removeClass("with-form");
        jQueryNuvem(".js-shipping-calculator-with-zipcode").addClass("transition-up-active");
        jQueryNuvem(".js-shipping-calculator-spinner").show();
    } else {

        
        jQueryNuvem(".js-shipping-calculator-form").addClass("transition-up-active");
    }

    
    removeShippingSuboptions = function(){
        var shipping_suboptions_id = jQueryNuvem(".js-modal-shipping-suboptions").attr("id");
        jQueryNuvem("#" + shipping_suboptions_id).remove();
        jQueryNuvem('.js-modal-overlay[data-modal-id="#' + shipping_suboptions_id + '"').remove();
    };

    

    jQueryNuvem(".js-calculate-shipping").on("click", function (e) {
	    e.preventDefault();

                let shipping_input_val = jQueryNuvem(e.currentTarget).closest(".js-shipping-calculator-form").find(".js-shipping-input").val();

        jQueryNuvem(".js-shipping-input").val(shipping_input_val);

                
        if (jQueryNuvem(".js-cart-item").length) {
            LS.calculateShippingAjax(
            jQueryNuvem('#cart-shipping-container').find(".js-shipping-input").val(),
            '\/envio\/',
            jQueryNuvem("#cart-shipping-container").closest(".js-shipping-calculator-container") );
        }

        jQueryNuvem(".js-shipping-calculator-current-zip").html(shipping_input_val);
        removeShippingSuboptions();
	});

	
    jQueryNuvem(".js-shipping-input").on('keydown', function (e) {
	    var key = e.which ? e.which : e.keyCode;
	    var enterKey = 13;
	    if (key === enterKey) {
	        e.preventDefault();
            jQueryNuvem(e.currentTarget).closest(".js-shipping-calculator-form").find(".js-calculate-shipping").trigger('click');
	        if (window.innerWidth < 768) {
                jQueryNuvem(e.currentTarget).trigger('blur');
	        }
	    }
	});

    
    jQueryNuvem(document).on("change", ".js-shipping-method, .js-branch-method", function (e) {
        selectShippingOption(this, true);
        jQueryNuvem(".js-shipping-method-unavailable").hide();
    });

    
    jQueryNuvem(document).on('shipping.options.checked', '.js-shipping-method', function (e) {
        let shippingPrice = jQueryNuvem(this).attr("data-price");
        LS.addToTotal(shippingPrice);

        let total = (LS.data.cart.total / 100) + parseFloat(shippingPrice);
        jQueryNuvem(".js-cart-widget-total").html(LS.formatToCurrency(total));

        selectShippingOption(this, false);
    });

    
    jQueryNuvem(document).on("click", ".js-toggle-branches", function (e) {
        e.preventDefault();
        jQueryNuvem(".js-store-branches-container").slideToggle("fast");
        jQueryNuvem(".js-see-branches, .js-hide-branches").toggle();
    });

    
    jQueryNuvem(document).on("click", ".js-toggle-more-shipping-options", function(e) {
	    e.preventDefault();

        
        if(jQueryNuvem(this).hasClass("js-show-other-pickup-options")){
            jQueryNuvem(".js-other-pickup-options").slideToggle(600);
            jQueryNuvem(".js-show-other-pickup-options .js-shipping-see-less, .js-show-other-pickup-options .js-shipping-see-more").toggle();
        }else{
            jQueryNuvem(".js-other-shipping-options").slideToggle(600);
            jQueryNuvem(".js-show-more-shipping-options .js-shipping-see-less, .js-show-more-shipping-options .js-shipping-see-more").toggle();
        }
	});

    
    
    calculateCartShippingOnLoad = function() {
                if (jQueryNuvem("#cart-shipping-container .js-shipping-input").val()) {
            // If user already had calculated shipping: recalculate shipping
            setTimeout(function() {
                LS.calculateShippingAjax(
                    jQueryNuvem('#cart-shipping-container').find(".js-shipping-input").val(),
                    '\/envio\/',
                    jQueryNuvem("#cart-shipping-container").closest(".js-shipping-calculator-container") );
                    removeShippingSuboptions();
            }, 100);
        }

        if (jQueryNuvem(".js-branch-method").hasClass('js-selected-shipping-method')) {
                    }
    };

    

    
    
    jQueryNuvem(document).on("click", ".js-shipping-calculator-change-zipcode", function(e) {
        e.preventDefault();
        jQueryNuvem(".js-shipping-calculator-response").fadeOut(100);
        jQueryNuvem(".js-shipping-calculator-head").addClass("with-form").removeClass("with-zip");
        jQueryNuvem(".js-shipping-calculator-with-zipcode").removeClass("transition-up-active");
        jQueryNuvem(".js-shipping-calculator-form").addClass("transition-up-active");
    });

	
	

    
    jQueryNuvem(document).on("click", ".js-save-shipping-country", function(e) {

        e.preventDefault();

        
        var selected_country_url = jQueryNuvem(this).closest(".js-modal-shipping-country").find(".js-shipping-country-select option").filter((el) => el.selected).attr("data-country-url");
        location.href = selected_country_url;

        jQueryNuvem(this).text('Aplicando...').addClass("disabled");
    });

    
    jQueryNuvem(".js-winnie-pooh-form").on("submit", function (e) {
        jQueryNuvem(e.currentTarget).attr('action', '');
    });

    jQueryNuvem(".js-form").on("submit", function (e) {
        jQueryNuvem(e.currentTarget).find('.js-form-spinner').show();
    });

    
    
    
    jQueryNuvem('.js-password-view').on("click", function (e) {
        jQueryNuvem(e.currentTarget).toggleClass('password-view');

        if(jQueryNuvem(e.currentTarget).hasClass('password-view')){
            jQueryNuvem(e.currentTarget).parent().find(".js-password-input").attr('type', '');
            jQueryNuvem(e.currentTarget).find(".js-eye-open, .js-eye-closed").toggle();
        } else {
            jQueryNuvem(e.currentTarget).parent().find(".js-password-input").attr('type', 'password');
            jQueryNuvem(e.currentTarget).find(".js-eye-open, .js-eye-closed").toggle();
        }
    });

    

    
    

    
    
        
});
                            });
        </script>
<script defer src="https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015" integrity="sha512-ZpsOmlRQV6y907TI0dKBHq9Md29nnaEIPlkf84rnaERnq6zvWvPUqr2ft8M1aS28oN72PdrCzSjY4U6VaAw1EQ==" data-cf-beacon='{"rayId":"8a90ed21a99f2115","version":"2024.7.0","serverTiming":{"name":{"cfL4":true}},"token":"2a3f03576c514bd3b43f2cb8c8b50533","b":1}' crossorigin="anonymous"></script>
</body>
</html>
